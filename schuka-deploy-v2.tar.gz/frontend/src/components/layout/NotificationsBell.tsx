'use client';
// Колокольчик уведомлений — общий для всех кабинетов (родитель/педагог/руководитель).
// Раз в минуту проверяет количество непрочитанных, по клику открывает список.
import { useEffect, useRef, useState } from 'react';
import { Bell, Check, CheckCheck } from 'lucide-react';
import { api } from '@/lib/api';
import type { AppNotification } from '@/types';
import { formatDistanceToNow } from 'date-fns';
import { ru } from 'date-fns/locale';

const ICON_BY_TYPE: Record<string, string> = {
  PAYMENT_DUE: '💳',
  PAYMENT_RECEIVED: '✅',
  NEW_PHOTO: '🖼️',
  NEW_COMMENT: '💬',
  SUBSCRIPTION_LOW: '⚠️',
  LESSON_REMINDER: '📅',
  ACHIEVEMENT: '🏅',
  BIRTHDAY: '🎂',
  INVENTORY_LOW: '📦',
};

export default function NotificationsBell() {
  const [open, setOpen] = useState(false);
  const [unread, setUnread] = useState(0);
  const [items, setItems] = useState<AppNotification[]>([]);
  const [loading, setLoading] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  const refreshCount = () => {
    api.get('/notifications/unread-count').then((r) => setUnread(r.data.count)).catch(() => {});
  };

  useEffect(() => {
    refreshCount();
    const interval = setInterval(refreshCount, 60_000);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    if (!open) return;
    setLoading(true);
    api.get('/notifications').then((r) => setItems(r.data)).finally(() => setLoading(false));
  }, [open]);

  useEffect(() => {
    const onClickOutside = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false);
    };
    document.addEventListener('mousedown', onClickOutside);
    return () => document.removeEventListener('mousedown', onClickOutside);
  }, []);

  const markRead = async (id: string) => {
    setItems((prev) => prev.map((n) => (n.id === id ? { ...n, isRead: true } : n)));
    setUnread((u) => Math.max(0, u - 1));
    await api.patch(`/notifications/${id}/read`).catch(() => {});
  };

  const markAllRead = async () => {
    setItems((prev) => prev.map((n) => ({ ...n, isRead: true })));
    setUnread(0);
    await api.patch('/notifications/read-all').catch(() => {});
  };

  return (
    <div className="relative" ref={ref}>
      <button
        onClick={() => setOpen((v) => !v)}
        className="relative w-9 h-9 rounded-xl flex items-center justify-center text-muted hover:text-ink hover:bg-paper-dark transition-colors"
        aria-label="Уведомления"
      >
        <Bell size={18} />
        {unread > 0 && (
          <span className="absolute -top-0.5 -right-0.5 min-w-[16px] h-4 px-1 rounded-full bg-terra text-white text-[10px] font-bold flex items-center justify-center">
            {unread > 9 ? '9+' : unread}
          </span>
        )}
      </button>

      {open && (
        <div className="absolute right-0 top-11 w-80 max-h-[70vh] overflow-y-auto rounded-2xl border border-line bg-white shadow-lg z-50">
          <div className="flex items-center justify-between px-4 py-3 border-b border-line">
            <p className="text-sm font-bold text-ink">Уведомления</p>
            {items.some((n) => !n.isRead) && (
              <button onClick={markAllRead} className="text-xs text-muted hover:text-ink flex items-center gap-1">
                <CheckCheck size={13} /> Прочитать всё
              </button>
            )}
          </div>

          {loading ? (
            <div className="p-4 space-y-2">
              <div className="h-12 bg-line rounded-xl animate-pulse" />
              <div className="h-12 bg-line rounded-xl animate-pulse" />
            </div>
          ) : items.length === 0 ? (
            <p className="text-sm text-muted text-center py-10">Пока пусто</p>
          ) : (
            <div className="divide-y divide-line">
              {items.map((n) => (
                <button
                  key={n.id}
                  onClick={() => !n.isRead && markRead(n.id)}
                  className={`w-full text-left px-4 py-3 flex gap-2.5 hover:bg-paper-dark transition-colors ${n.isRead ? '' : 'bg-ochre/4'}`}
                >
                  <span className="text-lg flex-shrink-0">{ICON_BY_TYPE[n.type] ?? '🔔'}</span>
                  <div className="flex-1 min-w-0">
                    <p className={`text-sm ${n.isRead ? 'text-ink/70' : 'font-semibold text-ink'}`}>{n.title}</p>
                    {n.body && <p className="text-xs text-muted mt-0.5 line-clamp-2">{n.body}</p>}
                    <p className="text-[11px] text-muted mt-1">
                      {formatDistanceToNow(new Date(n.createdAt), { addSuffix: true, locale: ru })}
                    </p>
                  </div>
                  {!n.isRead && <Check size={13} className="text-ochre flex-shrink-0 mt-1" />}
                </button>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
}
