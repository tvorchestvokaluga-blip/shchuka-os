// Типы данных — зеркало схемы БД и API-ответов бэкенда.

export type UserRole = 'OWNER' | 'ADMIN' | 'TEACHER' | 'PARENT';

export interface AuthUser {
  userId: string;
  schoolId: string;
  role: UserRole;
  email: string;
  fullName: string;
}

/** Активная запись ребёнка — группа/программа, без вложенного student (он и так уже student). */
export interface StudentActiveEnrollment {
  id: string;
  status: string;
  group: { id: string; name: string };
  program: { id: string; name: string };
}

export interface Student {
  id: string;
  firstName: string;
  lastName: string;
  birthDate: string;
  avatarEmoji?: string;
  familyId: string;
  family?: { id: string; name: string };
  enrollments?: StudentActiveEnrollment[];
}

export interface Program {
  id: string;
  name: string;
  description?: string;
  ageFrom: number;
  ageTo: number;
  basePrice: number;
  isActive: boolean;
}

export interface Group {
  id: string;
  name: string;
  maxSize: number;
  isActive: boolean;
  program: Pick<Program, 'id' | 'name'>;
  teacher?: { user: { fullName: string } };
  scheduleSlots: ScheduleSlot[];
  _count?: { enrollments: number };
}

export interface ScheduleSlot {
  id: string;
  weekday: 'MON' | 'TUE' | 'WED' | 'THU' | 'FRI' | 'SAT' | 'SUN';
  startTime: string;
  endTime: string;
  room?: string;
}

export interface Enrollment {
  id: string;
  status: 'ACTIVE' | 'PAUSED' | 'FINISHED' | 'CANCELLED';
  startDate: string;
  endDate?: string;
  priceFrozen?: number;
  student: Pick<Student, 'id' | 'firstName' | 'lastName' | 'avatarEmoji'>;
  program: Pick<Program, 'id' | 'name'>;
  group: Pick<Group, 'id' | 'name'>;
  subscriptions?: Subscription[];
}

export interface Subscription {
  id: string;
  totalLessons: number;
  remainingLessons: number;
  status: 'ACTIVE' | 'EXHAUSTED' | 'EXPIRED' | 'CANCELLED';
  expiryDate?: string;
  payment?: Payment;
}

export interface Payment {
  id: string;
  amount: number;
  status: 'PENDING' | 'PAID' | 'OVERDUE' | 'REFUNDED' | 'CANCELLED';
  method?: string;
  paidAt?: string;
  dueDate?: string;
  subscription?: Subscription;
}

export interface Lesson {
  id: string;
  date: string;
  topic?: string;
  materials?: string;
  note?: string;
  group: Pick<Group, 'id' | 'name'>;
  _count?: { attendances: number; photos: number };
}

/** Роспись группы — ребёнок в составе группы, с датой рождения (для карточки/роста). */
export interface GroupRosterStudent extends Pick<Student, 'id' | 'firstName' | 'lastName' | 'birthDate' | 'avatarEmoji'> {}

export interface GroupDetail extends Group {
  program: Program;
  enrollments: { id: string; student: GroupRosterStudent }[];
}

export interface AttendanceRecord {
  id: string;
  status: 'PRESENT' | 'ABSENT' | 'EXCUSED' | 'MAKEUP';
  enrollment: {
    student: Pick<Student, 'id' | 'firstName' | 'lastName' | 'avatarEmoji'>;
  };
  subscription?: Pick<Subscription, 'remainingLessons' | 'totalLessons'>;
}

export interface Photo {
  id: string;
  url: string;
  caption?: string;
  createdAt: string;
  lesson?: { date: string; topic?: string };
}

export interface Comment {
  id: string;
  text: string;
  visibility: 'PARENT' | 'INTERNAL';
  aiAssisted: boolean;
  createdAt: string;
  author: { fullName: string };
  lesson?: { date: string; topic?: string };
}

/** Один урок в истории зачисления — тема и отметка посещения. */
export interface PassportLesson {
  id: string;
  date: string;
  topic?: string;
  materials?: string;
  status: 'PRESENT' | 'ABSENT' | 'EXCUSED' | 'MAKEUP';
}

/** Оплата в составе паспорта — с привязкой к программе/группе для отображения. */
export interface PassportPayment {
  id: string;
  amount: number;
  status: 'PENDING' | 'PAID' | 'OVERDUE' | 'REFUNDED' | 'CANCELLED';
  method?: string;
  paidAt?: string;
  dueDate?: string;
  totalLessons: number;
  remainingLessons: number;
  program: string;
  group: string;
}

// Паспорт художника — агрегированный ответ
export interface ArtistPassport {
  student: Pick<Student, 'id' | 'firstName' | 'lastName' | 'birthDate' | 'avatarEmoji'> & { note?: string };
  skills: { name: string; level: number }[];
  achievements: { title: string; icon?: string; awardedAt: string }[];
  artworks: { id: string; photoUrl: string; title?: string; createdAt: string }[];
  enrollments: {
    id: string;
    program: string;
    group: string;
    status: string;
    startDate: string;
    attendanceRate?: number;
    totalLessons: number;
    presentCount: number;
    lessons: PassportLesson[];
    missedTopics: PassportLesson[];
    recentComments: Comment[];
    payments: PassportPayment[];
  }[];
  timeline: (Comment & { programName: string })[];
  photos: Photo[];
  developmentPlans: DevelopmentPlan[];
  payments: PassportPayment[];
  summary: {
    programsCount: number;
    totalLessonsAttended: number;
    totalLessonsMissed: number;
    achievementsCount: number;
    artworksCount: number;
    photosCount: number;
    overdueAmount: number;
    pendingAmount: number;
    memberSince?: string;
  };
}

// ── Индивидуальный план развития ────────────────────────────────────────────

export interface DevelopmentPlan {
  id: string;
  periodLabel?: string;
  goals: string;
  focusAreas?: string;
  notes?: string;
  createdAt: string;
  updatedAt: string;
  author: { fullName: string };
}

// ── Фаза 1: новости, домашние задания, документы ────────────────────────────

export interface NewsPost {
  id: string;
  title: string;
  body: string;
  isPublished: boolean;
  publishedAt: string;
  createdAt: string;
  author: { fullName: string };
}

export interface Homework {
  id: string;
  title: string;
  description: string;
  dueDate?: string;
  attachmentUrl?: string;
  createdAt: string;
  group: Pick<Group, 'id' | 'name'>;
  lesson?: { id: string; date: string; topic?: string };
  author: { fullName: string };
}

export type SchukaDocumentType = 'CONTRACT' | 'AGREEMENT' | 'OTHER';

export interface SchukaDocument {
  id: string;
  type: SchukaDocumentType;
  title: string;
  url: string;
  createdAt: string;
  uploadedBy: { fullName: string };
  family?: { id: string; name: string };
}
// ── Фаза 2: отработка пропущенных занятий ───────────────────────────────────

export interface MakeupMyBooking {
  id: string;
  studentId: string;
  studentName: string;
}

export interface MakeupSlotParentView {
  id: string;
  date: string;
  capacity: number;
  note?: string;
  remaining: number;
  myBookings: MakeupMyBooking[];
}

export interface MakeupMissedTopic {
  date: string;
  topic: string | null;
  groupName: string;
}

export interface MakeupRosterEntry {
  bookingId: string;
  studentId: string;
  studentName: string;
  missedTopics: MakeupMissedTopic[];
}

export interface MakeupSlotStaffView {
  id: string;
  date: string;
  capacity: number;
  note?: string;
  remaining: number;
  roster: MakeupRosterEntry[];
}

// ── Уведомления (колокольчик) ───────────────────────────────────────────────

export type AppNotificationType =
  | 'PAYMENT_DUE' | 'PAYMENT_RECEIVED' | 'NEW_PHOTO' | 'NEW_COMMENT'
  | 'SUBSCRIPTION_LOW' | 'LESSON_REMINDER' | 'ACHIEVEMENT' | 'BIRTHDAY' | 'INVENTORY_LOW';

export interface AppNotification {
  id: string;
  type: AppNotificationType;
  title: string;
  body?: string;
  isRead: boolean;
  createdAt: string;
}

// ── Доска задач руководителя ────────────────────────────────────────────────

export type TaskStatus = 'TODO' | 'DONE';

export interface SchukaTask {
  id: string;
  title: string;
  note?: string;
  dueDate?: string;
  status: TaskStatus;
  completedAt?: string;
  createdAt: string;
}

// ── Инвентаризация ───────────────────────────────────────────────────────────

export interface InventoryItem {
  id: string;
  name: string;
  unit: string;
  quantity: number;
  minQuantity: number;
  note?: string;
  low: boolean;
}

// ── Сотрудники ───────────────────────────────────────────────────────────────

export interface StaffMember {
  id: string;
  fullName: string;
  email: string;
  phone?: string;
  role: 'OWNER' | 'ADMIN' | 'TEACHER';
  isActive: boolean;
  lastLoginAt?: string;
  createdAt: string;
  teacher?: { id: string; groups: { id: string; name: string }[] };
}

// ── Отчёты ────────────────────────────────────────────────────────────────────

export interface WeeklySummary {
  period: { from: string; to: string; days: number };
  lessonsHeld: number;
  attendance: { present: number; absent: number; excused: number; makeup: number; rate: number | null };
  enrollments: { new: number };
  revenue: { collected: number; pendingAmount: number; pendingCount: number; overdueAmount: number; overdueCount: number };
  activity: { newPhotos: number; newComments: number; newHomework: number };
  inventory: { lowStockCount: number; items: { id: string; name: string; quantity: number; unit: string }[] };
  tasks: { open: number };
  birthdays: { id: string; name: string; birthDate: string }[];
}

export type AttentionAlertType = 'ATTENDANCE' | 'NO_FEEDBACK';
export type AttentionSeverity = 'high' | 'medium' | 'low';

export interface AttentionAlert {
  studentId: string;
  name: string;
  groupName: string;
  type: AttentionAlertType;
  severity: AttentionSeverity;
  detail: string;
}
