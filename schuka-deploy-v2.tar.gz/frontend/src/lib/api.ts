// lib/api.ts — единая точка обращения к бэкенду.
// Все запросы идут через этот клиент: он добавляет токен и
// обрабатывает 401 (редирект на логин).
import axios from 'axios';

export const api = axios.create({
  baseURL: process.env.NEXT_PUBLIC_API_URL || 'http://localhost:4000/api',
  timeout: 10_000,
});

// добавляем токен к каждому запросу
api.interceptors.request.use((config) => {
  if (typeof window !== 'undefined') {
    const token = localStorage.getItem('schuka_token');
    if (token) config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

// при 401 — очищаем токен и уходим на логин
api.interceptors.response.use(
  (r) => r,
  (err) => {
    if (err.response?.status === 401 && typeof window !== 'undefined') {
      localStorage.removeItem('schuka_token');
      localStorage.removeItem('schuka_user');
      window.location.href = '/login';
    }
    return Promise.reject(err);
  },
);

// ── утилиты ──────────────────────────────────────────────────────────────
export function getToken() {
  if (typeof window === 'undefined') return null;
  return localStorage.getItem('schuka_token');
}
export function setToken(token: string) {
  localStorage.setItem('schuka_token', token);
}
export function clearAuth() {
  localStorage.removeItem('schuka_token');
  localStorage.removeItem('schuka_user');
}

// Превращает относительный путь файла (например "/uploads/photos/.../x.jpg",
// который отдаёт наше API) в полный URL — на случай локального/тестового
// хранения фото на сервере. Полные http(s)-ссылки (будущее облако) не трогает.
export function resolveFileUrl(url: string | null | undefined): string {
  if (!url) return '';
  if (/^https?:\/\//i.test(url)) return url;
  const apiBase = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:4000/api';
  const origin = apiBase.replace(/\/api\/?$/, '');
  return `${origin}${url.startsWith('/') ? '' : '/'}${url}`;
}
