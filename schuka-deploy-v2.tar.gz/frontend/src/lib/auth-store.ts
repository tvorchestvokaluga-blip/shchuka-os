﻿// store/auth.ts — глобальное состояние авторизации (Zustand).
import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import type { AuthUser } from '../types';
import { api, setToken, clearAuth } from '@/lib/api';

interface AuthState {
  user: AuthUser | null;
  isLoading: boolean;
  login: (email: string, password: string) => Promise<void>;
  logout: () => void;
}

export const useAuthStore = create<AuthState>()(
  persist(
    (set) => ({
      user: null,
      isLoading: false,

      login: async (email, password) => {
        set({ isLoading: true });
        try {
          const { data } = await api.post('/auth/login', { email, password });
          setToken(data.accessToken);
          set({ user: { ...data.user, email } });
        } finally {
          set({ isLoading: false });
        }
      },

      logout: () => {
        clearAuth();
        set({ user: null });
        window.location.href = '/login';
      },
    }),
    {
      name: 'schuka_user',
      // сохраняем только user, токен хранится в localStorage отдельно
      partialize: (state) => ({ user: state.user }),
    },
  ),
);
