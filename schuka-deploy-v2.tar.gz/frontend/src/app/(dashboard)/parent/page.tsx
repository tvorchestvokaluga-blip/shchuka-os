'use client';
// Кабинет родителя — главная страница.
// Показывает детей, ближайшее занятие, остаток абонемента, последнее фото.
import { useEffect, useState } from 'react';
import Link from 'next/link';
import { Calendar, CreditCard, Image, ChevronRight, Award, Baby } from 'lucide-react';
import { api } from '@/lib/api';
import { useAuthStore } from '@/lib/auth-store';
import type { Enrollment, Payment } from '../../../types';
import { format } from 'date-fns';
import { ru } from 'date-fns/locale';

const WEEKDAY_RU: Record<string, string> = {
  MON: 'Пн', TUE: 'Вт', WED: 'Ср', THU: 'Чт', FRI: 'Пт', SAT: 'Сб', SUN: 'Вс',
};

export default function ParentHome() {
  const { user } = useAuthStore();
  const [enrollments, setEnrollments] = useState<Enrollment[]>([]);
  const [payments, setPayments] = useState<Payment[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    Promise.all([
      api.get('/enrollments').then((r) => setEnrollments(r.data)),
      api.get('/payments').then((r) => setPayments(r.data)),
    ]).finally(() => setLoading(false));
  }, []);

  const pendingPayments = payments.filter((p) => p.status === 'PENDING' || p.status === 'OVERDUE');

  if (loading) return <PageSkeleton />;

  return (
    <div className="space-y-6">
      {/* приветствие */}
      <div>
        <p className="text-sm text-muted">Добрый день,</p>
        <h1 className="text-2xl font-extrabold text-ink tracking-tight">
          {user?.fullName?.split(' ')[0]} 👋
        </h1>
      </div>

      {/* предупреждение о задолженности */}
      {pendingPayments.length > 0 && (
        <div className="rounded-2xl bg-terra/8 border border-terra/20 px-4 py-3.5 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <CreditCard size={18} className="text-terra" />
            <div>
              <p className="text-sm font-semibold text-ink">
                Ожидается оплата
              </p>
              <p className="text-xs text-muted">
                {pendingPayments.length} {pendingPayments.length === 1 ? 'платёж' : 'платежа'}
              </p>
            </div>
          </div>
          <Link href="/parent/payments" className="text-xs font-semibold text-terra hover:underline">
            Подробнее →
          </Link>
        </div>
      )}

      {/* карточки детей */}
      {enrollments.length === 0 ? (
        <div className="card text-center py-10 text-muted">
          <Baby size={36} className="mx-auto mb-3 opacity-30" />
          <p className="text-sm">Зачислений не найдено</p>
        </div>
      ) : (
        <div className="space-y-4">
          {enrollments.map((enr) => (
            <StudentCard key={enr.id} enrollment={enr} />
          ))}
        </div>
      )}
    </div>
  );
}

function StudentCard({ enrollment }: { enrollment: Enrollment }) {
  const sub = enrollment.subscriptions?.[0];
  const remaining = sub?.remainingLessons ?? 0;
  const total = sub?.totalLessons ?? 0;

  return (
    <div className="card space-y-4">
      {/* заголовок */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-11 h-11 rounded-2xl bg-paper-dark flex items-center justify-center text-xl flex-shrink-0">
            {enrollment.student.avatarEmoji ?? '🎨'}
          </div>
          <div>
            <p className="font-bold text-ink">
              {enrollment.student.firstName} {enrollment.student.lastName}
            </p>
            <p className="text-xs text-muted">{enrollment.program.name} · {enrollment.group.name}</p>
          </div>
        </div>
        <Link
          href={`/parent/passport?studentId=${enrollment.student.id}`}
          className="flex items-center gap-1 text-xs font-semibold text-ochre hover:text-ochre-dark"
        >
          <Award size={13} />
          Паспорт
        </Link>
      </div>

      {/* абонемент */}
      {sub && (
        <div>
          <div className="flex justify-between text-xs text-muted mb-1.5">
            <span>Абонемент: занятий</span>
            <span className="font-semibold text-ink">{remaining} / {total}</span>
          </div>
          <div className="skill-bar">
            <div
              className="skill-fill"
              style={{ width: `${total > 0 ? (remaining / total) * 100 : 0}%` }}
            />
          </div>
          {remaining <= 2 && remaining > 0 && (
            <p className="text-xs text-terra mt-1.5 font-medium">
              Осталось мало занятий — пора продлить абонемент
            </p>
          )}
        </div>
      )}

      {/* быстрые ссылки */}
      <div className="grid grid-cols-3 gap-2">
        {[
          { href: `/parent/photos?studentId=${enrollment.student.id}`, icon: Image, label: 'Фото' },
          { href: `/parent/payments`, icon: CreditCard, label: 'Оплаты' },
          { href: `/parent/schedule`, icon: Calendar, label: 'Расписание' },
        ].map(({ href, icon: Icon, label }) => (
          <Link
            key={label}
            href={href}
            className="flex flex-col items-center gap-1.5 py-3 rounded-xl bg-paper-dark
                       hover:bg-line transition-colors text-muted hover:text-ink"
          >
            <Icon size={18} />
            <span className="text-xs font-medium">{label}</span>
          </Link>
        ))}
      </div>
    </div>
  );
}

function PageSkeleton() {
  return (
    <div className="space-y-6 animate-pulse">
      <div className="h-8 w-48 bg-line rounded-xl" />
      <div className="card h-48 bg-line border-0" />
    </div>
  );
}
