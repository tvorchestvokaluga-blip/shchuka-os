'use client';
// Кабинет родителя — оплаты.
// Список платежей ребёнка/детей со статусами + видимость оплаченных занятий.
import { useEffect, useState } from 'react';
import { CreditCard, CheckCircle2 } from 'lucide-react';
import { api } from '@/lib/api';
import type { Payment } from '@/types';

const STATUS_MAP: Record<string, { label: string; cls: string }> = {
  PAID: { label: 'Оплачено', cls: 'badge-success' },
  PENDING: { label: 'Ожидается', cls: 'badge-warning' },
  OVERDUE: { label: 'Просрочено', cls: 'badge-danger' },
  REFUNDED: { label: 'Возврат', cls: 'badge-neutral' },
  CANCELLED: { label: 'Отменено', cls: 'badge-neutral' },
};

const FILTERS = [
  { key: 'ALL', label: 'Все' },
  { key: 'PENDING', label: 'Ожидается' },
  { key: 'OVERDUE', label: 'Просрочено' },
  { key: 'PAID', label: 'Оплачено' },
];

export default function ParentPayments() {
  const [payments, setPayments] = useState<Payment[]>([]);
  const [filter, setFilter] = useState('ALL');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api.get('/payments').then((r) => setPayments(r.data)).finally(() => setLoading(false));
  }, []);

  const filtered = filter === 'ALL' ? payments : payments.filter((p) => p.status === filter);
  const totalDue = payments
    .filter((p) => p.status === 'PENDING' || p.status === 'OVERDUE')
    .reduce((s, p) => s + Number(p.amount), 0);

  // оплаченные абонементы — сколько занятий оплачено и сколько уже использовано
  const paidSubs = payments
    .filter((p) => p.status === 'PAID' && p.subscription)
    .map((p) => p.subscription as any);

  if (loading) return <PageSkeleton />;

  return (
    <div className="space-y-6">
      <div>
        <p className="text-sm text-muted">Финансы</p>
        <h1 className="text-2xl font-extrabold text-ink tracking-tight">Оплаты</h1>
      </div>

      {totalDue > 0 && (
        <div className="rounded-2xl bg-terra/8 border border-terra/20 px-4 py-3.5 flex items-center gap-3">
          <CreditCard size={18} className="text-terra flex-shrink-0" />
          <div>
            <p className="text-sm font-semibold text-ink">К оплате: {totalDue.toLocaleString('ru-RU')} ₽</p>
            <p className="text-xs text-muted">Свяжитесь со школой для оплаты</p>
          </div>
          <button className="btn-primary ml-auto flex-shrink-0" onClick={() => alert('Онлайн-оплата подключается — пока свяжитесь со школой.')}>
            Оплатить
          </button>
        </div>
      )}

      {paidSubs.length > 0 && (
        <div className="card space-y-3">
          <p className="section-title mb-0 flex items-center gap-1.5">
            <CheckCircle2 size={13} className="text-sage" /> Оплаченные занятия
          </p>
          {paidSubs.map((sub, i) => {
            const total = sub.totalLessons ?? 0;
            const remaining = sub.remainingLessons ?? 0;
            const used = Math.max(total - remaining, 0);
            return (
              <div key={sub.id ?? i}>
                <div className="flex justify-between text-xs text-muted mb-1.5">
                  <span>Использовано занятий</span>
                  <span className="font-semibold text-ink">{used} / {total}</span>
                </div>
                <div className="skill-bar">
                  <div className="skill-fill" style={{ width: `${total > 0 ? (used / total) * 100 : 0}%` }} />
                </div>
              </div>
            );
          })}
        </div>
      )}

      <div className="flex gap-2 overflow-x-auto pb-1">
        {FILTERS.map((f) => (
          <button
            key={f.key}
            onClick={() => setFilter(f.key)}
            className={`flex-shrink-0 px-3.5 py-1.5 rounded-lg text-xs font-semibold border transition-all
              ${filter === f.key
                ? 'bg-ink text-white border-ink'
                : 'bg-white text-muted border-line hover:border-ink/20 hover:text-ink'
              }`}
          >
            {f.label}
          </button>
        ))}
      </div>

      {filtered.length === 0 ? (
        <div className="card text-center py-14 text-muted">
          <CreditCard size={36} className="mx-auto mb-3 opacity-30" />
          <p className="text-sm">Платежей не найдено</p>
        </div>
      ) : (
        <div className="card divide-y divide-line p-0">
          {filtered.map((p) => {
            const st = STATUS_MAP[p.status] ?? STATUS_MAP.PENDING;
            const sub: any = p.subscription;
            return (
              <div key={p.id} className="flex items-center gap-3 px-5 py-4">
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-semibold text-ink truncate">
                    {sub?.enrollment?.student
                      ? `${sub.enrollment.student.firstName} ${sub.enrollment.student.lastName}`
                      : 'Абонемент'}
                  </p>
                  <p className="text-xs text-muted">
                    {sub?.enrollment?.group?.name ?? sub?.enrollment?.program?.name ?? ''}
                    {sub?.totalLessons != null && ` · ${sub.totalLessons} занятий`}
                    {p.dueDate && ` · до ${new Date(p.dueDate).toLocaleDateString('ru-RU')}`}
                    {p.paidAt && ` · оплачено ${new Date(p.paidAt).toLocaleDateString('ru-RU')}`}
                  </p>
                </div>
                <p className="text-sm font-bold text-ink flex-shrink-0">
                  {Number(p.amount).toLocaleString('ru-RU')} ₽
                </p>
                <span className={`badge ${st.cls} flex-shrink-0`}>{st.label}</span>
                {(p.status === 'PENDING' || p.status === 'OVERDUE') && (
                  <button className="btn-secondary text-xs py-1.5 px-3 flex-shrink-0"
                    onClick={() => alert('Онлайн-оплата подключается — пока свяжитесь со школой.')}>
                    Оплатить
                  </button>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

function PageSkeleton() {
  return (
    <div className="space-y-6 animate-pulse">
      <div className="h-8 w-40 bg-line rounded-xl" />
      <div className="card h-64 bg-line border-0" />
    </div>
  );
}
