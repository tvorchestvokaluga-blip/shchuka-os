'use client';
// Кабинет родителя — домашние задания по группам, где занимаются дети.
import { useEffect, useState } from 'react';
import { ClipboardList, Paperclip } from 'lucide-react';
import { api } from '@/lib/api';
import type { Homework } from '@/types';

export default function ParentHomework() {
  const [items, setItems] = useState<Homework[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api.get('/homework').then((r) => setItems(r.data)).finally(() => setLoading(false));
  }, []);

  if (loading) return <PageSkeleton />;

  return (
    <div className="space-y-6">
      <div>
        <p className="text-sm text-muted">Учёба</p>
        <h1 className="text-2xl font-extrabold text-ink tracking-tight">Домашнее задание</h1>
      </div>

      {items.length === 0 ? (
        <div className="card text-center py-14 text-muted">
          <ClipboardList size={36} className="mx-auto mb-3 opacity-30" />
          <p className="text-sm">Домашних заданий пока нет</p>
        </div>
      ) : (
        <div className="space-y-4">
          {items.map((hw) => {
            const overdue = hw.dueDate && new Date(hw.dueDate) < new Date();
            return (
              <div key={hw.id} className="card space-y-2">
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <p className="text-xs font-semibold text-ochre">{hw.group.name}</p>
                    <h2 className="font-bold text-ink text-lg">{hw.title}</h2>
                  </div>
                  {hw.dueDate && (
                    <span className={`badge flex-shrink-0 ${overdue ? 'badge-danger' : 'badge-warning'}`}>
                      до {new Date(hw.dueDate).toLocaleDateString('ru-RU', { day: 'numeric', month: 'short' })}
                    </span>
                  )}
                </div>
                <p className="text-sm text-ink/80 whitespace-pre-wrap leading-relaxed">{hw.description}</p>
                {hw.attachmentUrl && (
                  <a
                    href={hw.attachmentUrl}
                    target="_blank"
                    rel="noreferrer"
                    className="inline-flex items-center gap-1.5 text-xs font-semibold text-ochre hover:text-ochre-dark"
                  >
                    <Paperclip size={13} />
                    Материалы к заданию
                  </a>
                )}
                <p className="text-xs text-muted pt-1">— {hw.author.fullName}</p>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

function PageSkeleton() {
  return (
    <div className="space-y-6 animate-pulse">
      <div className="h-8 w-56 bg-line rounded-xl" />
      <div className="card h-32 bg-line border-0" />
      <div className="card h-32 bg-line border-0" />
    </div>
  );
}
