'use client';
// Кабинет родителя — фото с занятий.
// Показывает фотографии по каждому ребёнку, с переключателем между детьми.
import { useEffect, useState } from 'react';
import { useSearchParams } from 'next/navigation';
import { Image as ImageIcon } from 'lucide-react';
import { api, resolveFileUrl } from '@/lib/api';
import type { Enrollment, Photo } from '@/types';

export default function ParentPhotos() {
  const searchParams = useSearchParams();
  const initialStudentId = searchParams.get('studentId') ?? '';

  const [enrollments, setEnrollments] = useState<Enrollment[]>([]);
  const [studentId, setStudentId] = useState(initialStudentId);
  const [photos, setPhotos] = useState<Photo[]>([]);
  const [loadingChildren, setLoadingChildren] = useState(true);
  const [loadingPhotos, setLoadingPhotos] = useState(false);

  // список детей родителя
  useEffect(() => {
    api.get('/enrollments').then((r) => {
      const data: Enrollment[] = r.data;
      setEnrollments(data);
      if (!initialStudentId && data.length > 0) {
        setStudentId(data[0].student.id);
      }
    }).finally(() => setLoadingChildren(false));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // уникальные дети (может быть несколько зачислений на одного ребёнка)
  const children = Array.from(
    new Map(enrollments.map((e) => [e.student.id, e.student])).values(),
  );

  useEffect(() => {
    if (!studentId) return;
    setLoadingPhotos(true);
    api.get(`/students/${studentId}/photos`)
      .then((r) => setPhotos(r.data))
      .finally(() => setLoadingPhotos(false));
  }, [studentId]);

  if (loadingChildren) return <PageSkeleton />;

  return (
    <div className="space-y-6">
      <div>
        <p className="text-sm text-muted">Архив занятий</p>
        <h1 className="text-2xl font-extrabold text-ink tracking-tight">Фото с занятий</h1>
      </div>

      {children.length > 1 && (
        <div className="flex gap-2 overflow-x-auto pb-1">
          {children.map((c) => (
            <button
              key={c.id}
              onClick={() => setStudentId(c.id)}
              className={`flex-shrink-0 flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-semibold border transition-all
                ${studentId === c.id
                  ? 'bg-ink text-white border-ink'
                  : 'bg-white text-muted border-line hover:border-ink/20 hover:text-ink'
                }`}
            >
              <span>{c.avatarEmoji ?? '🎨'}</span>
              {c.firstName}
            </button>
          ))}
        </div>
      )}

      {loadingPhotos ? (
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
          {[0, 1, 2, 3, 4, 5].map((i) => (
            <div key={i} className="aspect-square rounded-2xl bg-line animate-pulse" />
          ))}
        </div>
      ) : photos.length === 0 ? (
        <div className="card text-center py-14 text-muted">
          <ImageIcon size={36} className="mx-auto mb-3 opacity-30" />
          <p className="text-sm">Фото пока нет</p>
        </div>
      ) : (
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
          {photos.map((p) => (
            <PhotoCard key={p.id} photo={p} />
          ))}
        </div>
      )}
    </div>
  );
}

function PhotoCard({ photo }: { photo: Photo }) {
  const [broken, setBroken] = useState(false);
  const date = photo.lesson?.date ?? photo.createdAt;

  return (
    <div className="rounded-2xl overflow-hidden border border-line bg-white group">
      <div className="aspect-square bg-paper-dark flex items-center justify-center overflow-hidden">
        {!broken ? (
          <img
            src={resolveFileUrl(photo.url)}
            alt={photo.caption ?? 'Фото с занятия'}
            className="w-full h-full object-cover transition-transform duration-200 group-hover:scale-105"
            onError={() => setBroken(true)}
          />
        ) : (
          <ImageIcon size={28} className="text-muted opacity-40" />
        )}
      </div>
      <div className="px-3 py-2">
        {photo.caption && <p className="text-xs font-medium text-ink truncate">{photo.caption}</p>}
        <p className="text-xs text-muted">
          {new Date(date).toLocaleDateString('ru-RU', { day: 'numeric', month: 'long' })}
        </p>
      </div>
    </div>
  );
}

function PageSkeleton() {
  return (
    <div className="space-y-6 animate-pulse">
      <div className="h-8 w-48 bg-line rounded-xl" />
      <div className="grid grid-cols-3 gap-3">
        {[0, 1, 2].map((i) => <div key={i} className="aspect-square rounded-2xl bg-line" />)}
      </div>
    </div>
  );
}
