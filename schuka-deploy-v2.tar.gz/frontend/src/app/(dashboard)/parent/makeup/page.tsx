'use client';
// Кабинет родителя — отработка пропущенных занятий.
// Общие слоты на всю школу (обычно 2 в месяц, 8 мест), запись по предзаписи.
// Родитель просто бронирует место — какие темы пропущены, решает педагог.
import { useEffect, useState } from 'react';
import { CalendarClock, Check, X } from 'lucide-react';
import { api } from '@/lib/api';
import type { MakeupSlotParentView, Student } from '@/types';

export default function ParentMakeup() {
  const [slots, setSlots] = useState<MakeupSlotParentView[]>([]);
  const [children, setChildren] = useState<Student[]>([]);
  const [loading, setLoading] = useState(true);
  const [busySlot, setBusySlot] = useState<string | null>(null);
  const [error, setError] = useState('');

  const load = () => {
    Promise.all([api.get('/makeup/slots'), api.get('/students')])
      .then(([slotsRes, studentsRes]) => {
        setSlots(slotsRes.data);
        setChildren(studentsRes.data);
      })
      .finally(() => setLoading(false));
  };

  useEffect(load, []);

  const book = async (slotId: string, studentId: string) => {
    setError('');
    setBusySlot(slotId);
    try {
      await api.post(`/makeup/slots/${slotId}/book`, { studentId });
      load();
    } catch (e: any) {
      setError(e?.response?.data?.message ?? 'Не удалось записаться');
    } finally {
      setBusySlot(null);
    }
  };

  const cancel = async (bookingId: string, slotId: string) => {
    setError('');
    setBusySlot(slotId);
    try {
      await api.delete(`/makeup/bookings/${bookingId}`);
      load();
    } catch (e: any) {
      setError(e?.response?.data?.message ?? 'Не удалось отменить запись');
    } finally {
      setBusySlot(null);
    }
  };

  if (loading) return <PageSkeleton />;

  return (
    <div className="space-y-6">
      <div>
        <p className="text-sm text-muted">Расписание</p>
        <h1 className="text-2xl font-extrabold text-ink tracking-tight">Отработка пропущенных занятий</h1>
        <p className="text-sm text-muted mt-1">
          Дополнительные занятия вне расписания — возможность отработать пропущенные темы.
        </p>
      </div>

      {error && (
        <div className="rounded-xl bg-terra/8 border border-terra/20 px-3.5 py-2.5 text-sm text-terra font-medium">
          {error}
        </div>
      )}

      {slots.length === 0 ? (
        <div className="card text-center py-14 text-muted">
          <CalendarClock size={36} className="mx-auto mb-3 opacity-30" />
          <p className="text-sm">Ближайших слотов отработки пока нет — следите за новостями школы</p>
        </div>
      ) : (
        <div className="space-y-4">
          {slots.map((slot) => (
            <SlotCard
              key={slot.id}
              slot={slot}
              children={children}
              busy={busySlot === slot.id}
              onBook={(studentId) => book(slot.id, studentId)}
              onCancel={(bookingId) => cancel(bookingId, slot.id)}
            />
          ))}
        </div>
      )}
    </div>
  );
}

function SlotCard({
  slot, children, busy, onBook, onCancel,
}: {
  slot: MakeupSlotParentView;
  children: Student[];
  busy: boolean;
  onBook: (studentId: string) => void;
  onCancel: (bookingId: string) => void;
}) {
  const [selectedChild, setSelectedChild] = useState(children[0]?.id ?? '');
  const bookedIds = new Set(slot.myBookings.map((b) => b.studentId));
  const bookableChildren = children.filter((c) => !bookedIds.has(c.id));
  const dateStr = new Date(slot.date).toLocaleString('ru-RU', {
    day: 'numeric', month: 'long', hour: '2-digit', minute: '2-digit',
  });

  return (
    <div className="card space-y-3">
      <div className="flex items-start justify-between gap-3">
        <div>
          <p className="font-bold text-ink text-lg">{dateStr}</p>
          {slot.note && <p className="text-sm text-muted">{slot.note}</p>}
        </div>
        <span className={`badge flex-shrink-0 ${slot.remaining > 0 ? 'badge-success' : 'badge-neutral'}`}>
          {slot.remaining > 0 ? `Свободно мест: ${slot.remaining} из ${slot.capacity}` : 'Мест нет'}
        </span>
      </div>

      {slot.myBookings.length > 0 && (
        <div className="space-y-1.5">
          {slot.myBookings.map((b) => (
            <div key={b.id} className="flex items-center justify-between rounded-lg bg-sage/8 px-3 py-2">
              <span className="text-sm font-semibold text-ink flex items-center gap-1.5">
                <Check size={14} className="text-sage" /> {b.studentName} записан(а)
              </span>
              <button
                onClick={() => onCancel(b.id)}
                disabled={busy}
                className="text-xs font-semibold text-terra hover:text-terra-dark flex items-center gap-1"
              >
                <X size={13} /> Отменить
              </button>
            </div>
          ))}
        </div>
      )}

      {slot.remaining > 0 && bookableChildren.length > 0 && (
        <div className="flex items-center gap-2 pt-1">
          {bookableChildren.length > 1 && (
            <select
              className="input flex-1"
              value={selectedChild}
              onChange={(e) => setSelectedChild(e.target.value)}
            >
              {bookableChildren.map((c) => (
                <option key={c.id} value={c.id}>{c.firstName} {c.lastName}</option>
              ))}
            </select>
          )}
          <button
            className="btn-primary flex-shrink-0"
            disabled={busy}
            onClick={() => onBook(selectedChild || bookableChildren[0].id)}
          >
            Записаться{bookableChildren.length === 1 ? ` — ${bookableChildren[0].firstName}` : ''}
          </button>
        </div>
      )}
    </div>
  );
}

function PageSkeleton() {
  return (
    <div className="space-y-6 animate-pulse">
      <div className="h-8 w-72 bg-line rounded-xl" />
      <div className="card h-28 bg-line border-0" />
      <div className="card h-28 bg-line border-0" />
    </div>
  );
}
