'use client';
// Кабинет родителя — расписание занятий детей.
import { useEffect, useState } from 'react';
import { Calendar, MapPin } from 'lucide-react';
import { api } from '@/lib/api';
import type { Enrollment, Group } from '@/types';

const WEEKDAYS = [
  { key: 'MON', label: 'Понедельник' },
  { key: 'TUE', label: 'Вторник' },
  { key: 'WED', label: 'Среда' },
  { key: 'THU', label: 'Четверг' },
  { key: 'FRI', label: 'Пятница' },
  { key: 'SAT', label: 'Суббота' },
  { key: 'SUN', label: 'Воскресенье' },
];

export default function ParentSchedule() {
  const [enrollments, setEnrollments] = useState<Enrollment[]>([]);
  const [groups, setGroups] = useState<Group[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    Promise.all([
      api.get('/enrollments').then((r) => setEnrollments(r.data)),
      api.get('/groups').then((r) => setGroups(r.data)).catch(() => setGroups([])),
    ]).finally(() => setLoading(false));
  }, []);

  if (loading) return <PageSkeleton />;

  const groupIds = new Set(enrollments.map((e) => e.group.id));
  const relevantGroups = groups.filter((g) => groupIds.has(g.id));
  // если /groups не отдал полные объекты (например, роль ограничена) — fallback на данные зачислений
  const source = relevantGroups.length > 0 ? relevantGroups : [];

  const byDay: Record<string, { groupName: string; studentName: string; startTime: string; endTime: string; room?: string }[]> = {};
  WEEKDAYS.forEach((d) => (byDay[d.key] = []));

  source.forEach((g) => {
    const enr = enrollments.filter((e) => e.group.id === g.id);
    (g.scheduleSlots ?? []).forEach((slot) => {
      enr.forEach((e) => {
        byDay[slot.weekday]?.push({
          groupName: g.name,
          studentName: e.student.firstName,
          startTime: slot.startTime,
          endTime: slot.endTime,
          room: slot.room,
        });
      });
    });
  });

  const hasAny = Object.values(byDay).some((d) => d.length > 0);

  return (
    <div className="space-y-6">
      <div>
        <p className="text-sm text-muted">Занятия детей</p>
        <h1 className="text-2xl font-extrabold text-ink tracking-tight">Расписание</h1>
      </div>

      {!hasAny ? (
        <div className="card text-center py-14 text-muted">
          <Calendar size={36} className="mx-auto mb-3 opacity-30" />
          <p className="text-sm">Расписание пока не сформировано</p>
        </div>
      ) : (
        <div className="space-y-4">
          {WEEKDAYS.filter((d) => byDay[d.key].length > 0).map((d) => (
            <div key={d.key} className="card">
              <h2 className="font-bold text-ink mb-3">{d.label}</h2>
              <div className="space-y-2">
                {byDay[d.key]
                  .sort((a, b) => a.startTime.localeCompare(b.startTime))
                  .map((item, i) => (
                    <div key={i} className="flex items-center gap-3 p-3 rounded-xl bg-paper-dark">
                      <div className="w-16 flex-shrink-0 text-sm font-bold text-ochre">
                        {item.startTime}
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-semibold text-ink">{item.groupName}</p>
                        <p className="text-xs text-muted">{item.studentName}</p>
                      </div>
                      {item.room && (
                        <div className="flex items-center gap-1 text-xs text-muted flex-shrink-0">
                          <MapPin size={12} />
                          {item.room}
                        </div>
                      )}
                    </div>
                  ))}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

function PageSkeleton() {
  return (
    <div className="space-y-6 animate-pulse">
      <div className="h-8 w-40 bg-line rounded-xl" />
      <div className="card h-24 bg-line border-0" />
      <div className="card h-24 bg-line border-0" />
    </div>
  );
}
