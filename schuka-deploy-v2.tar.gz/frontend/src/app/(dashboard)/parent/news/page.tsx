'use client';
// Кабинет родителя — новости школы.
import { useEffect, useState } from 'react';
import { Newspaper } from 'lucide-react';
import { api } from '@/lib/api';
import type { NewsPost } from '@/types';

export default function ParentNews() {
  const [posts, setPosts] = useState<NewsPost[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api.get('/news').then((r) => setPosts(r.data)).finally(() => setLoading(false));
  }, []);

  if (loading) return <PageSkeleton />;

  return (
    <div className="space-y-6">
      <div>
        <p className="text-sm text-muted">Школа «Щука»</p>
        <h1 className="text-2xl font-extrabold text-ink tracking-tight">Новости школы</h1>
      </div>

      {posts.length === 0 ? (
        <div className="card text-center py-14 text-muted">
          <Newspaper size={36} className="mx-auto mb-3 opacity-30" />
          <p className="text-sm">Новостей пока нет</p>
        </div>
      ) : (
        <div className="space-y-4">
          {posts.map((post) => (
            <div key={post.id} className="card space-y-2">
              <div className="flex items-start justify-between gap-3">
                <h2 className="font-bold text-ink text-lg">{post.title}</h2>
                <span className="text-xs text-muted flex-shrink-0 whitespace-nowrap">
                  {new Date(post.publishedAt).toLocaleDateString('ru-RU', { day: 'numeric', month: 'long' })}
                </span>
              </div>
              <p className="text-sm text-ink/80 whitespace-pre-wrap leading-relaxed">{post.body}</p>
              <p className="text-xs text-muted pt-1">— {post.author.fullName}</p>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

function PageSkeleton() {
  return (
    <div className="space-y-6 animate-pulse">
      <div className="h-8 w-48 bg-line rounded-xl" />
      <div className="card h-40 bg-line border-0" />
      <div className="card h-40 bg-line border-0" />
    </div>
  );
}
