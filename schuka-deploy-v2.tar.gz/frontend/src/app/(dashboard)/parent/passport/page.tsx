﻿'use client';
// Паспорт художника — главная ценность для родителя.
// Один экран, который хочется открывать и показывать.
import { useEffect, useState } from 'react';
import { useSearchParams } from 'next/navigation';
import { Award, Image, Star, TrendingUp, Calendar, MessageSquare, Target } from 'lucide-react';
import { api, resolveFileUrl } from '@/lib/api';
import type { ArtistPassport } from '../../../types';
import { format } from 'date-fns';
import { ru } from 'date-fns/locale';

export default function PassportPage() {
  const params = useSearchParams();
  const studentId = params.get('studentId');
  const [passport, setPassport] = useState<ArtistPassport | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!studentId) return;
    api.get(`/students/${studentId}/passport`)
      .then((r) => setPassport(r.data))
      .finally(() => setLoading(false));
  }, [studentId]);

  if (loading) return <div className="animate-pulse space-y-4"><div className="h-48 card bg-line border-0" /></div>;
  if (!passport) return <div className="card text-center py-10 text-muted">Ученик не найден</div>;

  const { student, skills, achievements, summary, timeline, photos, developmentPlans } = passport;

  return (
    <div className="space-y-6">
      {/* шапка паспорта */}
      <div className="card bg-ink text-white border-0">
        <div className="flex items-start gap-4">
          <div className="w-16 h-16 rounded-2xl bg-white/10 flex items-center justify-center text-3xl flex-shrink-0">
            {student.avatarEmoji ?? '🎨'}
          </div>
          <div className="flex-1 min-w-0">
            <h1 className="text-xl font-extrabold tracking-tight">
              {student.firstName} {student.lastName}
            </h1>
            {summary.memberSince && (
              <p className="text-sm text-white/50 mt-0.5">
                В школе с {format(new Date(summary.memberSince), 'LLLL yyyy', { locale: ru })}
              </p>
            )}
            {/* сводка */}
            <div className="flex gap-4 mt-3 flex-wrap">
              {[
                { v: summary.totalLessonsAttended, l: 'занятий' },
                { v: summary.achievementsCount, l: 'достижений' },
                { v: summary.artworksCount, l: 'работ' },
              ].map(({ v, l }) => (
                <div key={l}>
                  <span className="text-lg font-extrabold text-ochre">{v}</span>
                  <span className="text-xs text-white/50 ml-1">{l}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* навыки */}
      {skills.length > 0 && (
        <div className="card">
          <div className="flex items-center gap-2 mb-4">
            <TrendingUp size={16} className="text-ochre" />
            <h2 className="font-bold text-ink">Навыки</h2>
          </div>
          <div className="space-y-3">
            {skills.map((s) => (
              <div key={s.name}>
                <div className="flex justify-between text-sm mb-1.5">
                  <span className="font-medium text-ink">{s.name}</span>
                  <span className="text-muted text-xs">{s.level} / 5</span>
                </div>
                <div className="skill-bar">
                  <div className="skill-fill" style={{ width: `${(s.level / 5) * 100}%` }} />
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* план развития */}
      {developmentPlans.length > 0 && (
        <div className="card">
          <div className="flex items-center gap-2 mb-4">
            <Target size={16} className="text-ochre" />
            <h2 className="font-bold text-ink">План развития</h2>
          </div>
          <div className="p-3 rounded-xl bg-paper-dark">
            <div className="flex items-center justify-between gap-2 flex-wrap">
              <span className="text-xs font-semibold text-muted uppercase tracking-wide">
                {developmentPlans[0].periodLabel ?? 'Текущий план'}
              </span>
              <span className="text-xs text-muted">
                {format(new Date(developmentPlans[0].createdAt), 'd MMM yyyy', { locale: ru })}
              </span>
            </div>
            <p className="text-sm text-ink mt-1.5 leading-relaxed">{developmentPlans[0].goals}</p>
            {developmentPlans[0].focusAreas && (
              <p className="text-xs text-muted mt-1"><b>Акцент:</b> {developmentPlans[0].focusAreas}</p>
            )}
          </div>
        </div>
      )}

      {/* достижения */}
      {achievements.length > 0 && (
        <div className="card">
          <div className="flex items-center gap-2 mb-4">
            <Award size={16} className="text-ochre" />
            <h2 className="font-bold text-ink">Достижения</h2>
          </div>
          <div className="flex flex-wrap gap-2">
            {achievements.map((a) => (
              <div
                key={a.title}
                className="flex items-center gap-2 px-3 py-2 rounded-xl bg-paper-dark border border-line"
              >
                <span className="text-lg">{a.icon ?? '🏅'}</span>
                <span className="text-sm font-semibold text-ink">{a.title}</span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* фотогалерея */}
      {photos.length > 0 && (
        <div className="card">
          <div className="flex items-center gap-2 mb-4">
            <Image size={16} className="text-ochre" />
            <h2 className="font-bold text-ink">Работы и фото</h2>
          </div>
          <div className="grid grid-cols-3 gap-2">
            {photos.slice(0, 9).map((photo) => (
              <div
                key={photo.id}
                className="aspect-square rounded-xl overflow-hidden bg-paper-dark border border-line
                           flex items-center justify-center"
              >
                {photo.url.startsWith('seed/') || photo.url.startsWith('__') ? (
                  <span className="text-3xl">🖼️</span>
                ) : (
                  <img src={resolveFileUrl(photo.url)} alt={photo.caption ?? ''} className="w-full h-full object-cover" />
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* хронология комментариев */}
      {timeline.length > 0 && (
        <div className="card">
          <div className="flex items-center gap-2 mb-4">
            <MessageSquare size={16} className="text-ochre" />
            <h2 className="font-bold text-ink">Комментарии педагога</h2>
          </div>
          <div className="space-y-4">
            {timeline.slice(0, 5).map((c) => (
              <div key={c.id} className="flex gap-3">
                <div className="w-8 h-8 rounded-xl bg-sage/10 flex items-center justify-center flex-shrink-0 text-sm">
                  👩‍🎨
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="text-sm font-semibold text-ink">{c.author.fullName}</span>
                    {c.aiAssisted && (
                      <span className="badge badge-neutral text-xs">AI-черновик</span>
                    )}
                    <span className="text-xs text-muted ml-auto">
                      {format(new Date(c.createdAt), 'd MMM', { locale: ru })}
                    </span>
                  </div>
                  <p className="text-sm text-ink/80 mt-1 leading-relaxed">{c.text}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
