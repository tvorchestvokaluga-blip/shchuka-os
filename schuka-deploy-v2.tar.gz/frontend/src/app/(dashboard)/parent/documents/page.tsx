'use client';
// Кабинет родителя — договоры и документы семьи.
import { useEffect, useState } from 'react';
import { FileText, Download, FileSignature, FileCheck2 } from 'lucide-react';
import { api } from '@/lib/api';
import type { SchukaDocument } from '@/types';

const TYPE_MAP: Record<string, { label: string; icon: React.ElementType }> = {
  CONTRACT: { label: 'Договор', icon: FileSignature },
  AGREEMENT: { label: 'Соглашение', icon: FileCheck2 },
  OTHER: { label: 'Документ', icon: FileText },
};

export default function ParentDocuments() {
  const [docs, setDocs] = useState<SchukaDocument[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api.get('/documents').then((r) => setDocs(r.data)).finally(() => setLoading(false));
  }, []);

  if (loading) return <PageSkeleton />;

  return (
    <div className="space-y-6">
      <div>
        <p className="text-sm text-muted">Документы</p>
        <h1 className="text-2xl font-extrabold text-ink tracking-tight">Договоры и документы</h1>
      </div>

      {docs.length === 0 ? (
        <div className="card text-center py-14 text-muted">
          <FileText size={36} className="mx-auto mb-3 opacity-30" />
          <p className="text-sm">Документов пока нет</p>
        </div>
      ) : (
        <div className="card divide-y divide-line p-0">
          {docs.map((doc) => {
            const t = TYPE_MAP[doc.type] ?? TYPE_MAP.OTHER;
            const Icon = t.icon;
            return (
              <a
                key={doc.id}
                href={doc.url}
                target="_blank"
                rel="noreferrer"
                className="flex items-center gap-3 px-5 py-4 hover:bg-paper-dark transition-colors"
              >
                <div className="w-10 h-10 rounded-xl bg-paper-dark flex items-center justify-center flex-shrink-0">
                  <Icon size={18} className="text-ochre" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-semibold text-ink truncate">{doc.title}</p>
                  <p className="text-xs text-muted">
                    {t.label} · {new Date(doc.createdAt).toLocaleDateString('ru-RU')}
                  </p>
                </div>
                <Download size={16} className="text-muted flex-shrink-0" />
              </a>
            );
          })}
        </div>
      )}
    </div>
  );
}

function PageSkeleton() {
  return (
    <div className="space-y-6 animate-pulse">
      <div className="h-8 w-64 bg-line rounded-xl" />
      <div className="card h-48 bg-line border-0" />
    </div>
  );
}
