'use client';
// layout.tsx для (dashboard) — боковая навигация + шапка.
// Сигнатурный элемент: цвет акцентной полоски меняется по роли.
import { useEffect } from 'react';
import { useRouter, usePathname } from 'next/navigation';
import Link from 'next/link';
import {
  LayoutDashboard, Users, BookOpen, Calendar, CreditCard,
  Image, MessageSquare, Award, BarChart3, LogOut, Palette, Baby,
  Newspaper, ClipboardList, FileText, CalendarClock, ListTodo, Package, AlertTriangle, UserCog
} from 'lucide-react';
import { useAuthStore } from '@/lib/auth-store';
import NotificationsBell from '@/components/layout/NotificationsBell';
import type { UserRole } from '../../types';

// навигация по ролям
const NAV: Record<UserRole, { href: string; icon: React.ElementType; label: string }[]> = {
  PARENT: [
    { href: '/parent', icon: LayoutDashboard, label: 'Главная' },
    { href: '/parent/news', icon: Newspaper, label: 'Новости школы' },
    { href: '/parent/homework', icon: ClipboardList, label: 'Домашнее задание' },
    { href: '/parent/passport', icon: Award, label: 'Паспорт художника' },
    { href: '/parent/photos', icon: Image, label: 'Фото с занятий' },
    { href: '/parent/payments', icon: CreditCard, label: 'Оплаты' },
    { href: '/parent/documents', icon: FileText, label: 'Договоры и документы' },
    { href: '/parent/makeup', icon: CalendarClock, label: 'Отработка занятий' },
    { href: '/parent/schedule', icon: Calendar, label: 'Расписание' },
  ],
  TEACHER: [
    { href: '/teacher', icon: LayoutDashboard, label: 'Сегодня' },
    { href: '/teacher/groups', icon: Users, label: 'Мои группы' },
    { href: '/teacher/attendance', icon: Calendar, label: 'Посещаемость' },
    { href: '/teacher/homework', icon: ClipboardList, label: 'Домашние задания' },
    { href: '/teacher/makeup', icon: CalendarClock, label: 'Отработки' },
    { href: '/teacher/comments', icon: MessageSquare, label: 'Комментарии' },
  ],
  OWNER: [
    { href: '/admin', icon: LayoutDashboard, label: 'Обзор' },
    { href: '/admin/tasks', icon: ListTodo, label: 'Задачи' },
    { href: '/admin/families', icon: Users, label: 'Семьи и дети' },
    { href: '/admin/groups', icon: BookOpen, label: 'Группы' },
    { href: '/admin/news', icon: Newspaper, label: 'Новости школы' },
    { href: '/admin/payments', icon: CreditCard, label: 'Оплаты' },
    { href: '/admin/documents', icon: FileText, label: 'Документы' },
    { href: '/admin/makeup', icon: CalendarClock, label: 'Отработки' },
    { href: '/admin/inventory', icon: Package, label: 'Инвентаризация' },
    { href: '/admin/reports', icon: AlertTriangle, label: 'Отчёты' },
    { href: '/admin/schedule', icon: Calendar, label: 'Расписание' },
    { href: '/admin/staff', icon: UserCog, label: 'Сотрудники' },
    { href: '/admin/analytics', icon: BarChart3, label: 'Аналитика' },
  ],
  ADMIN: [
    { href: '/admin', icon: LayoutDashboard, label: 'Обзор' },
    { href: '/admin/tasks', icon: ListTodo, label: 'Задачи' },
    { href: '/admin/families', icon: Users, label: 'Семьи и дети' },
    { href: '/admin/groups', icon: BookOpen, label: 'Группы' },
    { href: '/admin/news', icon: Newspaper, label: 'Новости школы' },
    { href: '/admin/payments', icon: CreditCard, label: 'Оплаты' },
    { href: '/admin/documents', icon: FileText, label: 'Документы' },
    { href: '/admin/makeup', icon: CalendarClock, label: 'Отработки' },
    { href: '/admin/inventory', icon: Package, label: 'Инвентаризация' },
    { href: '/admin/reports', icon: AlertTriangle, label: 'Отчёты' },
    { href: '/admin/schedule', icon: Calendar, label: 'Расписание' },
    { href: '/admin/staff', icon: UserCog, label: 'Сотрудники' },
  ],
  MARKETER: [],
  ACCOUNTANT: [],
};

// акцентный цвет по роли — в тон сайту школы (коралл/зелёный/графит)
const ROLE_ACCENT: Record<string, string> = {
  PARENT:  '#E8563A', // коралл
  TEACHER: '#3C6350', // зелёный
  OWNER:   '#2B382F', // тёмно-зелёный графит (цвет логотипа)
  ADMIN:   '#2B382F',
};

const ROLE_LABEL: Record<string, string> = {
  PARENT: 'Родитель', TEACHER: 'Педагог',
  OWNER: 'Руководитель', ADMIN: 'Администратор',
};

export default function DashboardLayout({ children }: { children: React.ReactNode }) {
  const { user, logout } = useAuthStore();
  const router = useRouter();
  const pathname = usePathname();

  useEffect(() => {
    if (!user) router.push('/login');
  }, [user, router]);

  if (!user) return null;

  const navItems = NAV[user.role] ?? [];
  const accent = ROLE_ACCENT[user.role] ?? '#D4894A';

  return (
    <div className="flex h-screen bg-paper overflow-hidden">
      {/* Sidebar */}
      <aside className="w-60 flex-shrink-0 flex flex-col bg-ink text-white">
        {/* лого */}
        <div className="px-5 py-5 border-b border-white/10">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-white/10 flex items-center justify-center text-lg">🐟</div>
            <div>
              <div className="text-sm font-extrabold tracking-tight">Schuka OS</div>
              <div className="text-xs text-white/40">школа «Щука»</div>
            </div>
          </div>
        </div>

        {/* роль-бейдж */}
        <div className="px-5 py-3 border-b border-white/10">
          <div
            className="inline-flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs font-semibold"
            style={{ background: accent + '25', color: accent }}
          >
            <Palette size={12} />
            {ROLE_LABEL[user.role]}
          </div>
          <div className="text-xs text-white/50 mt-1.5 truncate">{user.email}</div>
        </div>

        {/* навигация */}
        <nav className="flex-1 px-3 py-4 space-y-0.5 overflow-y-auto">
          {navItems.map((item) => {
            const Icon = item.icon;
            const active = pathname === item.href;
            return (
              <Link
                key={item.href}
                href={item.href}
                className={`
                  flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium
                  transition-all duration-150
                  ${active
                    ? 'bg-white/12 text-white'
                    : 'text-white/50 hover:bg-white/7 hover:text-white/80'
                  }
                `}
              >
                <Icon size={17} />
                {item.label}
                {active && (
                  <div className="ml-auto w-1.5 h-1.5 rounded-full" style={{ background: accent }} />
                )}
              </Link>
            );
          })}
        </nav>

        {/* выход */}
        <div className="px-3 pb-4">
          <button
            onClick={logout}
            className="flex items-center gap-3 px-3 py-2.5 w-full rounded-xl
                       text-sm font-medium text-white/40 hover:text-white/70
                       hover:bg-white/7 transition-all duration-150"
          >
            <LogOut size={17} />
            Выйти
          </button>
        </div>
      </aside>

      {/* Контент */}
      <main className="flex-1 overflow-y-auto">
        {/* Акцентная полоска сверху — сигнатурный элемент, меняется по роли */}
        <div className="h-0.5 w-full" style={{ background: accent }} />
        <div className="max-w-5xl mx-auto px-6 pt-4">
          <div className="flex justify-end mb-1">
            <NotificationsBell />
          </div>
        </div>
        <div className="max-w-5xl mx-auto px-6 pb-6">
          {children}
        </div>
      </main>
    </div>
  );
}
