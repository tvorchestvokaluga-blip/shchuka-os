'use client';
// Доска задач руководителя — простой рабочий чек-лист по школе
// (не привязан к урокам/группам: "оплатить аренду", "заказать краски" и т.п.).
import { useEffect, useState } from 'react';
import { CheckSquare, Square, Plus, Trash2, Calendar, ListTodo, History } from 'lucide-react';
import { api } from '@/lib/api';
import type { SchukaTask } from '@/types';
import { format, isPast, isToday } from 'date-fns';
import { ru } from 'date-fns/locale';

export default function AdminTasks() {
  const [open, setOpen] = useState<SchukaTask[]>([]);
  const [done, setDone] = useState<SchukaTask[]>([]);
  const [loading, setLoading] = useState(true);
  const [showDone, setShowDone] = useState(false);

  const [title, setTitle] = useState('');
  const [note, setNote] = useState('');
  const [dueDate, setDueDate] = useState('');
  const [showForm, setShowForm] = useState(false);
  const [saving, setSaving] = useState(false);

  const load = () => {
    setLoading(true);
    return api.get('/tasks').then((r) => { setOpen(r.data.open); setDone(r.data.done); }).finally(() => setLoading(false));
  };

  useEffect(() => { load(); }, []);

  const submit = async () => {
    if (!title.trim()) return;
    setSaving(true);
    try {
      await api.post('/tasks', { title, note: note || undefined, dueDate: dueDate || undefined });
      setTitle(''); setNote(''); setDueDate(''); setShowForm(false);
      await load();
    } finally {
      setSaving(false);
    }
  };

  const toggleDone = async (task: SchukaTask) => {
    // оптимистично убираем/возвращаем из списка, чтобы не мигало
    if (task.status === 'TODO') {
      setOpen((prev) => prev.filter((t) => t.id !== task.id));
    } else {
      setDone((prev) => prev.filter((t) => t.id !== task.id));
    }
    await api.patch(`/tasks/${task.id}`, { status: task.status === 'TODO' ? 'DONE' : 'TODO' });
    await load();
  };

  const remove = async (id: string) => {
    setOpen((prev) => prev.filter((t) => t.id !== id));
    await api.delete(`/tasks/${id}`);
  };

  if (loading) return <PageSkeleton />;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <p className="text-sm text-muted">Управление</p>
          <h1 className="text-2xl font-extrabold text-ink tracking-tight">Задачи</h1>
        </div>
        <button onClick={() => setShowForm((v) => !v)} className="btn-primary">
          <Plus size={16} /> Новая задача
        </button>
      </div>

      {showForm && (
        <div className="card border-ochre/30 bg-ochre/4 space-y-3">
          <input className="input" placeholder="Что нужно сделать" value={title} onChange={(e) => setTitle(e.target.value)} />
          <input className="input" placeholder="Заметка (необязательно)" value={note} onChange={(e) => setNote(e.target.value)} />
          <div className="flex gap-2 items-center">
            <span className="text-xs text-muted">Срок (необязательно)</span>
            <input type="date" className="input w-auto" value={dueDate} onChange={(e) => setDueDate(e.target.value)} />
          </div>
          <div className="flex gap-2">
            <button onClick={submit} disabled={saving || !title.trim()} className="btn-primary flex-1 justify-center">
              {saving ? 'Сохранение...' : 'Добавить'}
            </button>
            <button onClick={() => setShowForm(false)} className="btn-secondary">Отмена</button>
          </div>
        </div>
      )}

      <div className="flex items-center gap-2">
        <ListTodo size={15} className="text-ochre" />
        <h2 className="font-bold text-ink">К выполнению ({open.length})</h2>
      </div>

      {open.length === 0 ? (
        <div className="card text-center py-10 text-muted text-sm">Задач нет — всё сделано 🎉</div>
      ) : (
        <div className="space-y-2">
          {open.map((t) => (
            <TaskRow key={t.id} task={t} onToggle={() => toggleDone(t)} onRemove={() => remove(t.id)} />
          ))}
        </div>
      )}

      <button
        onClick={() => setShowDone((v) => !v)}
        className="flex items-center gap-2 text-sm text-muted hover:text-ink transition-colors"
      >
        <History size={14} /> {showDone ? 'Скрыть выполненные' : `Выполненные (${done.length})`}
      </button>

      {showDone && (
        <div className="space-y-2">
          {done.length === 0 ? (
            <p className="text-sm text-muted">Пока пусто</p>
          ) : (
            done.map((t) => (
              <TaskRow key={t.id} task={t} onToggle={() => toggleDone(t)} onRemove={() => remove(t.id)} />
            ))
          )}
        </div>
      )}
    </div>
  );
}

function TaskRow({ task, onToggle, onRemove }: { task: SchukaTask; onToggle: () => void; onRemove: () => void }) {
  const done = task.status === 'DONE';
  const overdue = !done && task.dueDate && isPast(new Date(task.dueDate)) && !isToday(new Date(task.dueDate));

  return (
    <div className={`card flex items-start gap-3 ${done ? 'opacity-60' : ''}`}>
      <button onClick={onToggle} className="mt-0.5 flex-shrink-0 text-ochre">
        {done ? <CheckSquare size={18} /> : <Square size={18} className="text-muted" />}
      </button>
      <div className="flex-1 min-w-0">
        <p className={`text-sm font-semibold text-ink ${done ? 'line-through' : ''}`}>{task.title}</p>
        {task.note && <p className="text-xs text-muted mt-0.5">{task.note}</p>}
        {task.dueDate && (
          <p className={`text-xs mt-1 flex items-center gap-1 ${overdue ? 'text-terra font-semibold' : 'text-muted'}`}>
            <Calendar size={11} /> {format(new Date(task.dueDate), 'd MMMM', { locale: ru })}
            {overdue && ' — просрочено'}
          </p>
        )}
      </div>
      <button onClick={onRemove} className="btn-ghost p-2 text-terra hover:bg-terra/8 flex-shrink-0">
        <Trash2 size={14} />
      </button>
    </div>
  );
}

function PageSkeleton() {
  return (
    <div className="space-y-6 animate-pulse">
      <div className="h-8 w-40 bg-line rounded-xl" />
      <div className="card h-16 bg-line border-0" />
      <div className="card h-16 bg-line border-0" />
    </div>
  );
}
