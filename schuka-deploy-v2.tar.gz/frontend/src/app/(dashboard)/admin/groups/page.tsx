'use client';
// Панель руководителя — группы.
// Клик по карточке группы открывает роспись/уроки/фото этой группы
// (кнопка включения/выключения группы остаётся отдельной, не переходит по ссылке).
import { useEffect, useState } from 'react';
import Link from 'next/link';
import { BookOpen, Plus, Check, X, Calendar, MapPin, Power } from 'lucide-react';
import { api } from '@/lib/api';
import type { Group, Program } from '@/types';

const WEEKDAYS = [
  { key: 'MON', label: 'Пн' }, { key: 'TUE', label: 'Вт' }, { key: 'WED', label: 'Ср' },
  { key: 'THU', label: 'Чт' }, { key: 'FRI', label: 'Пт' }, { key: 'SAT', label: 'Сб' }, { key: 'SUN', label: 'Вс' },
];

export default function AdminGroups() {
  const [groups, setGroups] = useState<Group[]>([]);
  const [programs, setPrograms] = useState<Program[]>([]);
  const [loading, setLoading] = useState(true);
  const [showCreate, setShowCreate] = useState(false);
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState({
    name: '', programId: '', maxSize: 8, weekday: 'MON', startTime: '16:00', endTime: '17:00', room: '',
  });

  const load = () => Promise.all([
    api.get('/groups').then((r) => setGroups(r.data)),
    api.get('/programs').then((r) => setPrograms(r.data)).catch(() => setPrograms([])),
  ]).finally(() => setLoading(false));

  useEffect(() => { load(); }, []);

  useEffect(() => {
    if (!form.programId && programs.length > 0) {
      setForm((f) => ({ ...f, programId: programs[0].id }));
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [programs]);

  const submitCreate = async () => {
    if (!form.name.trim() || !form.programId) return;
    setSaving(true);
    try {
      await api.post('/groups', {
        name: form.name,
        programId: form.programId,
        maxSize: Number(form.maxSize) || 8,
        scheduleSlots: form.startTime && form.endTime
          ? [{ weekday: form.weekday, startTime: form.startTime, endTime: form.endTime, room: form.room || undefined }]
          : [],
      });
      setShowCreate(false);
      setForm({ name: '', programId: programs[0]?.id ?? '', maxSize: 8, weekday: 'MON', startTime: '16:00', endTime: '17:00', room: '' });
      await load();
    } finally {
      setSaving(false);
    }
  };

  const toggleActive = async (e: React.MouseEvent, g: Group) => {
    e.preventDefault();
    e.stopPropagation();
    await api.patch(`/groups/${g.id}`, { isActive: !g.isActive });
    await load();
  };

  if (loading) return <PageSkeleton />;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <p className="text-sm text-muted">Управление</p>
          <h1 className="text-2xl font-extrabold text-ink tracking-tight">Группы</h1>
        </div>
        <button onClick={() => setShowCreate((s) => !s)} className="btn-primary">
          <Plus size={16} /> Новая группа
        </button>
      </div>

      {showCreate && (
        <div className="card border-ochre/30 bg-ochre/4 space-y-3">
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-xs font-semibold text-muted mb-1 block">Название</label>
              <input className="input" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="Акварель 7-9" />
            </div>
            <div>
              <label className="text-xs font-semibold text-muted mb-1 block">Программа</label>
              <select className="input" value={form.programId} onChange={(e) => setForm({ ...form, programId: e.target.value })}>
                {programs.map((p) => <option key={p.id} value={p.id}>{p.name}</option>)}
              </select>
            </div>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div>
              <label className="text-xs font-semibold text-muted mb-1 block">Мест</label>
              <input type="number" min={1} max={20} className="input" value={form.maxSize}
                onChange={(e) => setForm({ ...form, maxSize: Number(e.target.value) })} />
            </div>
            <div>
              <label className="text-xs font-semibold text-muted mb-1 block">День</label>
              <select className="input" value={form.weekday} onChange={(e) => setForm({ ...form, weekday: e.target.value })}>
                {WEEKDAYS.map((d) => <option key={d.key} value={d.key}>{d.label}</option>)}
              </select>
            </div>
            <div>
              <label className="text-xs font-semibold text-muted mb-1 block">С</label>
              <input className="input" value={form.startTime} onChange={(e) => setForm({ ...form, startTime: e.target.value })} placeholder="16:00" />
            </div>
            <div>
              <label className="text-xs font-semibold text-muted mb-1 block">До</label>
              <input className="input" value={form.endTime} onChange={(e) => setForm({ ...form, endTime: e.target.value })} placeholder="17:00" />
            </div>
          </div>
          <div>
            <label className="text-xs font-semibold text-muted mb-1 block">Кабинет (необязательно)</label>
            <input className="input" value={form.room} onChange={(e) => setForm({ ...form, room: e.target.value })} placeholder="каб. 3" />
          </div>
          <div className="flex gap-2">
            <button onClick={submitCreate} disabled={saving} className="btn-primary flex-1 justify-center">
              <Check size={14} /> {saving ? 'Создание...' : 'Создать группу'}
            </button>
            <button onClick={() => setShowCreate(false)} className="btn-secondary"><X size={14} /></button>
          </div>
        </div>
      )}

      {groups.length === 0 ? (
        <div className="card text-center py-14 text-muted">
          <BookOpen size={36} className="mx-auto mb-3 opacity-30" />
          <p className="text-sm">Групп пока нет</p>
        </div>
      ) : (
        <div className="space-y-3">
          {groups.map((g) => {
            const count = g._count?.enrollments ?? 0;
            const pct = g.maxSize > 0 ? Math.round((count / g.maxSize) * 100) : 0;
            return (
              <Link
                key={g.id}
                href={`/admin/groups/${g.id}`}
                className={`card block hover:border-ink/20 transition-colors ${!g.isActive ? 'opacity-50' : ''}`}
              >
                <div className="flex items-center justify-between mb-2">
                  <div>
                    <p className="font-bold text-ink">{g.name}</p>
                    <p className="text-xs text-muted">{g.program?.name}{g.teacher?.user?.fullName && ` · ${g.teacher.user.fullName}`}</p>
                  </div>
                  <button
                    onClick={(e) => toggleActive(e, g)}
                    className={`btn-ghost p-2 ${g.isActive ? 'text-sage' : 'text-muted'}`}
                    title={g.isActive ? 'Активна' : 'Приостановлена'}
                  >
                    <Power size={14} />
                  </button>
                </div>
                <div className="flex justify-between text-xs text-muted mb-1.5">
                  <span>Заполненность</span>
                  <span className="font-semibold text-ink">{count} / {g.maxSize}</span>
                </div>
                <div className="skill-bar mb-3">
                  <div className="skill-fill" style={{ width: `${pct}%` }} />
                </div>
                {(g.scheduleSlots ?? []).length > 0 && (
                  <div className="flex flex-wrap gap-2">
                    {g.scheduleSlots.map((s) => (
                      <span key={s.id} className="badge badge-neutral">
                        <Calendar size={11} />
                        {WEEKDAYS.find((d) => d.key === s.weekday)?.label ?? s.weekday} {s.startTime}
                        {s.room && (<><MapPin size={11} className="ml-1" />{s.room}</>)}
                      </span>
                    ))}
                  </div>
                )}
              </Link>
            );
          })}
        </div>
      )}
    </div>
  );
}

function PageSkeleton() {
  return (
    <div className="space-y-6 animate-pulse">
      <div className="h-8 w-40 bg-line rounded-xl" />
      <div className="card h-32 bg-line border-0" />
      <div className="card h-32 bg-line border-0" />
    </div>
  );
}
