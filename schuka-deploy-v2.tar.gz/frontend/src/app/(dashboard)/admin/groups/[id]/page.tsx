'use client';
// Панель руководителя — карточка группы:
//  1. Роспись — дети группы, даты рождения, ссылка на полное досье ребёнка.
//  2. Уроки и темы — клик по уроку (прошедшему или будущему) открывает его
//     тему, материалы и можно их отредактировать; можно заполнить расписание
//     уроков вперёд или добавить один урок вручную.
//  3. Фото с урока — загрузка файла + отметка детей.
// Почти полностью зеркалит рабочее место педагога (teacher/groups/[id]),
// но ссылки ведут в разделы руководителя.
import { useEffect, useRef, useState } from 'react';
import Link from 'next/link';
import { useSearchParams } from 'next/navigation';
import { ArrowLeft, Cake, Calendar, MapPin, Plus, Sparkles, Upload, Check, ChevronDown, ChevronUp, Users, Trash2 } from 'lucide-react';
import { api, resolveFileUrl } from '@/lib/api';
import type { GroupDetail, Lesson } from '@/types';
import { format, differenceInYears, addMonths } from 'date-fns';
import { ru } from 'date-fns/locale';

const WEEKDAY_RU: Record<string, string> = {
  MON: 'Пн', TUE: 'Вт', WED: 'Ср', THU: 'Чт', FRI: 'Пт', SAT: 'Сб', SUN: 'Вс',
};

type TabKey = 'roster' | 'curriculum' | 'photos';

export default function AdminGroupDetail({ params }: { params: { id: string } }) {
  const groupId = params.id;
  const searchParams = useSearchParams();
  const initialTab = (searchParams.get('tab') as TabKey) || 'roster';

  const [group, setGroup] = useState<GroupDetail | null>(null);
  const [lessons, setLessons] = useState<Lesson[]>([]);
  const [loading, setLoading] = useState(true);
  const [tab, setTab] = useState<TabKey>(initialTab);

  const load = () => {
    Promise.all([
      api.get(`/groups/${groupId}`).then((r) => setGroup(r.data)),
      // сортируем по возрастанию сами — API отдаёт "свежее сверху" (так исторически
      // работает экран посещаемости), а для учебного плана нужен обратный порядок.
      api.get(`/groups/${groupId}/lessons`).then((r) => {
        const sorted = [...(r.data as Lesson[])].sort(
          (a, b) => new Date(a.date).getTime() - new Date(b.date).getTime(),
        );
        setLessons(sorted);
      }),
    ]).finally(() => setLoading(false));
  };

  useEffect(() => { load(); /* eslint-disable-next-line react-hooks/exhaustive-deps */ }, [groupId]);

  if (loading) {
    return (
      <div className="space-y-6 animate-pulse">
        <div className="h-8 w-40 bg-line rounded-xl" />
        <div className="card h-40 bg-line border-0" />
      </div>
    );
  }
  if (!group) {
    return (
      <div className="space-y-4">
        <BackLink />
        <div className="card text-center py-10 text-muted">Группа не найдена или нет доступа</div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <BackLink />

      <div>
        <h1 className="text-2xl font-extrabold text-ink tracking-tight">{group.name}</h1>
        <p className="text-sm text-muted">{group.program?.name}{group.teacher?.user?.fullName && ` · ${group.teacher.user.fullName}`}</p>
        {(group.scheduleSlots ?? []).length > 0 && (
          <div className="flex flex-wrap gap-2 mt-2">
            {group.scheduleSlots.map((s) => (
              <span key={s.id} className="badge badge-neutral">
                <Calendar size={11} /> {WEEKDAY_RU[s.weekday] ?? s.weekday} {s.startTime}
                {s.room && (<><MapPin size={11} className="ml-1" />{s.room}</>)}
              </span>
            ))}
          </div>
        )}
      </div>

      <div className="flex gap-2 overflow-x-auto pb-1">
        {[
          { key: 'roster', label: `Роспись (${group.enrollments.length})` },
          { key: 'curriculum', label: 'Уроки и темы' },
          { key: 'photos', label: 'Фото с урока' },
        ].map((t) => (
          <button
            key={t.key}
            onClick={() => setTab(t.key as TabKey)}
            className={`flex-shrink-0 px-4 py-2 rounded-xl text-sm font-semibold border transition-all
              ${tab === t.key ? 'bg-ink text-white border-ink' : 'bg-white text-muted border-line hover:border-ink/20 hover:text-ink'}`}
          >
            {t.label}
          </button>
        ))}
      </div>

      {tab === 'roster' && <RosterTab group={group} />}
      {tab === 'curriculum' && <CurriculumTab groupId={groupId} lessons={lessons} enrollmentCount={group.enrollments.length} onChange={load} />}
      {tab === 'photos' && <PhotosTab groupId={groupId} group={group} lessons={lessons} />}
    </div>
  );
}

function BackLink() {
  return (
    <Link href="/admin/groups" className="inline-flex items-center gap-1.5 text-sm text-muted hover:text-ink transition-colors">
      <ArrowLeft size={15} /> К группам
    </Link>
  );
}

// ── Роспись ──────────────────────────────────────────────────────────────
function RosterTab({ group }: { group: GroupDetail }) {
  if (group.enrollments.length === 0) {
    return <div className="card text-center py-10 text-muted text-sm">В группе пока нет детей</div>;
  }
  return (
    <div className="space-y-2">
      {group.enrollments.map((e) => {
        const age = e.student.birthDate ? differenceInYears(new Date(), new Date(e.student.birthDate)) : null;
        return (
          <Link
            key={e.id}
            href={`/admin/students/${e.student.id}`}
            className="card flex items-center justify-between hover:border-ink/20 transition-colors"
          >
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-paper-dark flex items-center justify-center text-lg flex-shrink-0">
                {e.student.avatarEmoji ?? '🎨'}
              </div>
              <div>
                <p className="text-sm font-semibold text-ink">{e.student.firstName} {e.student.lastName}</p>
                <p className="text-xs text-muted flex items-center gap-1">
                  <Cake size={11} />
                  {e.student.birthDate
                    ? `${format(new Date(e.student.birthDate), 'd MMMM yyyy', { locale: ru })} · ${age} лет`
                    : 'дата рождения не указана'}
                </p>
              </div>
            </div>
            <span className="text-xs text-muted">Досье →</span>
          </Link>
        );
      })}
    </div>
  );
}

// ── Уроки и темы ─────────────────────────────────────────────────────────
function CurriculumTab({ groupId, lessons, enrollmentCount, onChange }: {
  groupId: string; lessons: Lesson[]; enrollmentCount: number; onChange: () => void;
}) {
  const [generating, setGenerating] = useState(false);
  const [untilDate, setUntilDate] = useState(() => format(addMonths(new Date(), 6), 'yyyy-MM-dd'));
  const [genMsg, setGenMsg] = useState('');
  const [addingDate, setAddingDate] = useState('');
  const [adding, setAdding] = useState(false);
  const [expandedId, setExpandedId] = useState<string | null>(null);

  const generate = async () => {
    setGenerating(true);
    setGenMsg('');
    try {
      const { data } = await api.post(`/groups/${groupId}/lessons/generate`, { until: untilDate });
      setGenMsg(data.created > 0 ? `Добавлено уроков: ${data.created}` : 'Все уроки на этот период уже были добавлены ранее');
      onChange();
    } catch (e: any) {
      setGenMsg(e?.response?.data?.message ?? 'Не получилось — проверьте расписание группы');
    } finally {
      setGenerating(false);
    }
  };

  const addLesson = async () => {
    if (!addingDate) return;
    setAdding(true);
    try {
      await api.post(`/groups/${groupId}/lessons`, { groupId, date: new Date(addingDate).toISOString() });
      setAddingDate('');
      onChange();
    } finally {
      setAdding(false);
    }
  };

  return (
    <div className="space-y-4">
      <div className="card">
        <p className="text-sm font-semibold text-ink mb-2">Заполнить уроки вперёд</p>
        <p className="text-xs text-muted mb-3">
          Система сама расставит уроки по дням недели и времени из расписания группы — темы и материалы впишете потом, по одному.
        </p>
        <div className="flex gap-2 flex-wrap items-center">
          <span className="text-xs text-muted">до</span>
          <input type="date" value={untilDate} onChange={(e) => setUntilDate(e.target.value)} className="input w-auto" />
          <button onClick={generate} disabled={generating} className="btn-primary text-xs py-2">
            {generating ? 'Добавляю...' : 'Заполнить'}
          </button>
        </div>
        {genMsg && <p className="text-xs text-muted mt-2">{genMsg}</p>}
      </div>

      <div className="card flex gap-2 items-center flex-wrap">
        <Plus size={14} className="text-muted" />
        <input type="datetime-local" value={addingDate} onChange={(e) => setAddingDate(e.target.value)} className="input w-auto" />
        <button onClick={addLesson} disabled={adding || !addingDate} className="btn-secondary text-xs py-2">
          Добавить один урок
        </button>
      </div>

      {lessons.length === 0 ? (
        <div className="card text-center py-10 text-muted text-sm">Уроков пока нет</div>
      ) : (
        <div className="space-y-2">
          {lessons.map((l) => (
            <LessonRow
              key={l.id}
              lesson={l}
              enrollmentCount={enrollmentCount}
              expanded={expandedId === l.id}
              onToggle={() => setExpandedId(expandedId === l.id ? null : l.id)}
              onSaved={onChange}
            />
          ))}
        </div>
      )}
    </div>
  );
}

function LessonRow({ lesson, enrollmentCount, expanded, onToggle, onSaved }: {
  lesson: Lesson; enrollmentCount: number; expanded: boolean; onToggle: () => void; onSaved: () => void;
}) {
  const [topic, setTopic] = useState(lesson.topic ?? '');
  const [materials, setMaterials] = useState(lesson.materials ?? '');
  const [note, setNote] = useState(lesson.note ?? '');
  const [saving, setSaving] = useState(false);
  const [deleting, setDeleting] = useState(false);
  const isPast = new Date(lesson.date) < new Date();
  const marked = lesson._count?.attendances ?? 0;
  const photosCount = lesson._count?.photos ?? 0;

  const save = async () => {
    setSaving(true);
    try {
      await api.patch(`/lessons/${lesson.id}`, { topic, materials, note });
      onSaved();
    } finally {
      setSaving(false);
    }
  };

  const remove = async () => {
    const warn = marked > 0 || photosCount > 0
      ? `У этого урока уже есть отметки посещаемости (${marked}) или фото (${photosCount}) — отметки посещаемости удалятся вместе с уроком, а фото останутся у детей, просто без привязки к этой дате. Удалить урок?`
      : 'Удалить этот урок? Это действие необратимо.';
    if (!confirm(warn)) return;
    setDeleting(true);
    try {
      await api.delete(`/lessons/${lesson.id}`);
      onSaved();
    } catch (e: any) {
      alert(e?.response?.data?.message ?? 'Не получилось удалить урок');
    } finally {
      setDeleting(false);
    }
  };

  return (
    <div className="card">
      <button onClick={onToggle} className="w-full flex items-center justify-between text-left">
        <div>
          <p className={`text-sm font-semibold ${isPast ? 'text-muted' : 'text-ink'}`}>
            {format(new Date(lesson.date), 'd MMMM yyyy, HH:mm', { locale: ru })}
          </p>
          <p className="text-xs text-muted">{lesson.topic || 'Тема не задана'}</p>
        </div>
        <div className="flex items-center gap-2">
          {isPast && (
            <span className="badge badge-neutral text-[10px]">
              <Users size={10} /> {marked > 0 ? `отмечено: ${marked}` : 'посещаемость не отмечена'}
            </span>
          )}
          {expanded ? <ChevronUp size={16} className="text-muted" /> : <ChevronDown size={16} className="text-muted" />}
        </div>
      </button>

      {expanded && (
        <div className="mt-3 pt-3 border-t border-line space-y-2">
          <input
            className="input"
            placeholder="Тема урока"
            value={topic}
            onChange={(e) => setTopic(e.target.value)}
          />
          <textarea
            className="input min-h-20 resize-none"
            placeholder="Материалы / методичка (текст или ссылка)"
            value={materials}
            onChange={(e) => setMaterials(e.target.value)}
          />
          <textarea
            className="input min-h-16 resize-none"
            placeholder="Заметка (необязательно, видна только сотрудникам)"
            value={note}
            onChange={(e) => setNote(e.target.value)}
          />
          <div className="flex gap-2">
            <button onClick={save} disabled={saving || deleting} className="btn-primary text-xs py-2 flex-1 justify-center">
              {saving ? 'Сохранение...' : 'Сохранить'}
            </button>
            <button
              onClick={remove}
              disabled={saving || deleting}
              className="btn-ghost text-xs py-2 px-3 text-terra hover:bg-terra/8"
              title="Удалить урок"
            >
              <Trash2 size={14} /> {deleting ? 'Удаление...' : 'Удалить'}
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

// ── Фото с урока ─────────────────────────────────────────────────────────
function PhotosTab({ groupId, group, lessons }: { groupId: string; group: GroupDetail; lessons: Lesson[] }) {
  const [lessonId, setLessonId] = useState('');
  const [selected, setSelected] = useState<Set<string>>(new Set());
  const [caption, setCaption] = useState('');
  const [file, setFile] = useState<File | null>(null);
  const [uploading, setUploading] = useState(false);
  const [resultMsg, setResultMsg] = useState('');
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (!lessonId && lessons.length > 0) {
      // по умолчанию — ближайший прошедший урок (на нём и делали фото)
      const past = [...lessons].filter((l) => new Date(l.date) <= new Date());
      setLessonId((past[past.length - 1] ?? lessons[0]).id);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [lessons]);

  const toggleStudent = (id: string) => {
    setSelected((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id); else next.add(id);
      return next;
    });
  };

  const submit = async () => {
    if (!file || !lessonId || selected.size === 0) return;
    setUploading(true);
    setResultMsg('');
    try {
      const form = new FormData();
      form.append('file', file);
      // Content-Type для multipart с правильной границей (boundary) должен
      // проставить сам браузер — если задать его руками, файл не распарсится.
      const { data: uploaded } = await api.post('/photos/upload', form);
      const { data } = await api.post(`/lessons/${lessonId}/photos/bulk-with-comment`, {
        lessonId,
        studentIds: Array.from(selected),
        url: uploaded.url,
        caption: caption || undefined,
      });
      setResultMsg(
        `Готово: фото добавлено ${data.created} детям, авто-комментарий написан для ${data.commentsCreated} из них — уже видно родителям.`,
      );
      setFile(null);
      setCaption('');
      setSelected(new Set());
      if (fileInputRef.current) fileInputRef.current.value = '';
    } catch (e: any) {
      setResultMsg(e?.response?.data?.message ?? 'Не получилось загрузить фото');
    } finally {
      setUploading(false);
    }
  };

  return (
    <div className="space-y-4">
      <div className="card space-y-3">
        <div>
          <label className="text-xs font-semibold text-muted mb-1 block">Урок</label>
          <select className="input" value={lessonId} onChange={(e) => setLessonId(e.target.value)}>
            {lessons.map((l) => (
              <option key={l.id} value={l.id}>
                {format(new Date(l.date), 'd MMMM yyyy', { locale: ru })}{l.topic ? ` — ${l.topic}` : ''}
              </option>
            ))}
          </select>
        </div>

        <div>
          <label className="text-xs font-semibold text-muted mb-1 block">Фото</label>
          <input
            ref={fileInputRef}
            type="file"
            accept="image/*"
            onChange={(e) => setFile(e.target.files?.[0] ?? null)}
            className="input"
          />
        </div>

        <div>
          <label className="text-xs font-semibold text-muted mb-1 block">Подпись (необязательно)</label>
          <input className="input" value={caption} onChange={(e) => setCaption(e.target.value)} placeholder="Например: акварель, тема «Осенний лес»" />
        </div>

        <div>
          <label className="text-xs font-semibold text-muted mb-1 block">Кто на фото</label>
          <div className="flex flex-wrap gap-2">
            {group.enrollments.map((e) => {
              const on = selected.has(e.student.id);
              return (
                <button
                  key={e.student.id}
                  onClick={() => toggleStudent(e.student.id)}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold border transition-all
                    ${on ? 'bg-ochre text-white border-ochre' : 'bg-white text-muted border-line hover:border-ink/20 hover:text-ink'}`}
                >
                  {on && <Check size={12} />}
                  {e.student.avatarEmoji ?? '🎨'} {e.student.firstName}
                </button>
              );
            })}
          </div>
        </div>

        <button
          onClick={submit}
          disabled={uploading || !file || !lessonId || selected.size === 0}
          className="btn-primary w-full justify-center"
        >
          <Upload size={14} /> {uploading ? 'Загрузка...' : 'Загрузить и отправить родителям'}
        </button>
        <p className="text-xs text-muted flex items-center gap-1">
          <Sparkles size={11} /> Комментарий педагога к фото сформируется автоматически
        </p>

        {resultMsg && <p className="text-xs text-ink/80 bg-paper-dark rounded-xl p-3">{resultMsg}</p>}
      </div>
    </div>
  );
}
