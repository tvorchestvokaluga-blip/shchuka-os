'use client';
// Панель руководителя — новости школы.
import { useEffect, useState } from 'react';
import { Newspaper, Plus, Trash2, Pencil, X, Check, EyeOff, Eye } from 'lucide-react';
import { api } from '@/lib/api';
import type { NewsPost } from '@/types';

export default function AdminNews() {
  const [posts, setPosts] = useState<NewsPost[]>([]);
  const [loading, setLoading] = useState(true);
  const [showCreate, setShowCreate] = useState(false);
  const [editingId, setEditingId] = useState('');
  const [form, setForm] = useState({ title: '', body: '', isPublished: true });
  const [saving, setSaving] = useState(false);

  const load = () => {
    setLoading(true);
    return api.get('/news').then((r) => setPosts(r.data)).finally(() => setLoading(false));
  };

  useEffect(() => { load(); }, []);

  const startCreate = () => { setForm({ title: '', body: '', isPublished: true }); setShowCreate(true); setEditingId(''); };
  const startEdit = (p: NewsPost) => { setForm({ title: p.title, body: p.body, isPublished: p.isPublished }); setEditingId(p.id); setShowCreate(false); };
  const cancel = () => { setShowCreate(false); setEditingId(''); };

  const submitCreate = async () => {
    if (!form.title.trim() || !form.body.trim()) return;
    setSaving(true);
    try { await api.post('/news', form); setShowCreate(false); await load(); } finally { setSaving(false); }
  };

  const submitEdit = async (id: string) => {
    if (!form.title.trim() || !form.body.trim()) return;
    setSaving(true);
    try { await api.patch(`/news/${id}`, form); setEditingId(''); await load(); } finally { setSaving(false); }
  };

  const togglePublish = async (p: NewsPost) => {
    await api.patch(`/news/${p.id}`, { isPublished: !p.isPublished });
    await load();
  };

  const remove = async (id: string) => {
    if (!confirm('Удалить новость?')) return;
    await api.delete(`/news/${id}`);
    await load();
  };

  if (loading) return <PageSkeleton />;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <p className="text-sm text-muted">Коммуникация</p>
          <h1 className="text-2xl font-extrabold text-ink tracking-tight">Новости школы</h1>
        </div>
        <button onClick={startCreate} className="btn-primary"><Plus size={16} /> Добавить новость</button>
      </div>

      {showCreate && (
        <NewsForm form={form} setForm={setForm} onCancel={cancel} onSubmit={submitCreate} saving={saving} submitLabel="Опубликовать" />
      )}

      {posts.length === 0 ? (
        <div className="card text-center py-14 text-muted">
          <Newspaper size={36} className="mx-auto mb-3 opacity-30" />
          <p className="text-sm">Новостей пока нет</p>
        </div>
      ) : (
        <div className="space-y-3">
          {posts.map((p) => (
            <div key={p.id} className="card">
              {editingId === p.id ? (
                <NewsForm form={form} setForm={setForm} onCancel={cancel} onSubmit={() => submitEdit(p.id)} saving={saving} submitLabel="Сохранить" />
              ) : (
                <>
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2">
                        <h2 className="font-bold text-ink">{p.title}</h2>
                        {!p.isPublished && <span className="badge badge-neutral">Черновик</span>}
                      </div>
                      <p className="text-sm text-ink/70 mt-1 line-clamp-2">{p.body}</p>
                      <p className="text-xs text-muted mt-2">
                        {p.author.fullName} · {new Date(p.publishedAt).toLocaleDateString('ru-RU')}
                      </p>
                    </div>
                    <div className="flex gap-1 flex-shrink-0">
                      <button onClick={() => togglePublish(p)} className="btn-ghost p-2" title={p.isPublished ? 'Снять с публикации' : 'Опубликовать'}>
                        {p.isPublished ? <EyeOff size={14} /> : <Eye size={14} />}
                      </button>
                      <button onClick={() => startEdit(p)} className="btn-ghost p-2"><Pencil size={14} /></button>
                      <button onClick={() => remove(p.id)} className="btn-ghost p-2 text-terra hover:bg-terra/8"><Trash2 size={14} /></button>
                    </div>
                  </div>
                </>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

function NewsForm({ form, setForm, onCancel, onSubmit, saving, submitLabel }: {
  form: { title: string; body: string; isPublished: boolean };
  setForm: (f: { title: string; body: string; isPublished: boolean }) => void;
  onCancel: () => void; onSubmit: () => void; saving: boolean; submitLabel: string;
}) {
  return (
    <div className="card border-ochre/30 bg-ochre/4 space-y-3">
      <input className="input" placeholder="Заголовок новости" value={form.title}
        onChange={(e) => setForm({ ...form, title: e.target.value })} />
      <textarea className="input min-h-[100px]" placeholder="Текст новости" value={form.body}
        onChange={(e) => setForm({ ...form, body: e.target.value })} />
      <label className="flex items-center gap-2 text-sm text-ink cursor-pointer">
        <input type="checkbox" checked={form.isPublished}
          onChange={(e) => setForm({ ...form, isPublished: e.target.checked })} />
        Опубликовать сразу (видно всем родителям)
      </label>
      <div className="flex gap-2">
        <button onClick={onSubmit} disabled={saving} className="btn-primary flex-1 justify-center">
          <Check size={14} /> {saving ? 'Сохранение...' : submitLabel}
        </button>
        <button onClick={onCancel} className="btn-secondary"><X size={14} /></button>
      </div>
    </div>
  );
}

function PageSkeleton() {
  return (
    <div className="space-y-6 animate-pulse">
      <div className="h-8 w-48 bg-line rounded-xl" />
      <div className="card h-24 bg-line border-0" />
      <div className="card h-24 bg-line border-0" />
    </div>
  );
}
