'use client';
// Панель руководителя — аналитика школы.
import { useEffect, useState } from 'react';
import { Users, TrendingUp, CreditCard, BookOpen } from 'lucide-react';
import { api } from '@/lib/api';
import type { Group, Payment, Enrollment } from '@/types';

const STATUS_LABEL: Record<string, string> = {
  ACTIVE: 'Активные', PAUSED: 'На паузе', FINISHED: 'Завершены', CANCELLED: 'Отменены',
};
const STATUS_COLOR: Record<string, string> = {
  ACTIVE: '#5C7A6B', PAUSED: '#D4894A', FINISHED: '#7C7A8E', CANCELLED: '#B85450',
};

export default function AdminAnalytics() {
  const [groups, setGroups] = useState<Group[]>([]);
  const [payments, setPayments] = useState<Payment[]>([]);
  const [enrollments, setEnrollments] = useState<Enrollment[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    Promise.all([
      api.get('/groups').then((r) => setGroups(r.data)),
      api.get('/payments').then((r) => setPayments(r.data)),
      api.get('/enrollments').then((r) => setEnrollments(r.data)),
    ]).finally(() => setLoading(false));
  }, []);

  if (loading) return <PageSkeleton />;

  const uniqueStudents = new Set(enrollments.map((e) => e.student.id)).size;
  const totalCapacity = groups.reduce((s, g) => s + g.maxSize, 0);
  const totalEnrolled = groups.reduce((s, g) => s + (g._count?.enrollments ?? 0), 0);
  const fillRate = totalCapacity > 0 ? Math.round((totalEnrolled / totalCapacity) * 100) : 0;

  const revenuePaid = payments.filter((p) => p.status === 'PAID').reduce((s, p) => s + Number(p.amount), 0);
  const revenuePending = payments.filter((p) => p.status === 'PENDING').reduce((s, p) => s + Number(p.amount), 0);
  const revenueOverdue = payments.filter((p) => p.status === 'OVERDUE').reduce((s, p) => s + Number(p.amount), 0);
  const revenueTotal = revenuePaid + revenuePending + revenueOverdue || 1;

  const statusCounts: Record<string, number> = {};
  enrollments.forEach((e) => { statusCounts[e.status] = (statusCounts[e.status] ?? 0) + 1; });

  return (
    <div className="space-y-6">
      <div>
        <p className="text-sm text-muted">Показатели школы</p>
        <h1 className="text-2xl font-extrabold text-ink tracking-tight">Аналитика</h1>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <StatCard icon={Users} color="ochre" value={String(uniqueStudents)} label="Учеников" />
        <StatCard icon={BookOpen} color="sage" value={`${fillRate}%`} label="Заполненность групп" />
        <StatCard icon={CreditCard} color="sage" value={`${revenuePaid.toLocaleString('ru-RU')} ₽`} label="Выручка" />
        <StatCard icon={TrendingUp} color="terra" value={`${(revenuePending + revenueOverdue).toLocaleString('ru-RU')} ₽`} label="Ожидается" />
      </div>

      {/* заполненность по группам */}
      <div className="card">
        <h2 className="font-bold text-ink mb-4">Заполненность групп</h2>
        <div className="space-y-3">
          {groups.map((g) => {
            const count = g._count?.enrollments ?? 0;
            const pct = g.maxSize > 0 ? Math.round((count / g.maxSize) * 100) : 0;
            const color = pct >= 87 ? '#5C7A6B' : pct >= 60 ? '#D4894A' : '#B85450';
            return (
              <div key={g.id}>
                <div className="flex justify-between text-sm mb-1.5">
                  <span className="font-medium text-ink">{g.name}</span>
                  <span className="text-muted text-xs">{count} / {g.maxSize}</span>
                </div>
                <div className="skill-bar">
                  <div className="h-full rounded-full transition-all" style={{ width: `${pct}%`, background: color }} />
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* структура выручки */}
      <div className="card">
        <h2 className="font-bold text-ink mb-4">Структура выручки</h2>
        <div className="h-3 rounded-full overflow-hidden flex bg-line mb-3">
          <div className="h-full bg-sage" style={{ width: `${(revenuePaid / revenueTotal) * 100}%` }} />
          <div className="h-full bg-ochre" style={{ width: `${(revenuePending / revenueTotal) * 100}%` }} />
          <div className="h-full bg-terra" style={{ width: `${(revenueOverdue / revenueTotal) * 100}%` }} />
        </div>
        <div className="flex flex-wrap gap-4 text-xs">
          <LegendItem color="bg-sage" label="Оплачено" value={revenuePaid} />
          <LegendItem color="bg-ochre" label="Ожидается" value={revenuePending} />
          <LegendItem color="bg-terra" label="Просрочено" value={revenueOverdue} />
        </div>
      </div>

      {/* зачисления по статусу */}
      <div className="card">
        <h2 className="font-bold text-ink mb-4">Зачисления по статусу</h2>
        <div className="space-y-3">
          {Object.entries(statusCounts).map(([status, count]) => {
            const pct = enrollments.length > 0 ? Math.round((count / enrollments.length) * 100) : 0;
            return (
              <div key={status}>
                <div className="flex justify-between text-sm mb-1.5">
                  <span className="font-medium text-ink">{STATUS_LABEL[status] ?? status}</span>
                  <span className="text-muted text-xs">{count}</span>
                </div>
                <div className="skill-bar">
                  <div className="h-full rounded-full" style={{ width: `${pct}%`, background: STATUS_COLOR[status] ?? '#7C7A8E' }} />
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}

function StatCard({ icon: Icon, color, value, label }: { icon: React.ElementType; color: string; value: string; label: string }) {
  const colorMap: Record<string, string> = {
    ochre: 'text-ochre bg-ochre/8', sage: 'text-sage bg-sage/8', terra: 'text-terra bg-terra/8',
  };
  return (
    <div className="card">
      <div className={`w-9 h-9 rounded-xl flex items-center justify-center mb-3 ${colorMap[color]}`}>
        <Icon size={18} />
      </div>
      <p className="text-xl font-extrabold text-ink tracking-tight">{value}</p>
      <p className="text-sm font-semibold text-ink mt-0.5">{label}</p>
    </div>
  );
}

function LegendItem({ color, label, value }: { color: string; label: string; value: number }) {
  return (
    <div className="flex items-center gap-1.5">
      <span className={`w-2.5 h-2.5 rounded-full ${color}`} />
      <span className="text-muted">{label}:</span>
      <span className="font-semibold text-ink">{value.toLocaleString('ru-RU')} ₽</span>
    </div>
  );
}

function PageSkeleton() {
  return (
    <div className="space-y-6 animate-pulse">
      <div className="h-8 w-40 bg-line rounded-xl" />
      <div className="grid grid-cols-2 gap-4">
        {[0, 1, 2, 3].map((i) => <div key={i} className="h-24 card bg-line border-0" />)}
      </div>
    </div>
  );
}
