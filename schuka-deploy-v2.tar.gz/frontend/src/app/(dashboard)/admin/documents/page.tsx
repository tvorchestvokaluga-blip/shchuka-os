'use client';
// Панель руководителя — договоры и документы семей.
import { useEffect, useState } from 'react';
import { FileText, Plus, Trash2, X, Check } from 'lucide-react';
import { api } from '@/lib/api';
import type { SchukaDocument, SchukaDocumentType } from '@/types';

interface Family { id: string; name: string; }

const TYPE_LABEL: Record<SchukaDocumentType, string> = {
  CONTRACT: 'Договор', AGREEMENT: 'Соглашение', OTHER: 'Документ',
};

const EMPTY_FORM = { familyId: '', type: 'CONTRACT' as SchukaDocumentType, title: '', url: '' };

export default function AdminDocuments() {
  const [docs, setDocs] = useState<SchukaDocument[]>([]);
  const [families, setFamilies] = useState<Family[]>([]);
  const [loading, setLoading] = useState(true);
  const [showCreate, setShowCreate] = useState(false);
  const [form, setForm] = useState(EMPTY_FORM);
  const [saving, setSaving] = useState(false);

  const load = () => {
    setLoading(true);
    return Promise.all([
      api.get('/documents').then((r) => setDocs(r.data)),
      api.get('/families').then((r) => setFamilies(r.data)),
    ]).finally(() => setLoading(false));
  };

  useEffect(() => { load(); }, []);

  const startCreate = () => {
    setForm({ ...EMPTY_FORM, familyId: families[0]?.id ?? '' });
    setShowCreate(true);
  };

  const submitCreate = async () => {
    if (!form.familyId || !form.title.trim() || !form.url.trim()) return;
    setSaving(true);
    try { await api.post('/documents', form); setShowCreate(false); await load(); } finally { setSaving(false); }
  };

  const remove = async (id: string) => {
    if (!confirm('Удалить документ?')) return;
    await api.delete(`/documents/${id}`);
    await load();
  };

  if (loading) return <PageSkeleton />;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <p className="text-sm text-muted">Управление</p>
          <h1 className="text-2xl font-extrabold text-ink tracking-tight">Документы</h1>
        </div>
        <button onClick={startCreate} className="btn-primary"><Plus size={16} /> Добавить документ</button>
      </div>

      {showCreate && (
        <div className="card border-ochre/30 bg-ochre/4 space-y-3">
          <div>
            <label className="text-xs font-semibold text-muted mb-1 block">Семья</label>
            <select className="input" value={form.familyId} onChange={(e) => setForm({ ...form, familyId: e.target.value })}>
              {families.map((f) => <option key={f.id} value={f.id}>{f.name}</option>)}
            </select>
          </div>
          <div>
            <label className="text-xs font-semibold text-muted mb-1 block">Тип</label>
            <select className="input" value={form.type} onChange={(e) => setForm({ ...form, type: e.target.value as SchukaDocumentType })}>
              {Object.entries(TYPE_LABEL).map(([v, label]) => <option key={v} value={v}>{label}</option>)}
            </select>
          </div>
          <input className="input" placeholder="Название документа" value={form.title}
            onChange={(e) => setForm({ ...form, title: e.target.value })} />
          <input className="input" placeholder="Ссылка на файл (Google Диск, Яндекс.Диск и т.п.)" value={form.url}
            onChange={(e) => setForm({ ...form, url: e.target.value })} />
          <div className="flex gap-2">
            <button onClick={submitCreate} disabled={saving} className="btn-primary flex-1 justify-center">
              <Check size={14} /> {saving ? 'Сохранение...' : 'Добавить'}
            </button>
            <button onClick={() => setShowCreate(false)} className="btn-secondary"><X size={14} /></button>
          </div>
        </div>
      )}

      {docs.length === 0 ? (
        <div className="card text-center py-14 text-muted">
          <FileText size={36} className="mx-auto mb-3 opacity-30" />
          <p className="text-sm">Документов пока нет</p>
        </div>
      ) : (
        <div className="card divide-y divide-line p-0">
          {docs.map((doc) => (
            <div key={doc.id} className="flex items-center gap-3 px-5 py-4">
              <div className="flex-1 min-w-0">
                <a href={doc.url} target="_blank" rel="noreferrer" className="text-sm font-semibold text-ink hover:text-ochre truncate block">
                  {doc.title}
                </a>
                <p className="text-xs text-muted">
                  {TYPE_LABEL[doc.type]} · {doc.family?.name ?? ''} · {new Date(doc.createdAt).toLocaleDateString('ru-RU')}
                </p>
              </div>
              <button onClick={() => remove(doc.id)} className="btn-ghost p-2 text-terra hover:bg-terra/8 flex-shrink-0">
                <Trash2 size={14} />
              </button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

function PageSkeleton() {
  return (
    <div className="space-y-6 animate-pulse">
      <div className="h-8 w-48 bg-line rounded-xl" />
      <div className="card h-48 bg-line border-0" />
    </div>
  );
}
