'use client';
// Панель руководителя — семьи и дети.
// Три вида одних и тех же данных: по семьям (было), по группам и общий список
// (оба — по просьбе: "семьи и дети сделать по группам и страничку с отдельным списком").
// Имя ребёнка — ссылка на полное досье (/admin/students/[id]): уроки, фото, оплаты, навыки.
import { useEffect, useState } from 'react';
import Link from 'next/link';
import { Users, Plus, Trash2, Pencil, X, Check, Baby, BookOpen, List, Cake } from 'lucide-react';
import { api } from '@/lib/api';
import type { Student } from '@/types';
import { differenceInYears } from 'date-fns';

interface Family {
  id: string;
  name: string;
  note?: string;
  students?: Student[];
}

type Tab = 'families' | 'groups' | 'list';

export default function AdminFamilies() {
  const [families, setFamilies] = useState<Family[]>([]);
  const [students, setStudents] = useState<Student[]>([]);
  const [loading, setLoading] = useState(true);
  const [tab, setTab] = useState<Tab>('families');
  const [showCreate, setShowCreate] = useState(false);
  const [editingId, setEditingId] = useState('');
  const [form, setForm] = useState({ name: '', note: '' });
  const [saving, setSaving] = useState(false);

  const load = () => {
    setLoading(true);
    return Promise.all([
      api.get('/families').then((r) => setFamilies(r.data)),
      api.get('/students').then((r) => setStudents(r.data)).catch(() => setStudents([])),
    ]).finally(() => setLoading(false));
  };

  useEffect(() => { load(); }, []);

  const childrenOf = (family: Family) =>
    family.students ?? students.filter((s) => s.familyId === family.id);

  const startCreate = () => { setForm({ name: '', note: '' }); setShowCreate(true); setEditingId(''); };
  const startEdit = (f: Family) => { setForm({ name: f.name, note: f.note ?? '' }); setEditingId(f.id); setShowCreate(false); };
  const cancel = () => { setShowCreate(false); setEditingId(''); };

  const submitCreate = async () => {
    if (!form.name.trim()) return;
    setSaving(true);
    try {
      await api.post('/families', { name: form.name, note: form.note || undefined });
      setShowCreate(false);
      await load();
    } finally {
      setSaving(false);
    }
  };

  const submitEdit = async (id: string) => {
    if (!form.name.trim()) return;
    setSaving(true);
    try {
      await api.patch(`/families/${id}`, { name: form.name, note: form.note || undefined });
      setEditingId('');
      await load();
    } finally {
      setSaving(false);
    }
  };

  const remove = async (id: string) => {
    if (!confirm('Удалить семью? Это действие необратимо.')) return;
    await api.delete(`/families/${id}`);
    await load();
  };

  if (loading) return <PageSkeleton />;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <p className="text-sm text-muted">Управление</p>
          <h1 className="text-2xl font-extrabold text-ink tracking-tight">Семьи и дети</h1>
        </div>
        {tab === 'families' && (
          <button onClick={startCreate} className="btn-primary">
            <Plus size={16} /> Добавить семью
          </button>
        )}
      </div>

      <div className="flex gap-2 overflow-x-auto pb-1">
        {[
          { key: 'families', label: 'По семьям', icon: Users },
          { key: 'groups', label: 'По группам', icon: BookOpen },
          { key: 'list', label: 'Общий список', icon: List },
        ].map((t) => (
          <button
            key={t.key}
            onClick={() => setTab(t.key as Tab)}
            className={`flex-shrink-0 flex items-center gap-1.5 px-4 py-2 rounded-xl text-sm font-semibold border transition-all
              ${tab === t.key ? 'bg-ink text-white border-ink' : 'bg-white text-muted border-line hover:border-ink/20 hover:text-ink'}`}
          >
            <t.icon size={14} /> {t.label}
          </button>
        ))}
      </div>

      {tab === 'families' && (
        <>
          {showCreate && (
            <FamilyForm form={form} setForm={setForm} onCancel={cancel} onSubmit={submitCreate} saving={saving} submitLabel="Создать" />
          )}

          {families.length === 0 ? (
            <div className="card text-center py-14 text-muted">
              <Users size={36} className="mx-auto mb-3 opacity-30" />
              <p className="text-sm">Семей пока нет</p>
            </div>
          ) : (
            <div className="space-y-3">
              {families.map((f) => (
                <div key={f.id} className="card">
                  {editingId === f.id ? (
                    <FamilyForm form={form} setForm={setForm} onCancel={cancel} onSubmit={() => submitEdit(f.id)} saving={saving} submitLabel="Сохранить" />
                  ) : (
                    <>
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="font-bold text-ink">{f.name}</p>
                          {f.note && <p className="text-xs text-muted mt-0.5">{f.note}</p>}
                        </div>
                        <div className="flex gap-1">
                          <button onClick={() => startEdit(f)} className="btn-ghost p-2"><Pencil size={14} /></button>
                          <button onClick={() => remove(f.id)} className="btn-ghost p-2 text-terra hover:bg-terra/8"><Trash2 size={14} /></button>
                        </div>
                      </div>
                      <div className="flex flex-wrap gap-2 mt-3">
                        {childrenOf(f).length === 0 ? (
                          <span className="text-xs text-muted">Детей не добавлено</span>
                        ) : (
                          childrenOf(f).map((s) => (
                            <Link key={s.id} href={`/admin/students/${s.id}`} className="badge badge-neutral hover:bg-ochre/10 hover:text-ochre-dark transition-colors">
                              <Baby size={11} />
                              {s.firstName} {s.lastName}
                            </Link>
                          ))
                        )}
                      </div>
                    </>
                  )}
                </div>
              ))}
            </div>
          )}
        </>
      )}

      {tab === 'groups' && <ByGroupTab students={students} />}
      {tab === 'list' && <FlatListTab students={students} />}
    </div>
  );
}

// ── По группам ───────────────────────────────────────────────────────────
function ByGroupTab({ students }: { students: Student[] }) {
  const groups = new Map<string, { name: string; students: Student[] }>();
  const noGroup: Student[] = [];

  for (const s of students) {
    const enr = s.enrollments?.[0];
    if (!enr) { noGroup.push(s); continue; }
    const key = enr.group.id;
    if (!groups.has(key)) groups.set(key, { name: enr.group.name, students: [] });
    groups.get(key)!.students.push(s);
  }

  const entries = Array.from(groups.entries()).sort((a, b) => a[1].name.localeCompare(b[1].name, 'ru'));

  if (entries.length === 0 && noGroup.length === 0) {
    return <div className="card text-center py-14 text-muted text-sm">Детей пока нет</div>;
  }

  return (
    <div className="space-y-4">
      {entries.map(([groupId, g]) => (
        <div key={groupId} className="card">
          <div className="flex items-center justify-between mb-3">
            <h2 className="font-bold text-ink flex items-center gap-2"><BookOpen size={15} className="text-ochre" /> {g.name}</h2>
            <span className="badge badge-neutral">{g.students.length} детей</span>
          </div>
          <div className="flex flex-wrap gap-2">
            {g.students.map((s) => (
              <Link key={s.id} href={`/admin/students/${s.id}`} className="badge badge-neutral hover:bg-ochre/10 hover:text-ochre-dark transition-colors">
                {s.avatarEmoji ?? '🎨'} {s.firstName} {s.lastName}
              </Link>
            ))}
          </div>
        </div>
      ))}

      {noGroup.length > 0 && (
        <div className="card border-terra/20 bg-terra/4">
          <h2 className="font-bold text-ink mb-3">Без группы</h2>
          <div className="flex flex-wrap gap-2">
            {noGroup.map((s) => (
              <Link key={s.id} href={`/admin/students/${s.id}`} className="badge badge-neutral hover:bg-ochre/10 hover:text-ochre-dark transition-colors">
                {s.avatarEmoji ?? '🎨'} {s.firstName} {s.lastName}
              </Link>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

// ── Общий список ─────────────────────────────────────────────────────────
type SortKey = 'name' | 'age' | 'group' | 'family';

function FlatListTab({ students }: { students: Student[] }) {
  const [sortKey, setSortKey] = useState<SortKey>('name');
  const [query, setQuery] = useState('');

  const filtered = students.filter((s) => {
    if (!query.trim()) return true;
    const q = query.toLowerCase();
    return (
      `${s.firstName} ${s.lastName}`.toLowerCase().includes(q) ||
      (s.family?.name ?? '').toLowerCase().includes(q) ||
      (s.enrollments?.[0]?.group.name ?? '').toLowerCase().includes(q)
    );
  });

  const sorted = [...filtered].sort((a, b) => {
    switch (sortKey) {
      case 'age':
        if (!a.birthDate) return 1;
        if (!b.birthDate) return -1;
        return new Date(a.birthDate).getTime() - new Date(b.birthDate).getTime();
      case 'group':
        return (a.enrollments?.[0]?.group.name ?? '').localeCompare(b.enrollments?.[0]?.group.name ?? '', 'ru');
      case 'family':
        return (a.family?.name ?? '').localeCompare(b.family?.name ?? '', 'ru');
      default:
        return `${a.lastName}${a.firstName}`.localeCompare(`${b.lastName}${b.firstName}`, 'ru');
    }
  });

  return (
    <div className="space-y-3">
      <div className="flex gap-2 flex-wrap items-center">
        <input
          className="input flex-1 min-w-[200px]"
          placeholder="Поиск: имя, семья, группа..."
          value={query}
          onChange={(e) => setQuery(e.target.value)}
        />
        <select className="input w-auto" value={sortKey} onChange={(e) => setSortKey(e.target.value as SortKey)}>
          <option value="name">Сортировка: по имени</option>
          <option value="age">По возрасту</option>
          <option value="group">По группе</option>
          <option value="family">По семье</option>
        </select>
      </div>

      {sorted.length === 0 ? (
        <div className="card text-center py-14 text-muted text-sm">Никого не нашлось</div>
      ) : (
        <div className="card p-0 overflow-hidden">
          <div className="divide-y divide-line">
            {sorted.map((s) => {
              const age = s.birthDate ? differenceInYears(new Date(), new Date(s.birthDate)) : null;
              return (
                <Link key={s.id} href={`/admin/students/${s.id}`} className="flex items-center justify-between px-4 py-3 hover:bg-paper-dark transition-colors">
                  <div className="flex items-center gap-3 min-w-0">
                    <span className="text-lg flex-shrink-0">{s.avatarEmoji ?? '🎨'}</span>
                    <div className="min-w-0">
                      <p className="text-sm font-semibold text-ink truncate">{s.firstName} {s.lastName}</p>
                      <p className="text-xs text-muted flex items-center gap-1">
                        <Cake size={10} /> {age !== null ? `${age} лет` : 'возраст не указан'} · {s.family?.name ?? 'без семьи'}
                      </p>
                    </div>
                  </div>
                  <span className="badge badge-neutral flex-shrink-0">
                    {s.enrollments?.[0]?.group.name ?? 'без группы'}
                  </span>
                </Link>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}

function FamilyForm({
  form, setForm, onCancel, onSubmit, saving, submitLabel,
}: {
  form: { name: string; note: string };
  setForm: (f: { name: string; note: string }) => void;
  onCancel: () => void;
  onSubmit: () => void;
  saving: boolean;
  submitLabel: string;
}) {
  return (
    <div className="card border-ochre/30 bg-ochre/4 space-y-3">
      <div>
        <label className="text-xs font-semibold text-muted mb-1 block">Название семьи</label>
        <input
          className="input"
          placeholder="например, Семья Орловых"
          value={form.name}
          onChange={(e) => setForm({ ...form, name: e.target.value })}
        />
      </div>
      <div>
        <label className="text-xs font-semibold text-muted mb-1 block">Заметка (необязательно)</label>
        <input
          className="input"
          placeholder="контакты, особенности..."
          value={form.note}
          onChange={(e) => setForm({ ...form, note: e.target.value })}
        />
      </div>
      <div className="flex gap-2">
        <button onClick={onSubmit} disabled={saving} className="btn-primary flex-1 justify-center">
          <Check size={14} /> {saving ? 'Сохранение...' : submitLabel}
        </button>
        <button onClick={onCancel} className="btn-secondary"><X size={14} /></button>
      </div>
    </div>
  );
}

function PageSkeleton() {
  return (
    <div className="space-y-6 animate-pulse">
      <div className="h-8 w-48 bg-line rounded-xl" />
      <div className="card h-24 bg-line border-0" />
      <div className="card h-24 bg-line border-0" />
    </div>
  );
}
