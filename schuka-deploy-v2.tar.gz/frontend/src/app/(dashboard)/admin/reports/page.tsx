'use client';
// Отчёты руководителя: еженедельная сводка по школе + дети, требующие внимания
// (частые пропуски / давно нет комментария педагога). Данные считаются на лету
// из уже существующих модулей — отдельной таблицы отчётов в системе нет.
import { useEffect, useState } from 'react';
import {
  Calendar, Users, TrendingUp, CreditCard, Image, MessageSquare, ClipboardList,
  Package, ListTodo, Cake, AlertTriangle, MessageSquareOff, Send, Check, Settings2,
} from 'lucide-react';
import { api } from '@/lib/api';
import type { WeeklySummary, AttentionAlert } from '@/types';

const TABS = [
  { key: 'weekly', label: 'Еженедельная сводка' },
  { key: 'attention', label: 'Требуют внимания' },
] as const;

export default function AdminReports() {
  const [tab, setTab] = useState<(typeof TABS)[number]['key']>('weekly');
  const [summary, setSummary] = useState<WeeklySummary | null>(null);
  const [alerts, setAlerts] = useState<AttentionAlert[] | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    Promise.all([
      api.get('/reports/weekly-summary').then((r) => setSummary(r.data)),
      api.get('/reports/attention').then((r) => setAlerts(r.data)),
    ]).finally(() => setLoading(false));
  }, []);

  return (
    <div className="space-y-6">
      <div className="flex items-start justify-between gap-3 flex-wrap">
        <div>
          <p className="text-sm text-muted">Руководителю</p>
          <h1 className="text-2xl font-extrabold text-ink tracking-tight">Отчёты</h1>
        </div>
        <TelegramSendButton />
      </div>

      <TelegramSettings />

      <div className="flex gap-2 border-b border-line">
        {TABS.map((t) => (
          <button
            key={t.key}
            onClick={() => setTab(t.key)}
            className={`px-3 py-2 text-sm font-semibold border-b-2 -mb-px transition-colors ${
              tab === t.key ? 'border-ink text-ink' : 'border-transparent text-muted hover:text-ink'
            }`}
          >
            {t.label}
            {t.key === 'attention' && alerts && alerts.length > 0 && (
              <span className="ml-1.5 inline-flex items-center justify-center w-5 h-5 rounded-full bg-terra/10 text-terra text-xs font-bold">
                {alerts.length}
              </span>
            )}
          </button>
        ))}
      </div>

      {loading ? (
        <PageSkeleton />
      ) : tab === 'weekly' ? (
        <WeeklyTab summary={summary} />
      ) : (
        <AttentionTab alerts={alerts ?? []} />
      )}
    </div>
  );
}

function WeeklyTab({ summary }: { summary: WeeklySummary | null }) {
  if (!summary) return null;
  const from = new Date(summary.period.from).toLocaleDateString('ru-RU');
  const to = new Date(summary.period.to).toLocaleDateString('ru-RU');

  return (
    <div className="space-y-6">
      <p className="text-xs text-muted">Период: {from} — {to}</p>

      <div className="grid grid-cols-2 gap-4">
        <StatCard icon={Calendar} color="ink" value={String(summary.lessonsHeld)} label="Занятий проведено" />
        <StatCard
          icon={Users}
          color="sage"
          value={summary.attendance.rate !== null ? `${summary.attendance.rate}%` : '—'}
          label="Посещаемость"
        />
        <StatCard
          icon={TrendingUp}
          color="ochre"
          value={String(summary.enrollments.new)}
          label="Новых зачислений"
        />
        <StatCard
          icon={CreditCard}
          color="sage"
          value={`${summary.revenue.collected.toLocaleString('ru-RU')} ₽`}
          label="Собрано оплат"
        />
      </div>

      <div className="card">
        <h2 className="font-bold text-ink mb-4">Посещаемость за период</h2>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-center">
          <MiniStat value={summary.attendance.present} label="Были" color="text-sage" />
          <MiniStat value={summary.attendance.absent} label="Пропуски" color="text-terra" />
          <MiniStat value={summary.attendance.excused} label="Уважит." color="text-ochre" />
          <MiniStat value={summary.attendance.makeup} label="Отработки" color="text-ink" />
        </div>
      </div>

      <div className="card">
        <h2 className="font-bold text-ink mb-4">Оплаты</h2>
        <div className="space-y-2 text-sm">
          <Row label="Собрано за период" value={`${summary.revenue.collected.toLocaleString('ru-RU')} ₽`} />
          <Row label="Ожидается" value={`${summary.revenue.pendingAmount.toLocaleString('ru-RU')} ₽ (${summary.revenue.pendingCount})`} />
          <Row label="Просрочено" value={`${summary.revenue.overdueAmount.toLocaleString('ru-RU')} ₽ (${summary.revenue.overdueCount})`} accent={summary.revenue.overdueCount > 0} />
        </div>
      </div>

      <div className="card">
        <h2 className="font-bold text-ink mb-4">Активность педагогов</h2>
        <div className="grid grid-cols-3 gap-3 text-center">
          <MiniStat value={summary.activity.newPhotos} label="Фото" icon={Image} />
          <MiniStat value={summary.activity.newComments} label="Комментарии" icon={MessageSquare} />
          <MiniStat value={summary.activity.newHomework} label="Задания" icon={ClipboardList} />
        </div>
      </div>

      {(summary.inventory.lowStockCount > 0 || summary.tasks.open > 0 || summary.birthdays.length > 0) && (
        <div className="card">
          <h2 className="font-bold text-ink mb-4">Организационное</h2>
          <div className="space-y-2 text-sm">
            {summary.inventory.lowStockCount > 0 && (
              <Row icon={Package} label="Нужно закупить" value={`${summary.inventory.lowStockCount} поз.`} accent />
            )}
            {summary.tasks.open > 0 && (
              <Row icon={ListTodo} label="Открытых задач" value={String(summary.tasks.open)} />
            )}
            {summary.birthdays.length > 0 && (
              <Row icon={Cake} label="Дни рождения" value={summary.birthdays.map((b) => b.name).join(', ')} />
            )}
          </div>
        </div>
      )}
    </div>
  );
}

function AttentionTab({ alerts }: { alerts: AttentionAlert[] }) {
  if (alerts.length === 0) {
    return (
      <div className="card text-center py-14 text-muted">
        <p className="text-sm">Сейчас никто не требует особого внимания 👍</p>
      </div>
    );
  }
  return (
    <div className="space-y-2">
      {alerts.map((a, idx) => (
        <div
          key={`${a.studentId}-${a.type}-${idx}`}
          className={`card flex items-start gap-3 ${a.severity === 'high' ? 'border-terra/30 bg-terra/4' : ''}`}
        >
          <div className={`w-8 h-8 rounded-xl flex items-center justify-center flex-shrink-0 ${
            a.type === 'ATTENDANCE' ? 'text-terra bg-terra/8' : 'text-ochre bg-ochre/8'
          }`}>
            {a.type === 'ATTENDANCE' ? <AlertTriangle size={15} /> : <MessageSquareOff size={15} />}
          </div>
          <div className="min-w-0">
            <p className="text-sm font-semibold text-ink">{a.name} <span className="text-muted font-normal">· {a.groupName}</span></p>
            <p className="text-xs text-muted mt-0.5">{a.detail}</p>
          </div>
        </div>
      ))}
    </div>
  );
}

function StatCard({ icon: Icon, color, value, label }: { icon: React.ElementType; color: string; value: string; label: string }) {
  const colorMap: Record<string, string> = {
    ochre: 'text-ochre bg-ochre/8', sage: 'text-sage bg-sage/8', terra: 'text-terra bg-terra/8', ink: 'text-ink bg-ink/8',
  };
  return (
    <div className="card">
      <div className={`w-9 h-9 rounded-xl flex items-center justify-center mb-3 ${colorMap[color]}`}>
        <Icon size={18} />
      </div>
      <p className="text-xl font-extrabold text-ink tracking-tight">{value}</p>
      <p className="text-sm font-semibold text-ink mt-0.5">{label}</p>
    </div>
  );
}

function MiniStat({ value, label, color, icon: Icon }: { value: number; label: string; color?: string; icon?: React.ElementType }) {
  return (
    <div>
      {Icon && <Icon size={14} className="mx-auto mb-1 text-muted" />}
      <p className={`text-lg font-extrabold ${color ?? 'text-ink'}`}>{value}</p>
      <p className="text-xs text-muted">{label}</p>
    </div>
  );
}

function Row({ icon: Icon, label, value, accent }: { icon?: React.ElementType; label: string; value: string; accent?: boolean }) {
  return (
    <div className="flex items-center justify-between gap-3">
      <span className="text-muted flex items-center gap-1.5">{Icon && <Icon size={13} />} {label}</span>
      <span className={`font-semibold ${accent ? 'text-terra' : 'text-ink'}`}>{value}</span>
    </div>
  );
}

function TelegramSendButton() {
  const [sending, setSending] = useState(false);
  const [sent, setSent] = useState(false);
  const [error, setError] = useState('');

  const send = async () => {
    setSending(true);
    setError('');
    setSent(false);
    try {
      await api.post('/reports/send-telegram');
      setSent(true);
      setTimeout(() => setSent(false), 4000);
    } catch (e: any) {
      setError(e?.response?.data?.message ?? 'Не удалось отправить');
    } finally {
      setSending(false);
    }
  };

  return (
    <div className="flex flex-col items-end gap-1">
      <button onClick={send} disabled={sending} className="btn-secondary">
        {sent ? <Check size={14} /> : <Send size={14} />}
        {sending ? 'Отправка...' : sent ? 'Отправлено' : 'Отправить в Telegram'}
      </button>
      {error && <p className="text-xs text-terra">{error}</p>}
    </div>
  );
}

function TelegramSettings() {
  const [open, setOpen] = useState(false);
  const [chatId, setChatId] = useState('');
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);

  const save = async () => {
    if (!chatId.trim()) return;
    setSaving(true);
    try {
      await api.patch('/auth/me/telegram', { telegramChatId: chatId.trim() });
      setSaved(true);
      setTimeout(() => setSaved(false), 4000);
    } finally {
      setSaving(false);
    }
  };

  if (!open) {
    return (
      <button onClick={() => setOpen(true)} className="text-xs text-muted hover:text-ink flex items-center gap-1 -mt-3">
        <Settings2 size={12} /> Настроить Telegram-чат
      </button>
    );
  }

  return (
    <div className="card border-ochre/30 bg-ochre/4 space-y-2">
      <p className="text-sm font-semibold text-ink">Привязка Telegram</p>
      <p className="text-xs text-muted">
        Откройте бота Schuka OS в Telegram, отправьте ему любое сообщение — и вставьте сюда свой chat_id.
      </p>
      <div className="flex gap-2">
        <input
          className="input"
          placeholder="Ваш Telegram chat_id"
          value={chatId}
          onChange={(e) => setChatId(e.target.value)}
        />
        <button onClick={save} disabled={saving || !chatId.trim()} className="btn-primary">
          {saved ? <Check size={14} /> : null} {saving ? 'Сохранение...' : saved ? 'Сохранено' : 'Сохранить'}
        </button>
      </div>
    </div>
  );
}

function PageSkeleton() {
  return (
    <div className="space-y-6 animate-pulse">
      <div className="grid grid-cols-2 gap-4">
        {[0, 1, 2, 3].map((i) => <div key={i} className="h-24 card bg-line border-0" />)}
      </div>
      <div className="card h-32 bg-line border-0" />
    </div>
  );
}
