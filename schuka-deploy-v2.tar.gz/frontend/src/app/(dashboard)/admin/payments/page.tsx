'use client';
// Панель руководителя — управление оплатами.
import { useEffect, useState } from 'react';
import { CreditCard, Check, X } from 'lucide-react';
import { api } from '@/lib/api';
import type { Payment } from '@/types';

const STATUS_MAP: Record<string, { label: string; cls: string }> = {
  PAID: { label: 'Оплачено', cls: 'badge-success' },
  PENDING: { label: 'Ожидается', cls: 'badge-warning' },
  OVERDUE: { label: 'Просрочено', cls: 'badge-danger' },
  REFUNDED: { label: 'Возврат', cls: 'badge-neutral' },
  CANCELLED: { label: 'Отменено', cls: 'badge-neutral' },
};

const METHODS = [
  { key: 'CASH', label: 'Наличные' },
  { key: 'CARD', label: 'Карта' },
  { key: 'TRANSFER', label: 'Перевод' },
  { key: 'ONLINE', label: 'Онлайн' },
];

const FILTERS = [
  { key: 'ALL', label: 'Все' },
  { key: 'PENDING', label: 'Ожидается' },
  { key: 'OVERDUE', label: 'Просрочено' },
  { key: 'PAID', label: 'Оплачено' },
];

export default function AdminPayments() {
  const [payments, setPayments] = useState<Payment[]>([]);
  const [filter, setFilter] = useState('ALL');
  const [loading, setLoading] = useState(true);
  const [markingId, setMarkingId] = useState('');
  const [method, setMethod] = useState('CASH');
  const [busyId, setBusyId] = useState('');

  const load = () => api.get('/payments').then((r) => setPayments(r.data)).finally(() => setLoading(false));

  useEffect(() => { load(); }, []);

  const filtered = filter === 'ALL' ? payments : payments.filter((p) => p.status === filter);
  const totalRevenue = payments.filter((p) => p.status === 'PAID').reduce((s, p) => s + Number(p.amount), 0);
  const totalDue = payments.filter((p) => p.status === 'PENDING' || p.status === 'OVERDUE').reduce((s, p) => s + Number(p.amount), 0);

  const markPaid = async (id: string) => {
    setBusyId(id);
    try {
      await api.patch(`/payments/${id}/mark-paid`, { method });
      setMarkingId('');
      await load();
    } finally {
      setBusyId('');
    }
  };

  const markOverdue = async (id: string) => {
    setBusyId(id);
    try {
      await api.patch(`/payments/${id}/mark-overdue`);
      await load();
    } finally {
      setBusyId('');
    }
  };

  if (loading) return <PageSkeleton />;

  return (
    <div className="space-y-6">
      <div>
        <p className="text-sm text-muted">Управление</p>
        <h1 className="text-2xl font-extrabold text-ink tracking-tight">Оплаты</h1>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div className="card">
          <p className="text-xs text-muted mb-1">Получено</p>
          <p className="text-xl font-extrabold text-sage">{totalRevenue.toLocaleString('ru-RU')} ₽</p>
        </div>
        <div className="card">
          <p className="text-xs text-muted mb-1">К получению</p>
          <p className="text-xl font-extrabold text-terra">{totalDue.toLocaleString('ru-RU')} ₽</p>
        </div>
      </div>

      <div className="flex gap-2 overflow-x-auto pb-1">
        {FILTERS.map((f) => (
          <button
            key={f.key}
            onClick={() => setFilter(f.key)}
            className={`flex-shrink-0 px-3.5 py-1.5 rounded-lg text-xs font-semibold border transition-all
              ${filter === f.key ? 'bg-ink text-white border-ink' : 'bg-white text-muted border-line hover:border-ink/20 hover:text-ink'}`}
          >
            {f.label}
          </button>
        ))}
      </div>

      {filtered.length === 0 ? (
        <div className="card text-center py-14 text-muted">
          <CreditCard size={36} className="mx-auto mb-3 opacity-30" />
          <p className="text-sm">Платежей не найдено</p>
        </div>
      ) : (
        <div className="space-y-2">
          {filtered.map((p) => {
            const st = STATUS_MAP[p.status] ?? STATUS_MAP.PENDING;
            const sub: any = p.subscription;
            const isBusy = busyId === p.id;
            return (
              <div key={p.id} className="card space-y-3">
                <div className="flex items-center gap-3">
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-semibold text-ink truncate">
                      {sub?.enrollment?.student
                        ? `${sub.enrollment.student.firstName} ${sub.enrollment.student.lastName}`
                        : 'Абонемент'}
                    </p>
                    <p className="text-xs text-muted">
                      {sub?.enrollment?.group?.name ?? ''}
                      {p.dueDate && ` · до ${new Date(p.dueDate).toLocaleDateString('ru-RU')}`}
                    </p>
                  </div>
                  <p className="text-sm font-bold text-ink flex-shrink-0">{Number(p.amount).toLocaleString('ru-RU')} ₽</p>
                  <span className={`badge ${st.cls} flex-shrink-0`}>{st.label}</span>
                </div>

                {(p.status === 'PENDING' || p.status === 'OVERDUE') && (
                  markingId === p.id ? (
                    <div className="flex items-center gap-2 pt-2 border-t border-line">
                      <select className="input flex-1" value={method} onChange={(e) => setMethod(e.target.value)}>
                        {METHODS.map((m) => <option key={m.key} value={m.key}>{m.label}</option>)}
                      </select>
                      <button onClick={() => markPaid(p.id)} disabled={isBusy} className="btn-primary text-xs py-2">
                        <Check size={13} /> Подтвердить
                      </button>
                      <button onClick={() => setMarkingId('')} className="btn-secondary p-2"><X size={14} /></button>
                    </div>
                  ) : (
                    <div className="flex gap-2 pt-2 border-t border-line">
                      <button onClick={() => setMarkingId(p.id)} className="btn-secondary flex-1 justify-center text-xs py-2">
                        Отметить оплаченным
                      </button>
                      {p.status === 'PENDING' && (
                        <button onClick={() => markOverdue(p.id)} disabled={isBusy} className="btn-ghost text-xs py-2 text-terra">
                          Просрочено
                        </button>
                      )}
                    </div>
                  )
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

function PageSkeleton() {
  return (
    <div className="space-y-6 animate-pulse">
      <div className="h-8 w-40 bg-line rounded-xl" />
      <div className="grid grid-cols-2 gap-4">
        <div className="card h-20 bg-line border-0" />
        <div className="card h-20 bg-line border-0" />
      </div>
      <div className="card h-24 bg-line border-0" />
    </div>
  );
}
