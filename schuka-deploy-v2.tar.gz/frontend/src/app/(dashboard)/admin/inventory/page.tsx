'use client';
// Инвентаризация — расходники школы (бумага, краски, мыло...) с сигналом,
// когда пора закупить. Сигнал также приходит в колокольчик уведомлений.
import { useEffect, useState } from 'react';
import { Package, Plus, Trash2, Pencil, X, Check, AlertTriangle } from 'lucide-react';
import { api } from '@/lib/api';
import type { InventoryItem } from '@/types';

const EMPTY_FORM = { name: '', unit: 'шт', quantity: '', minQuantity: '', note: '' };

export default function AdminInventory() {
  const [items, setItems] = useState<InventoryItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [editingId, setEditingId] = useState('');
  const [form, setForm] = useState(EMPTY_FORM);
  const [saving, setSaving] = useState(false);

  const load = () => {
    setLoading(true);
    return api.get('/inventory').then((r) => setItems(r.data)).finally(() => setLoading(false));
  };

  useEffect(() => { load(); }, []);

  const startCreate = () => { setForm(EMPTY_FORM); setShowForm(true); setEditingId(''); };
  const startEdit = (i: InventoryItem) => {
    setForm({ name: i.name, unit: i.unit, quantity: String(i.quantity), minQuantity: String(i.minQuantity), note: i.note ?? '' });
    setEditingId(i.id);
    setShowForm(false);
  };
  const cancel = () => { setShowForm(false); setEditingId(''); };

  const payload = () => ({
    name: form.name,
    unit: form.unit || 'шт',
    quantity: form.quantity === '' ? undefined : Number(form.quantity),
    minQuantity: form.minQuantity === '' ? undefined : Number(form.minQuantity),
    note: form.note || undefined,
  });

  const submitCreate = async () => {
    if (!form.name.trim()) return;
    setSaving(true);
    try {
      await api.post('/inventory', payload());
      setShowForm(false);
      await load();
    } finally {
      setSaving(false);
    }
  };

  const submitEdit = async (id: string) => {
    if (!form.name.trim()) return;
    setSaving(true);
    try {
      await api.patch(`/inventory/${id}`, payload());
      setEditingId('');
      await load();
    } finally {
      setSaving(false);
    }
  };

  const remove = async (id: string) => {
    if (!confirm('Удалить позицию из инвентаризации?')) return;
    await api.delete(`/inventory/${id}`);
    await load();
  };

  if (loading) return <PageSkeleton />;

  const lowCount = items.filter((i) => i.low).length;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <p className="text-sm text-muted">Управление</p>
          <h1 className="text-2xl font-extrabold text-ink tracking-tight">Инвентаризация</h1>
        </div>
        <button onClick={startCreate} className="btn-primary">
          <Plus size={16} /> Добавить позицию
        </button>
      </div>

      {lowCount > 0 && (
        <div className="card border-terra/30 bg-terra/6 flex items-center gap-2 text-sm text-terra font-semibold">
          <AlertTriangle size={16} /> Пора закупить: {lowCount} {lowCount === 1 ? 'позиция' : 'позиции'}
        </div>
      )}

      {showForm && (
        <ItemForm form={form} setForm={setForm} onCancel={cancel} onSubmit={submitCreate} saving={saving} submitLabel="Добавить" />
      )}

      {items.length === 0 ? (
        <div className="card text-center py-14 text-muted">
          <Package size={36} className="mx-auto mb-3 opacity-30" />
          <p className="text-sm">Список пока пуст</p>
        </div>
      ) : (
        <div className="space-y-2">
          {items.map((i) => (
            <div key={i.id} className={`card ${i.low ? 'border-terra/30 bg-terra/4' : ''}`}>
              {editingId === i.id ? (
                <ItemForm form={form} setForm={setForm} onCancel={cancel} onSubmit={() => submitEdit(i.id)} saving={saving} submitLabel="Сохранить" />
              ) : (
                <div className="flex items-center justify-between gap-3">
                  <div className="min-w-0">
                    <p className="text-sm font-semibold text-ink flex items-center gap-1.5">
                      {i.low && <AlertTriangle size={13} className="text-terra flex-shrink-0" />}
                      {i.name}
                    </p>
                    <p className="text-xs text-muted mt-0.5">
                      Остаток: {i.quantity} {i.unit} {i.minQuantity > 0 && `(порог: ${i.minQuantity} ${i.unit})`}
                    </p>
                    {i.note && <p className="text-xs text-muted mt-0.5">{i.note}</p>}
                  </div>
                  <div className="flex gap-1 flex-shrink-0">
                    <button onClick={() => startEdit(i)} className="btn-ghost p-2"><Pencil size={14} /></button>
                    <button onClick={() => remove(i.id)} className="btn-ghost p-2 text-terra hover:bg-terra/8"><Trash2 size={14} /></button>
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

function ItemForm({
  form, setForm, onCancel, onSubmit, saving, submitLabel,
}: {
  form: typeof EMPTY_FORM;
  setForm: (f: typeof EMPTY_FORM) => void;
  onCancel: () => void;
  onSubmit: () => void;
  saving: boolean;
  submitLabel: string;
}) {
  return (
    <div className="card border-ochre/30 bg-ochre/4 space-y-3">
      <input className="input" placeholder="Название (например, бумага туалетная)" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
      <div className="flex gap-2">
        <input className="input" placeholder="Ед. изм. (шт, уп, л...)" value={form.unit} onChange={(e) => setForm({ ...form, unit: e.target.value })} />
        <input type="number" min={0} step="0.1" className="input" placeholder="Остаток" value={form.quantity} onChange={(e) => setForm({ ...form, quantity: e.target.value })} />
        <input type="number" min={0} step="0.1" className="input" placeholder="Порог закупки" value={form.minQuantity} onChange={(e) => setForm({ ...form, minQuantity: e.target.value })} />
      </div>
      <input className="input" placeholder="Заметка (необязательно)" value={form.note} onChange={(e) => setForm({ ...form, note: e.target.value })} />
      <div className="flex gap-2">
        <button onClick={onSubmit} disabled={saving || !form.name.trim()} className="btn-primary flex-1 justify-center">
          <Check size={14} /> {saving ? 'Сохранение...' : submitLabel}
        </button>
        <button onClick={onCancel} className="btn-secondary"><X size={14} /></button>
      </div>
    </div>
  );
}

function PageSkeleton() {
  return (
    <div className="space-y-6 animate-pulse">
      <div className="h-8 w-48 bg-line rounded-xl" />
      <div className="card h-16 bg-line border-0" />
      <div className="card h-16 bg-line border-0" />
    </div>
  );
}
