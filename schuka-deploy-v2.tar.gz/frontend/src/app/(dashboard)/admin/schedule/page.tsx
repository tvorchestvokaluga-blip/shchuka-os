'use client';
// Панель руководителя — расписание всех групп.
// Клик по занятию открывает карточку группы на вкладке «Уроки и темы» —
// там видно тему, материалы и посещаемость конкретного прошедшего или
// будущего урока, и можно их отредактировать.
import { useEffect, useState } from 'react';
import Link from 'next/link';
import { Calendar, MapPin } from 'lucide-react';
import { api } from '@/lib/api';
import type { Group } from '@/types';

const WEEKDAYS = [
  { key: 'MON', label: 'Понедельник' },
  { key: 'TUE', label: 'Вторник' },
  { key: 'WED', label: 'Среда' },
  { key: 'THU', label: 'Четверг' },
  { key: 'FRI', label: 'Пятница' },
  { key: 'SAT', label: 'Суббота' },
  { key: 'SUN', label: 'Воскресенье' },
];

interface ScheduleItem {
  groupId: string;
  groupName: string;
  teacher?: string;
  startTime: string;
  endTime: string;
  room?: string;
}

export default function AdminSchedule() {
  const [groups, setGroups] = useState<Group[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api.get('/groups').then((r) => setGroups(r.data)).finally(() => setLoading(false));
  }, []);

  if (loading) return <PageSkeleton />;

  const byDay: Record<string, ScheduleItem[]> = {};
  WEEKDAYS.forEach((d) => (byDay[d.key] = []));
  groups.forEach((g) => {
    (g.scheduleSlots ?? []).forEach((slot) => {
      byDay[slot.weekday]?.push({
        groupId: g.id,
        groupName: g.name,
        teacher: g.teacher?.user?.fullName,
        startTime: slot.startTime,
        endTime: slot.endTime,
        room: slot.room,
      });
    });
  });
  const hasAny = Object.values(byDay).some((d) => d.length > 0);

  return (
    <div className="space-y-6">
      <div>
        <p className="text-sm text-muted">Управление</p>
        <h1 className="text-2xl font-extrabold text-ink tracking-tight">Расписание школы</h1>
        <p className="text-xs text-muted mt-1">Нажмите на занятие, чтобы открыть уроки и темы этой группы</p>
      </div>

      {!hasAny ? (
        <div className="card text-center py-14 text-muted">
          <Calendar size={36} className="mx-auto mb-3 opacity-30" />
          <p className="text-sm">Расписание пока не сформировано</p>
        </div>
      ) : (
        <div className="space-y-4">
          {WEEKDAYS.filter((d) => byDay[d.key].length > 0).map((d) => (
            <div key={d.key} className="card">
              <h2 className="font-bold text-ink mb-3">{d.label}</h2>
              <div className="space-y-2">
                {byDay[d.key]
                  .sort((a, b) => a.startTime.localeCompare(b.startTime))
                  .map((item, i) => (
                    <Link
                      key={i}
                      href={`/admin/groups/${item.groupId}?tab=curriculum`}
                      className="flex items-center gap-3 p-3 rounded-xl bg-paper-dark hover:bg-ochre/10 transition-colors"
                    >
                      <div className="w-16 flex-shrink-0 text-sm font-bold text-ochre">{item.startTime}</div>
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-semibold text-ink">{item.groupName}</p>
                        {item.teacher && <p className="text-xs text-muted">{item.teacher}</p>}
                      </div>
                      {item.room && (
                        <div className="flex items-center gap-1 text-xs text-muted flex-shrink-0">
                          <MapPin size={12} />{item.room}
                        </div>
                      )}
                    </Link>
                  ))}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

function PageSkeleton() {
  return (
    <div className="space-y-6 animate-pulse">
      <div className="h-8 w-48 bg-line rounded-xl" />
      <div className="card h-24 bg-line border-0" />
      <div className="card h-24 bg-line border-0" />
    </div>
  );
}
