'use client';
// Карточка ученика — вид руководителя/администратора. Полное досье:
// личные данные (с редактированием), уроки по каждому зачислению с темами
// и отметками посещения, пропущенные темы отдельным блоком, оплаты,
// навыки, достижения, фото, план развития и комментарии педагогов.
// Опирается на тот же эндпоинт «Паспорт художника», что видят родитель и педагог.
import { useEffect, useState } from 'react';
import Link from 'next/link';
import {
  ArrowLeft, Award, Image, TrendingUp, MessageSquare, Cake, Target,
  Pencil, Check, X, BookOpen, CreditCard, CalendarX,
} from 'lucide-react';
import { api, resolveFileUrl } from '@/lib/api';
import type { ArtistPassport, PassportLesson } from '@/types';
import { format, differenceInYears } from 'date-fns';
import { ru } from 'date-fns/locale';

export default function AdminStudentCard({ params }: { params: { id: string } }) {
  const studentId = params.id;
  const [passport, setPassport] = useState<ArtistPassport | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);

  const load = () => {
    api.get(`/students/${studentId}/passport`)
      .then((r) => setPassport(r.data))
      .catch(() => setError(true))
      .finally(() => setLoading(false));
  };

  useEffect(() => { if (studentId) load(); }, [studentId]);

  if (loading) {
    return (
      <div className="space-y-6 animate-pulse">
        <div className="h-8 w-40 bg-line rounded-xl" />
        <div className="card h-40 bg-line border-0" />
      </div>
    );
  }
  if (error || !passport) {
    return (
      <div className="space-y-4">
        <BackLink />
        <div className="card text-center py-10 text-muted">
          Карточка недоступна — либо ребёнок не найден, либо нет доступа
        </div>
      </div>
    );
  }

  const { student, skills, achievements, summary, timeline, photos, enrollments, developmentPlans, payments } = passport;
  const age = student.birthDate ? differenceInYears(new Date(), new Date(student.birthDate)) : null;

  return (
    <div className="space-y-6">
      <BackLink />

      {/* шапка — с редактированием */}
      <StudentHeader student={student} age={age} summary={summary} onSaved={load} />

      {/* уроки по каждому зачислению */}
      {enrollments.map((e) => (
        <LessonsCard key={e.id} enrollment={e} />
      ))}

      {/* оплаты */}
      <PaymentsCard payments={payments} />

      {/* план развития */}
      <DevelopmentPlanSection studentId={studentId} plans={developmentPlans} onSaved={load} />

      {/* навыки */}
      {skills.length > 0 && (
        <div className="card">
          <div className="flex items-center gap-2 mb-4">
            <TrendingUp size={16} className="text-ochre" />
            <h2 className="font-bold text-ink">Навыки</h2>
          </div>
          <div className="space-y-3">
            {skills.map((s) => (
              <div key={s.name}>
                <div className="flex justify-between text-sm mb-1.5">
                  <span className="font-medium text-ink">{s.name}</span>
                  <span className="text-muted text-xs">{s.level} / 5</span>
                </div>
                <div className="skill-bar">
                  <div className="skill-fill" style={{ width: `${(s.level / 5) * 100}%` }} />
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* достижения */}
      {achievements.length > 0 && (
        <div className="card">
          <div className="flex items-center gap-2 mb-4">
            <Award size={16} className="text-ochre" />
            <h2 className="font-bold text-ink">Достижения</h2>
          </div>
          <div className="flex flex-wrap gap-2">
            {achievements.map((a) => (
              <div key={a.title} className="flex items-center gap-2 px-3 py-2 rounded-xl bg-paper-dark border border-line">
                <span className="text-lg">{a.icon ?? '🏅'}</span>
                <span className="text-sm font-semibold text-ink">{a.title}</span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* фото */}
      {photos.length > 0 && (
        <div className="card">
          <div className="flex items-center gap-2 mb-4">
            <Image size={16} className="text-ochre" />
            <h2 className="font-bold text-ink">Работы и фото</h2>
          </div>
          <div className="grid grid-cols-3 gap-2">
            {photos.map((photo) => (
              <div key={photo.id} className="rounded-xl overflow-hidden bg-paper-dark border border-line">
                <div className="aspect-square flex items-center justify-center">
                  {photo.url.startsWith('seed/') || photo.url.startsWith('__') ? (
                    <span className="text-3xl">🖼️</span>
                  ) : (
                    <img src={resolveFileUrl(photo.url)} alt={photo.caption ?? ''} className="w-full h-full object-cover" />
                  )}
                </div>
                {photo.lesson?.date && (
                  <p className="text-[10px] text-muted px-1.5 py-1 truncate">
                    {format(new Date(photo.lesson.date), 'd MMM', { locale: ru })}
                    {photo.lesson.topic ? ` · ${photo.lesson.topic}` : ''}
                  </p>
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* комментарии */}
      {timeline.length > 0 && (
        <div className="card">
          <div className="flex items-center gap-2 mb-4">
            <MessageSquare size={16} className="text-ochre" />
            <h2 className="font-bold text-ink">Комментарии</h2>
          </div>
          <div className="space-y-4">
            {timeline.slice(0, 8).map((c) => (
              <div key={c.id} className="flex gap-3">
                <div className="w-8 h-8 rounded-xl bg-sage/10 flex items-center justify-center flex-shrink-0 text-sm">👩‍🎨</div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="text-sm font-semibold text-ink">{c.author.fullName}</span>
                    {c.aiAssisted && <span className="badge badge-neutral text-xs">AI-черновик</span>}
                    <span className="text-xs text-muted ml-auto">{format(new Date(c.createdAt), 'd MMM', { locale: ru })}</span>
                  </div>
                  <p className="text-sm text-ink/80 mt-1 leading-relaxed">{c.text}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

// ── шапка с редактированием ─────────────────────────────────────────────────
function StudentHeader({
  student, age, summary, onSaved,
}: {
  student: ArtistPassport['student'];
  age: number | null;
  summary: ArtistPassport['summary'];
  onSaved: () => void;
}) {
  const [editing, setEditing] = useState(false);
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState({
    firstName: student.firstName,
    lastName: student.lastName,
    birthDate: student.birthDate ? student.birthDate.slice(0, 10) : '',
    avatarEmoji: student.avatarEmoji ?? '',
    note: student.note ?? '',
  });

  const submit = async () => {
    setSaving(true);
    try {
      await api.patch(`/students/${student.id}`, {
        firstName: form.firstName,
        lastName: form.lastName,
        birthDate: form.birthDate || undefined,
        avatarEmoji: form.avatarEmoji || undefined,
        note: form.note || undefined,
      });
      setEditing(false);
      onSaved();
    } finally {
      setSaving(false);
    }
  };

  if (editing) {
    return (
      <div className="card space-y-3">
        <div className="grid grid-cols-2 gap-2">
          <div>
            <label className="text-xs font-semibold text-muted mb-1 block">Имя</label>
            <input className="input" value={form.firstName} onChange={(e) => setForm({ ...form, firstName: e.target.value })} />
          </div>
          <div>
            <label className="text-xs font-semibold text-muted mb-1 block">Фамилия</label>
            <input className="input" value={form.lastName} onChange={(e) => setForm({ ...form, lastName: e.target.value })} />
          </div>
        </div>
        <div className="grid grid-cols-2 gap-2">
          <div>
            <label className="text-xs font-semibold text-muted mb-1 block">Дата рождения</label>
            <input type="date" className="input" value={form.birthDate} onChange={(e) => setForm({ ...form, birthDate: e.target.value })} />
          </div>
          <div>
            <label className="text-xs font-semibold text-muted mb-1 block">Эмодзи-аватар</label>
            <input className="input" placeholder="🎨" value={form.avatarEmoji} onChange={(e) => setForm({ ...form, avatarEmoji: e.target.value })} />
          </div>
        </div>
        <div>
          <label className="text-xs font-semibold text-muted mb-1 block">Заметка</label>
          <textarea className="input min-h-[60px]" value={form.note} onChange={(e) => setForm({ ...form, note: e.target.value })} />
        </div>
        <div className="flex gap-2">
          <button onClick={submit} disabled={saving} className="btn-primary flex-1 justify-center">
            <Check size={14} /> {saving ? 'Сохранение...' : 'Сохранить'}
          </button>
          <button onClick={() => setEditing(false)} className="btn-secondary"><X size={14} /></button>
        </div>
      </div>
    );
  }

  return (
    <div className="card bg-ink text-white border-0">
      <div className="flex items-start gap-4">
        <div className="w-16 h-16 rounded-2xl bg-white/10 flex items-center justify-center text-3xl flex-shrink-0">
          {student.avatarEmoji ?? '🎨'}
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex items-start justify-between gap-2">
            <h1 className="text-xl font-extrabold tracking-tight">
              {student.firstName} {student.lastName}
            </h1>
            <button onClick={() => setEditing(true)} className="btn-ghost text-white/70 hover:text-white p-1.5 flex-shrink-0">
              <Pencil size={14} />
            </button>
          </div>
          <div className="flex items-center gap-3 mt-1 flex-wrap text-sm text-white/60">
            {student.birthDate ? (
              <span className="flex items-center gap-1">
                <Cake size={13} />
                {format(new Date(student.birthDate), 'd MMMM yyyy', { locale: ru })}
                {age !== null && ` · ${age} лет`}
              </span>
            ) : (
              <span className="text-white/40">Дата рождения не указана</span>
            )}
            {summary.memberSince && (
              <span>В школе с {format(new Date(summary.memberSince), 'LLLL yyyy', { locale: ru })}</span>
            )}
          </div>
          {student.note && <p className="text-xs text-white/50 mt-1.5">{student.note}</p>}
          <div className="flex gap-4 mt-3 flex-wrap">
            {[
              { v: summary.totalLessonsAttended, l: 'занятий было' },
              { v: summary.totalLessonsMissed, l: 'пропущено' },
              { v: summary.achievementsCount, l: 'достижений' },
              { v: summary.artworksCount, l: 'работ' },
            ].map(({ v, l }) => (
              <div key={l}>
                <span className="text-lg font-extrabold text-ochre">{v}</span>
                <span className="text-xs text-white/50 ml-1">{l}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

// ── уроки по зачислению ──────────────────────────────────────────────────────
function LessonsCard({ enrollment }: { enrollment: ArtistPassport['enrollments'][number] }) {
  const [showAll, setShowAll] = useState(false);
  const lessons = enrollment.lessons ?? [];
  const visible = showAll ? lessons : lessons.slice(0, 6);

  return (
    <div className="card">
      <div className="flex items-center justify-between mb-3 flex-wrap gap-2">
        <div className="flex items-center gap-2">
          <BookOpen size={16} className="text-ochre" />
          <h2 className="font-bold text-ink">{enrollment.group}</h2>
          <span className="text-xs text-muted">· {enrollment.program}</span>
        </div>
        {enrollment.attendanceRate !== null && (
          <span className="badge badge-neutral">{enrollment.attendanceRate}% посещаемость</span>
        )}
      </div>

      {enrollment.missedTopics.length > 0 && (
        <div className="mb-3 p-3 rounded-xl bg-terra/6 border border-terra/15">
          <div className="flex items-center gap-1.5 text-xs font-semibold text-terra mb-1.5">
            <CalendarX size={13} /> Пропущенные темы — можно наверстать
          </div>
          <div className="flex flex-wrap gap-1.5">
            {enrollment.missedTopics.map((l) => (
              <span key={l.id} className="badge badge-danger">
                {format(new Date(l.date), 'd MMM', { locale: ru })} · {l.topic}
              </span>
            ))}
          </div>
        </div>
      )}

      {lessons.length === 0 ? (
        <p className="text-sm text-muted">Занятий по программе пока не было</p>
      ) : (
        <>
          <div className="space-y-1.5">
            {visible.map((l) => (
              <LessonRow key={l.id} lesson={l} />
            ))}
          </div>
          {lessons.length > 6 && (
            <button onClick={() => setShowAll(!showAll)} className="btn-ghost text-xs mt-2 w-full justify-center">
              {showAll ? 'Свернуть' : `Показать все (${lessons.length})`}
            </button>
          )}
        </>
      )}
    </div>
  );
}

function LessonRow({ lesson }: { lesson: PassportLesson }) {
  const badge = {
    PRESENT: { cls: 'badge-success', label: 'был' },
    ABSENT: { cls: 'badge-danger', label: 'пропуск' },
    EXCUSED: { cls: 'badge-warning', label: 'уваж. причина' },
    MAKEUP: { cls: 'badge-neutral', label: 'отработка' },
  }[lesson.status];

  return (
    <div className="flex items-center gap-3 p-2.5 rounded-xl bg-paper-dark">
      <div className="w-16 flex-shrink-0 text-xs font-bold text-muted">
        {format(new Date(lesson.date), 'd MMM', { locale: ru })}
      </div>
      <div className="flex-1 min-w-0">
        <p className="text-sm text-ink truncate">{lesson.topic ?? 'Тема не указана'}</p>
      </div>
      <span className={`badge ${badge.cls} flex-shrink-0`}>{badge.label}</span>
    </div>
  );
}

// ── оплаты ───────────────────────────────────────────────────────────────────
function PaymentsCard({ payments }: { payments: ArtistPassport['payments'] }) {
  const statusMeta: Record<string, { cls: string; label: string }> = {
    PAID: { cls: 'badge-success', label: 'оплачено' },
    OVERDUE: { cls: 'badge-danger', label: 'просрочено' },
    PENDING: { cls: 'badge-warning', label: 'ожидает оплаты' },
    REFUNDED: { cls: 'badge-neutral', label: 'возврат' },
    CANCELLED: { cls: 'badge-neutral', label: 'отменено' },
  };

  return (
    <div className="card">
      <div className="flex items-center gap-2 mb-3">
        <CreditCard size={16} className="text-ochre" />
        <h2 className="font-bold text-ink">Оплаты</h2>
      </div>
      {payments.length === 0 ? (
        <p className="text-sm text-muted">Оплат пока нет</p>
      ) : (
        <div className="space-y-1.5">
          {payments.map((p) => {
            const meta = statusMeta[p.status] ?? statusMeta.PENDING;
            return (
              <div key={p.id} className="flex items-center gap-3 p-2.5 rounded-xl bg-paper-dark">
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-semibold text-ink">{Number(p.amount).toLocaleString('ru-RU')} ₽</p>
                  <p className="text-xs text-muted truncate">
                    {p.group} · {p.program} · {p.remainingLessons}/{p.totalLessons} занятий осталось
                  </p>
                </div>
                <div className="text-right flex-shrink-0">
                  <span className={`badge ${meta.cls}`}>{meta.label}</span>
                  {(p.paidAt || p.dueDate) && (
                    <p className="text-[10px] text-muted mt-1">
                      {p.paidAt
                        ? format(new Date(p.paidAt), 'd MMM yyyy', { locale: ru })
                        : `до ${format(new Date(p.dueDate!), 'd MMM yyyy', { locale: ru })}`}
                    </p>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

// ── план развития (как у педагога) ───────────────────────────────────────────
function DevelopmentPlanSection({ studentId, plans, onSaved }: { studentId: string; plans: ArtistPassport['developmentPlans']; onSaved: () => void }) {
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({ periodLabel: '', goals: '', focusAreas: '', notes: '' });
  const [saving, setSaving] = useState(false);
  const current = plans[0];

  const submit = async () => {
    if (!form.goals.trim()) return;
    setSaving(true);
    try {
      await api.post(`/students/${studentId}/development-plans`, {
        goals: form.goals,
        periodLabel: form.periodLabel || undefined,
        focusAreas: form.focusAreas || undefined,
        notes: form.notes || undefined,
      });
      setForm({ periodLabel: '', goals: '', focusAreas: '', notes: '' });
      setShowForm(false);
      onSaved();
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="card">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <Target size={16} className="text-ochre" />
          <h2 className="font-bold text-ink">План развития</h2>
        </div>
        {!showForm && (
          <button onClick={() => setShowForm(true)} className="btn-ghost text-xs">
            {current ? 'Обновить план' : 'Составить план'}
          </button>
        )}
      </div>

      {showForm && (
        <div className="space-y-2 mb-4 p-3 rounded-xl bg-ochre/4 border border-ochre/20">
          <input
            className="input"
            placeholder="Период (например, Осень 2026) — необязательно"
            value={form.periodLabel}
            onChange={(e) => setForm({ ...form, periodLabel: e.target.value })}
          />
          <textarea
            className="input min-h-[70px]"
            placeholder="Основные цели на период"
            value={form.goals}
            onChange={(e) => setForm({ ...form, goals: e.target.value })}
          />
          <textarea
            className="input min-h-[50px]"
            placeholder="На что сделать акцент (навыки, темы) — необязательно"
            value={form.focusAreas}
            onChange={(e) => setForm({ ...form, focusAreas: e.target.value })}
          />
          <textarea
            className="input min-h-[50px]"
            placeholder="Наблюдения о текущем прогрессе — необязательно"
            value={form.notes}
            onChange={(e) => setForm({ ...form, notes: e.target.value })}
          />
          <div className="flex gap-2">
            <button onClick={submit} disabled={saving || !form.goals.trim()} className="btn-primary flex-1 justify-center">
              <Check size={14} /> {saving ? 'Сохранение...' : 'Сохранить'}
            </button>
            <button onClick={() => setShowForm(false)} className="btn-secondary"><X size={14} /></button>
          </div>
        </div>
      )}

      {plans.length === 0 && !showForm ? (
        <p className="text-sm text-muted">План развития пока не составлен</p>
      ) : (
        <div className="space-y-3">
          {plans.map((p, idx) => (
            <div key={p.id} className={`p-3 rounded-xl ${idx === 0 ? 'bg-paper-dark' : 'bg-transparent border border-line'}`}>
              <div className="flex items-center justify-between gap-2 flex-wrap">
                <span className="text-xs font-semibold text-muted uppercase tracking-wide">
                  {idx === 0 ? 'Текущий план' : 'Из истории'} {p.periodLabel && `· ${p.periodLabel}`}
                </span>
                <span className="text-xs text-muted">{format(new Date(p.createdAt), 'd MMM yyyy', { locale: ru })} · {p.author.fullName}</span>
              </div>
              <p className="text-sm text-ink mt-1.5 leading-relaxed">{p.goals}</p>
              {p.focusAreas && <p className="text-xs text-muted mt-1"><b>Акцент:</b> {p.focusAreas}</p>}
              {p.notes && <p className="text-xs text-muted mt-1"><b>Наблюдения:</b> {p.notes}</p>}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

function BackLink() {
  return (
    <Link href="/admin/families" className="inline-flex items-center gap-1.5 text-sm text-muted hover:text-ink transition-colors">
      <ArrowLeft size={15} /> К семьям и детям
    </Link>
  );
}
