'use client';
// Панель руководителя — отработки пропущенных занятий.
// Создание слотов (обычно 2 в месяц, 8 мест) + список записавшихся с их
// пропущенными темами (считается автоматически по посещаемости).
import { useEffect, useState } from 'react';
import { CalendarClock, Plus, Trash2, Check, X, Users } from 'lucide-react';
import { api } from '@/lib/api';
import type { MakeupSlotStaffView } from '@/types';

export default function AdminMakeup() {
  const [slots, setSlots] = useState<MakeupSlotStaffView[]>([]);
  const [loading, setLoading] = useState(true);
  const [showCreate, setShowCreate] = useState(false);
  const [form, setForm] = useState({ date: '', time: '', capacity: 8, note: '' });
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');

  const load = () => {
    setLoading(true);
    return api.get('/makeup/slots').then((r) => setSlots(r.data)).finally(() => setLoading(false));
  };

  useEffect(() => { load(); }, []);

  const submitCreate = async () => {
    if (!form.date || !form.time) return;
    setSaving(true);
    setError('');
    try {
      const iso = new Date(`${form.date}T${form.time}`).toISOString();
      await api.post('/makeup/slots', { date: iso, capacity: Number(form.capacity) || 8, note: form.note || undefined });
      setShowCreate(false);
      setForm({ date: '', time: '', capacity: 8, note: '' });
      await load();
    } catch (e: any) {
      setError(e?.response?.data?.message ?? 'Не удалось создать слот');
    } finally {
      setSaving(false);
    }
  };

  const remove = async (id: string) => {
    if (!confirm('Отменить этот слот отработки? Все записи на него будут удалены.')) return;
    await api.delete(`/makeup/slots/${id}`);
    await load();
  };

  if (loading) return <PageSkeleton />;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <p className="text-sm text-muted">Расписание</p>
          <h1 className="text-2xl font-extrabold text-ink tracking-tight">Отработки пропущенных занятий</h1>
          <p className="text-sm text-muted mt-1">Обычно 2 слота в месяц, по 8 мест — запись по предзаписи.</p>
        </div>
        <button onClick={() => setShowCreate(!showCreate)} className="btn-primary"><Plus size={16} /> Добавить слот</button>
      </div>

      {showCreate && (
        <div className="card border-ochre/30 bg-ochre/4 space-y-3">
          {error && <p className="text-sm text-terra font-medium">{error}</p>}
          <div className="flex gap-2">
            <input type="date" className="input flex-1" value={form.date}
              onChange={(e) => setForm({ ...form, date: e.target.value })} />
            <input type="time" className="input flex-1" value={form.time}
              onChange={(e) => setForm({ ...form, time: e.target.value })} />
            <input type="number" min={1} className="input w-24" value={form.capacity}
              onChange={(e) => setForm({ ...form, capacity: Number(e.target.value) })} placeholder="Мест" />
          </div>
          <input className="input" placeholder="Примечание (например, кабинет)" value={form.note}
            onChange={(e) => setForm({ ...form, note: e.target.value })} />
          <div className="flex gap-2">
            <button onClick={submitCreate} disabled={saving} className="btn-primary flex-1 justify-center">
              <Check size={14} /> {saving ? 'Сохранение...' : 'Создать слот'}
            </button>
            <button onClick={() => setShowCreate(false)} className="btn-secondary"><X size={14} /></button>
          </div>
        </div>
      )}

      {slots.length === 0 ? (
        <div className="card text-center py-14 text-muted">
          <CalendarClock size={36} className="mx-auto mb-3 opacity-30" />
          <p className="text-sm">Слотов отработки пока нет</p>
        </div>
      ) : (
        <div className="space-y-4">
          {slots.map((slot) => (
            <div key={slot.id} className="card space-y-3">
              <div className="flex items-start justify-between gap-3">
                <div>
                  <p className="font-bold text-ink text-lg">
                    {new Date(slot.date).toLocaleString('ru-RU', { day: 'numeric', month: 'long', hour: '2-digit', minute: '2-digit' })}
                  </p>
                  {slot.note && <p className="text-sm text-muted">{slot.note}</p>}
                </div>
                <div className="flex items-center gap-2 flex-shrink-0">
                  <span className="badge badge-neutral">
                    <Users size={12} /> {slot.roster.length} / {slot.capacity}
                  </span>
                  <button onClick={() => remove(slot.id)} className="btn-ghost p-2 text-terra hover:bg-terra/8">
                    <Trash2 size={14} />
                  </button>
                </div>
              </div>

              {slot.roster.length === 0 ? (
                <p className="text-sm text-muted">Пока никто не записался</p>
              ) : (
                <div className="divide-y divide-line">
                  {slot.roster.map((r) => (
                    <div key={r.bookingId} className="py-2.5">
                      <p className="text-sm font-semibold text-ink">{r.studentName}</p>
                      {r.missedTopics.length === 0 ? (
                        <p className="text-xs text-muted">Пропущенных занятий не найдено</p>
                      ) : (
                        <ul className="mt-1 space-y-0.5">
                          {r.missedTopics.map((t, i) => (
                            <li key={i} className="text-xs text-muted">
                              {new Date(t.date).toLocaleDateString('ru-RU', { day: 'numeric', month: 'short' })} · {t.groupName}
                              {t.topic ? ` — ${t.topic}` : ''}
                            </li>
                          ))}
                        </ul>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

function PageSkeleton() {
  return (
    <div className="space-y-6 animate-pulse">
      <div className="h-8 w-72 bg-line rounded-xl" />
      <div className="card h-32 bg-line border-0" />
      <div className="card h-32 bg-line border-0" />
    </div>
  );
}
