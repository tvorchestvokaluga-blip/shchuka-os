'use client';
// Панель руководителя — «Сотрудники».
// Список педагогов и администраторов, добавление нового педагога, сброс пароля
// и включение/выключение доступа. Пароль показывается один раз сразу после
// создания или сброса — его нужно сразу скопировать/сфотографировать и
// передать сотруднику, второй раз его увидеть нельзя (хранится только хэш).
import { useEffect, useState } from 'react';
import { UserCog, Plus, Check, X, KeyRound, Power, Copy, BookOpen } from 'lucide-react';
import { api } from '@/lib/api';
import type { StaffMember } from '@/types';
import { format } from 'date-fns';
import { ru } from 'date-fns/locale';

const ROLE_LABEL: Record<string, string> = {
  OWNER: 'Руководитель', ADMIN: 'Администратор', TEACHER: 'Педагог',
};

export default function AdminStaff() {
  const [staff, setStaff] = useState<StaffMember[]>([]);
  const [loading, setLoading] = useState(true);
  const [showCreate, setShowCreate] = useState(false);
  const [reveal, setReveal] = useState<{ title: string; password: string } | null>(null);

  const load = () => api.get('/users').then((r) => setStaff(r.data)).finally(() => setLoading(false));
  useEffect(() => { load(); }, []);

  if (loading) return <PageSkeleton />;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <p className="text-sm text-muted">Управление</p>
          <h1 className="text-2xl font-extrabold text-ink tracking-tight">Сотрудники</h1>
          <p className="text-xs text-muted mt-1">
            Здесь можно дать педагогам их собственный вход в систему — чтобы заходили и работали сами.
          </p>
        </div>
        <button onClick={() => setShowCreate((s) => !s)} className="btn-primary">
          <Plus size={16} /> Добавить педагога
        </button>
      </div>

      {reveal && <PasswordReveal info={reveal} onClose={() => setReveal(null)} />}

      {showCreate && (
        <CreateTeacherForm
          onCancel={() => setShowCreate(false)}
          onCreated={(fullName, email, password) => {
            setShowCreate(false);
            setReveal({ title: `${fullName} (${email})`, password });
            load();
          }}
        />
      )}

      {staff.length === 0 ? (
        <div className="card text-center py-14 text-muted">
          <UserCog size={36} className="mx-auto mb-3 opacity-30" />
          <p className="text-sm">Сотрудников пока нет</p>
        </div>
      ) : (
        <div className="space-y-3">
          {staff.map((s) => (
            <StaffRow
              key={s.id}
              staff={s}
              onPasswordReset={(password) => setReveal({ title: `${s.fullName} (${s.email})`, password })}
              onChanged={load}
            />
          ))}
        </div>
      )}
    </div>
  );
}

function StaffRow({ staff, onPasswordReset, onChanged }: {
  staff: StaffMember;
  onPasswordReset: (password: string) => void;
  onChanged: () => void;
}) {
  const [busy, setBusy] = useState(false);

  const resetPassword = async () => {
    if (!confirm(`Сбросить пароль для ${staff.fullName}? Старый пароль перестанет работать.`)) return;
    setBusy(true);
    try {
      const { data } = await api.post(`/users/${staff.id}/reset-password`);
      onPasswordReset(data.tempPassword);
    } finally {
      setBusy(false);
    }
  };

  const toggleActive = async () => {
    setBusy(true);
    try {
      await api.patch(`/users/${staff.id}`, { isActive: !staff.isActive });
      onChanged();
    } finally {
      setBusy(false);
    }
  };

  const groups = staff.teacher?.groups ?? [];

  return (
    <div className={`card ${!staff.isActive ? 'opacity-50' : ''}`}>
      <div className="flex items-center justify-between gap-3">
        <div className="min-w-0">
          <div className="flex items-center gap-2 flex-wrap">
            <p className="font-bold text-ink">{staff.fullName}</p>
            <span className="badge badge-neutral">{ROLE_LABEL[staff.role] ?? staff.role}</span>
            {!staff.isActive && <span className="badge badge-danger">доступ выключен</span>}
          </div>
          <p className="text-xs text-muted mt-0.5">{staff.email}{staff.phone && ` · ${staff.phone}`}</p>
          <p className="text-xs text-muted mt-0.5">
            {staff.lastLoginAt
              ? `Последний вход: ${format(new Date(staff.lastLoginAt), 'd MMMM yyyy, HH:mm', { locale: ru })}`
              : 'Ещё ни разу не заходил(а)'}
          </p>
          {groups.length > 0 && (
            <div className="flex flex-wrap gap-1.5 mt-2">
              {groups.map((g) => (
                <span key={g.id} className="badge badge-neutral"><BookOpen size={10} /> {g.name}</span>
              ))}
            </div>
          )}
        </div>
        <div className="flex gap-1 flex-shrink-0">
          <button
            onClick={resetPassword}
            disabled={busy}
            className="btn-ghost p-2"
            title="Сбросить пароль"
          >
            <KeyRound size={15} />
          </button>
          {staff.role === 'TEACHER' && (
            <button
              onClick={toggleActive}
              disabled={busy}
              className={`btn-ghost p-2 ${staff.isActive ? 'text-sage' : 'text-muted'}`}
              title={staff.isActive ? 'Выключить доступ' : 'Включить доступ'}
            >
              <Power size={15} />
            </button>
          )}
        </div>
      </div>
    </div>
  );
}

function CreateTeacherForm({ onCancel, onCreated }: {
  onCancel: () => void;
  onCreated: (fullName: string, email: string, password: string) => void;
}) {
  const [fullName, setFullName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');

  const submit = async () => {
    if (!fullName.trim() || !email.trim()) return;
    setSaving(true);
    setError('');
    try {
      const { data } = await api.post('/users/teachers', { fullName, email, phone: phone || undefined });
      onCreated(data.user.fullName, data.user.email, data.tempPassword);
    } catch (e: any) {
      setError(e?.response?.data?.message ?? 'Не получилось создать учётную запись');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="card border-ochre/30 bg-ochre/4 space-y-3">
      <p className="text-sm font-semibold text-ink">Новый педагог</p>
      <div className="grid grid-cols-2 gap-3">
        <div>
          <label className="text-xs font-semibold text-muted mb-1 block">Имя и фамилия</label>
          <input className="input" value={fullName} onChange={(e) => setFullName(e.target.value)} placeholder="Иванова Мария Сергеевна" />
        </div>
        <div>
          <label className="text-xs font-semibold text-muted mb-1 block">Email (для входа)</label>
          <input className="input" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="ivanova.ms@schuka-os.local" />
        </div>
      </div>
      <div>
        <label className="text-xs font-semibold text-muted mb-1 block">Телефон (необязательно)</label>
        <input className="input" value={phone} onChange={(e) => setPhone(e.target.value)} placeholder="+7 900 000-00-00" />
      </div>
      {error && <p className="text-xs text-terra">{error}</p>}
      <div className="flex gap-2">
        <button onClick={submit} disabled={saving} className="btn-primary flex-1 justify-center">
          <Check size={14} /> {saving ? 'Создание...' : 'Создать и получить пароль'}
        </button>
        <button onClick={onCancel} className="btn-secondary"><X size={14} /></button>
      </div>
    </div>
  );
}

function PasswordReveal({ info, onClose }: { info: { title: string; password: string }; onClose: () => void }) {
  const [copied, setCopied] = useState(false);
  const copy = async () => {
    try {
      await navigator.clipboard.writeText(info.password);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      // буфер обмена недоступен — пароль всё равно виден на экране
    }
  };
  return (
    <div className="card border-sage/40 bg-sage/6 space-y-2">
      <p className="text-sm font-semibold text-ink">Готово — вот данные для входа: {info.title}</p>
      <div className="flex items-center gap-2">
        <code className="flex-1 bg-white border border-line rounded-lg px-3 py-2 text-sm font-mono tracking-wide">{info.password}</code>
        <button onClick={copy} className="btn-secondary text-xs py-2">
          <Copy size={13} /> {copied ? 'Скопировано' : 'Скопировать'}
        </button>
      </div>
      <p className="text-xs text-muted">
        Перешлите этот пароль педагогу сейчас (например, в мессенджер) — второй раз его показать нельзя,
        только сделать новый. Вход — на той же странице входа в систему, по этому email и паролю.
      </p>
      <button onClick={onClose} className="text-xs text-muted hover:text-ink underline">Закрыть</button>
    </div>
  );
}

function PageSkeleton() {
  return (
    <div className="space-y-6 animate-pulse">
      <div className="h-8 w-48 bg-line rounded-xl" />
      <div className="card h-20 bg-line border-0" />
      <div className="card h-20 bg-line border-0" />
    </div>
  );
}
