﻿'use client';
// Панель руководителя — главная страница.
// Показывает ключевые показатели школы, заполненность групп, задолженности.
import { useEffect, useState } from 'react';
import Link from 'next/link';
import { Users, CreditCard, TrendingUp, AlertCircle, ChevronRight, BookOpen } from 'lucide-react';
import { api } from '@/lib/api';
import type { Payment, Group, Enrollment } from '../../../types';

interface Stats {
  totalStudents: number;
  activeEnrollments: number;
  overduePayments: number;
  totalRevenue: number;
}

export default function AdminHome() {
  const [groups, setGroups] = useState<Group[]>([]);
  const [overduePayments, setOverduePayments] = useState<Payment[]>([]);
  const [recentPayments, setRecentPayments] = useState<Payment[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    Promise.all([
      api.get('/groups').then((r) => setGroups(r.data)),
      api.get('/payments/overdue').then((r) => setOverduePayments(r.data)),
      api.get('/payments').then((r) => setRecentPayments(r.data.slice(0, 5))),
    ]).finally(() => setLoading(false));
  }, []);

  const totalCapacity = groups.reduce((s, g) => s + g.maxSize, 0);
  const totalEnrolled = groups.reduce((s, g) => s + (g._count?.enrollments ?? 0), 0);
  const fillRate = totalCapacity > 0 ? Math.round((totalEnrolled / totalCapacity) * 100) : 0;

  if (loading) return (
    <div className="animate-pulse space-y-4">
      <div className="grid grid-cols-2 gap-4">{[0,1,2,3].map(i => <div key={i} className="h-28 card bg-line border-0" />)}</div>
    </div>
  );

  return (
    <div className="space-y-6">
      <div>
        <p className="text-sm text-muted">Панель руководителя</p>
        <h1 className="text-2xl font-extrabold text-ink tracking-tight">Обзор школы</h1>
      </div>

      {/* ключевые метрики */}
      <div className="grid grid-cols-2 gap-4">
        <StatCard
          icon={Users} color="ochre"
          value={String(totalEnrolled)}
          label="Учеников"
          sub={`цель: 100`}
        />
        <StatCard
          icon={BookOpen} color="sage"
          value={`${fillRate}%`}
          label="Заполненность"
          sub={`${totalEnrolled} из ${totalCapacity} мест`}
        />
        <StatCard
          icon={CreditCard} color="sage"
          value={`${recentPayments.filter(p => p.status === 'PAID').length}`}
          label="Оплачено"
          sub="за всё время"
        />
        <StatCard
          icon={AlertCircle} color="terra"
          value={String(overduePayments.length)}
          label="Задолженности"
          sub="семей"
          alert={overduePayments.length > 0}
        />
      </div>

      {/* заполненность групп */}
      <div className="card">
        <div className="flex items-center justify-between mb-4">
          <h2 className="font-bold text-ink">Заполненность групп</h2>
          <Link href="/admin/groups" className="text-xs text-ochre font-semibold hover:underline">
            Все группы →
          </Link>
        </div>
        <div className="space-y-3">
          {groups.map((g) => {
            const count = g._count?.enrollments ?? 0;
            const pct = Math.round((count / g.maxSize) * 100);
            const color = pct >= 87 ? '#5C7A6B' : pct >= 60 ? '#D4894A' : '#B85450';
            return (
              <div key={g.id}>
                <div className="flex justify-between text-sm mb-1.5">
                  <span className="font-medium text-ink">{g.name}</span>
                  <span className="text-muted text-xs">{count} / {g.maxSize}</span>
                </div>
                <div className="skill-bar">
                  <div className="h-full rounded-full transition-all" style={{ width: `${pct}%`, background: color }} />
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* задолженности */}
      {overduePayments.length > 0 && (
        <div className="card border-terra/20">
          <div className="flex items-center gap-2 mb-4">
            <AlertCircle size={16} className="text-terra" />
            <h2 className="font-bold text-ink">Задолженности</h2>
          </div>
          <div className="space-y-3">
            {overduePayments.slice(0, 5).map((p) => (
              <div key={p.id} className="flex items-center justify-between py-2 border-b border-line last:border-0">
                <div>
                  <p className="text-sm font-semibold text-ink">
                    {p.subscription?.enrollment?.student?.firstName}{' '}
                    {p.subscription?.enrollment?.student?.lastName}
                  </p>
                  <p className="text-xs text-muted">
                    {p.subscription?.enrollment?.group?.name}
                  </p>
                </div>
                <div className="text-right">
                  <p className="text-sm font-bold text-ink">
                    {Number(p.amount).toLocaleString('ru-RU')} ₽
                  </p>
                  <span className="badge badge-danger">просрочено</span>
                </div>
              </div>
            ))}
          </div>
          <Link href="/admin/payments" className="btn-secondary w-full justify-center mt-3 text-terra border-terra/30">
            Управление оплатами
          </Link>
        </div>
      )}

      {/* последние оплаты */}
      <div className="card">
        <div className="flex items-center justify-between mb-4">
          <h2 className="font-bold text-ink">Последние оплаты</h2>
          <Link href="/admin/payments" className="text-xs text-ochre font-semibold hover:underline">
            Все →
          </Link>
        </div>
        <div className="space-y-2">
          {recentPayments.map((p) => {
            const statusMap = {
              PAID: { label: 'Оплачено', cls: 'badge-success' },
              PENDING: { label: 'Ожидается', cls: 'badge-warning' },
              OVERDUE: { label: 'Просрочено', cls: 'badge-danger' },
              REFUNDED: { label: 'Возврат', cls: 'badge-neutral' },
              CANCELLED: { label: 'Отменено', cls: 'badge-neutral' },
            };
            const st = statusMap[p.status] ?? statusMap.PENDING;
            return (
              <div key={p.id} className="flex items-center gap-3 py-2.5 border-b border-line last:border-0">
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-semibold text-ink truncate">
                    {(p as any).subscription?.enrollment?.student?.firstName}{' '}
                    {(p as any).subscription?.enrollment?.student?.lastName}
                  </p>
                  <p className="text-xs text-muted">
                    {(p as any).subscription?.enrollment?.group?.name}
                  </p>
                </div>
                <p className="text-sm font-bold text-ink flex-shrink-0">
                  {Number(p.amount).toLocaleString('ru-RU')} ₽
                </p>
                <span className={`badge ${st.cls} flex-shrink-0`}>{st.label}</span>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}

function StatCard({
  icon: Icon, color, value, label, sub, alert = false
}: {
  icon: React.ElementType; color: string; value: string;
  label: string; sub: string; alert?: boolean;
}) {
  const colorMap: Record<string, string> = {
    ochre: 'text-ochre bg-ochre/8',
    sage: 'text-sage bg-sage/8',
    terra: 'text-terra bg-terra/8',
  };
  return (
    <div className={`card ${alert ? 'border-terra/30' : ''}`}>
      <div className={`w-9 h-9 rounded-xl flex items-center justify-center mb-3 ${colorMap[color]}`}>
        <Icon size={18} />
      </div>
      <p className="text-2xl font-extrabold text-ink tracking-tight">{value}</p>
      <p className="text-sm font-semibold text-ink mt-0.5">{label}</p>
      <p className="text-xs text-muted mt-0.5">{sub}</p>
    </div>
  );
}
