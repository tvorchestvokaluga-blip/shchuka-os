'use client';
// Кабинет педагога — кто записан на ближайшие отработки и что у ребёнка пропущено.
import { useEffect, useState } from 'react';
import { CalendarClock, Users } from 'lucide-react';
import { api } from '@/lib/api';
import type { MakeupSlotStaffView } from '@/types';

export default function TeacherMakeup() {
  const [slots, setSlots] = useState<MakeupSlotStaffView[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api.get('/makeup/slots').then((r) => setSlots(r.data)).finally(() => setLoading(false));
  }, []);

  if (loading) return <PageSkeleton />;

  return (
    <div className="space-y-6">
      <div>
        <p className="text-sm text-muted">Расписание</p>
        <h1 className="text-2xl font-extrabold text-ink tracking-tight">Отработки пропущенных занятий</h1>
        <p className="text-sm text-muted mt-1">Кто записался и какие темы пропустил — считается по посещаемости.</p>
      </div>

      {slots.length === 0 ? (
        <div className="card text-center py-14 text-muted">
          <CalendarClock size={36} className="mx-auto mb-3 opacity-30" />
          <p className="text-sm">Ближайших слотов отработки нет</p>
        </div>
      ) : (
        <div className="space-y-4">
          {slots.map((slot) => (
            <div key={slot.id} className="card space-y-3">
              <div className="flex items-start justify-between gap-3">
                <p className="font-bold text-ink text-lg">
                  {new Date(slot.date).toLocaleString('ru-RU', { day: 'numeric', month: 'long', hour: '2-digit', minute: '2-digit' })}
                </p>
                <span className="badge badge-neutral flex-shrink-0"><Users size={12} /> {slot.roster.length} / {slot.capacity}</span>
              </div>

              {slot.roster.length === 0 ? (
                <p className="text-sm text-muted">Пока никто не записался</p>
              ) : (
                <div className="divide-y divide-line">
                  {slot.roster.map((r) => (
                    <div key={r.bookingId} className="py-2.5">
                      <p className="text-sm font-semibold text-ink">{r.studentName}</p>
                      {r.missedTopics.length === 0 ? (
                        <p className="text-xs text-muted">Пропущенных занятий не найдено</p>
                      ) : (
                        <ul className="mt-1 space-y-0.5">
                          {r.missedTopics.map((t, i) => (
                            <li key={i} className="text-xs text-muted">
                              {new Date(t.date).toLocaleDateString('ru-RU', { day: 'numeric', month: 'short' })} · {t.groupName}
                              {t.topic ? ` — ${t.topic}` : ''}
                            </li>
                          ))}
                        </ul>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

function PageSkeleton() {
  return (
    <div className="space-y-6 animate-pulse">
      <div className="h-8 w-72 bg-line rounded-xl" />
      <div className="card h-32 bg-line border-0" />
    </div>
  );
}
