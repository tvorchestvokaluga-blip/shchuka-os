'use client';
// Карточка ученика — вид педагога. Опирается на тот же Паспорт художника,
// что видит родитель: навыки, достижения, фото, комментарии — плюс дата рождения
// и возраст, чтобы педагог сразу видел контекст ребёнка.
import { useEffect, useState } from 'react';
import Link from 'next/link';
import { ArrowLeft, Award, Image, TrendingUp, MessageSquare, Cake, Target, Plus, Check, X } from 'lucide-react';
import { api, resolveFileUrl } from '@/lib/api';
import type { ArtistPassport, DevelopmentPlan } from '@/types';
import { format, differenceInYears } from 'date-fns';
import { ru } from 'date-fns/locale';

export default function TeacherStudentCard({ params }: { params: { id: string } }) {
  const studentId = params.id;
  const [passport, setPassport] = useState<ArtistPassport | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);

  useEffect(() => {
    if (!studentId) return;
    api.get(`/students/${studentId}/passport`)
      .then((r) => setPassport(r.data))
      .catch(() => setError(true))
      .finally(() => setLoading(false));
  }, [studentId]);

  if (loading) {
    return (
      <div className="space-y-6 animate-pulse">
        <div className="h-8 w-40 bg-line rounded-xl" />
        <div className="card h-40 bg-line border-0" />
      </div>
    );
  }
  if (error || !passport) {
    return (
      <div className="space-y-4">
        <BackLink />
        <div className="card text-center py-10 text-muted">
          Карточка недоступна — либо ребёнок не найден, либо нет доступа
        </div>
      </div>
    );
  }

  const { student, skills, achievements, summary, timeline, photos, enrollments, developmentPlans } = passport;
  const age = differenceInYears(new Date(), new Date(student.birthDate));

  const reloadPassport = () => {
    api.get(`/students/${studentId}/passport`).then((r) => setPassport(r.data));
  };

  return (
    <div className="space-y-6">
      <BackLink />

      {/* шапка */}
      <div className="card bg-ink text-white border-0">
        <div className="flex items-start gap-4">
          <div className="w-16 h-16 rounded-2xl bg-white/10 flex items-center justify-center text-3xl flex-shrink-0">
            {student.avatarEmoji ?? '🎨'}
          </div>
          <div className="flex-1 min-w-0">
            <h1 className="text-xl font-extrabold tracking-tight">
              {student.firstName} {student.lastName}
            </h1>
            <div className="flex items-center gap-3 mt-1 flex-wrap text-sm text-white/60">
              <span className="flex items-center gap-1">
                <Cake size={13} />
                {format(new Date(student.birthDate), 'd MMMM yyyy', { locale: ru })} · {age} лет
              </span>
              {summary.memberSince && (
                <span>В школе с {format(new Date(summary.memberSince), 'LLLL yyyy', { locale: ru })}</span>
              )}
            </div>
            <div className="flex gap-4 mt-3 flex-wrap">
              {[
                { v: summary.totalLessonsAttended, l: 'занятий' },
                { v: summary.achievementsCount, l: 'достижений' },
                { v: summary.artworksCount, l: 'работ' },
              ].map(({ v, l }) => (
                <div key={l}>
                  <span className="text-lg font-extrabold text-ochre">{v}</span>
                  <span className="text-xs text-white/50 ml-1">{l}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* группы/программы */}
      {enrollments.length > 0 && (
        <div className="card">
          <h2 className="font-bold text-ink mb-3">Обучение</h2>
          <div className="space-y-2">
            {enrollments.map((e) => (
              <div key={e.id} className="flex items-center justify-between p-3 rounded-xl bg-paper-dark">
                <div>
                  <p className="text-sm font-semibold text-ink">{e.group}</p>
                  <p className="text-xs text-muted">{e.program}</p>
                </div>
                {e.attendanceRate !== null && (
                  <span className="badge badge-neutral">{e.attendanceRate}% посещаемость</span>
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* план развития */}
      <DevelopmentPlanSection studentId={studentId} plans={developmentPlans} onSaved={reloadPassport} />

      {/* навыки */}
      {skills.length > 0 && (
        <div className="card">
          <div className="flex items-center gap-2 mb-4">
            <TrendingUp size={16} className="text-ochre" />
            <h2 className="font-bold text-ink">Навыки</h2>
          </div>
          <div className="space-y-3">
            {skills.map((s) => (
              <div key={s.name}>
                <div className="flex justify-between text-sm mb-1.5">
                  <span className="font-medium text-ink">{s.name}</span>
                  <span className="text-muted text-xs">{s.level} / 5</span>
                </div>
                <div className="skill-bar">
                  <div className="skill-fill" style={{ width: `${(s.level / 5) * 100}%` }} />
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* достижения */}
      {achievements.length > 0 && (
        <div className="card">
          <div className="flex items-center gap-2 mb-4">
            <Award size={16} className="text-ochre" />
            <h2 className="font-bold text-ink">Достижения</h2>
          </div>
          <div className="flex flex-wrap gap-2">
            {achievements.map((a) => (
              <div key={a.title} className="flex items-center gap-2 px-3 py-2 rounded-xl bg-paper-dark border border-line">
                <span className="text-lg">{a.icon ?? '🏅'}</span>
                <span className="text-sm font-semibold text-ink">{a.title}</span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* фото */}
      {photos.length > 0 && (
        <div className="card">
          <div className="flex items-center gap-2 mb-4">
            <Image size={16} className="text-ochre" />
            <h2 className="font-bold text-ink">Работы и фото</h2>
          </div>
          <div className="grid grid-cols-3 gap-2">
            {photos.slice(0, 9).map((photo) => (
              <div key={photo.id} className="aspect-square rounded-xl overflow-hidden bg-paper-dark border border-line flex items-center justify-center">
                <img src={resolveFileUrl(photo.url)} alt={photo.caption ?? ''} className="w-full h-full object-cover" />
              </div>
            ))}
          </div>
        </div>
      )}

      {/* комментарии */}
      {timeline.length > 0 && (
        <div className="card">
          <div className="flex items-center gap-2 mb-4">
            <MessageSquare size={16} className="text-ochre" />
            <h2 className="font-bold text-ink">Комментарии</h2>
          </div>
          <div className="space-y-4">
            {timeline.slice(0, 8).map((c) => (
              <div key={c.id} className="flex gap-3">
                <div className="w-8 h-8 rounded-xl bg-sage/10 flex items-center justify-center flex-shrink-0 text-sm">👩‍🎨</div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="text-sm font-semibold text-ink">{c.author.fullName}</span>
                    {c.aiAssisted && <span className="badge badge-neutral text-xs">AI-черновик</span>}
                    <span className="text-xs text-muted ml-auto">{format(new Date(c.createdAt), 'd MMM', { locale: ru })}</span>
                  </div>
                  <p className="text-sm text-ink/80 mt-1 leading-relaxed">{c.text}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

function DevelopmentPlanSection({ studentId, plans, onSaved }: { studentId: string; plans: DevelopmentPlan[]; onSaved: () => void }) {
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({ periodLabel: '', goals: '', focusAreas: '', notes: '' });
  const [saving, setSaving] = useState(false);
  const current = plans[0];

  const submit = async () => {
    if (!form.goals.trim()) return;
    setSaving(true);
    try {
      await api.post(`/students/${studentId}/development-plans`, {
        goals: form.goals,
        periodLabel: form.periodLabel || undefined,
        focusAreas: form.focusAreas || undefined,
        notes: form.notes || undefined,
      });
      setForm({ periodLabel: '', goals: '', focusAreas: '', notes: '' });
      setShowForm(false);
      onSaved();
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="card">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <Target size={16} className="text-ochre" />
          <h2 className="font-bold text-ink">План развития</h2>
        </div>
        {!showForm && (
          <button onClick={() => setShowForm(true)} className="btn-ghost text-xs">
            <Plus size={13} /> {current ? 'Обновить план' : 'Составить план'}
          </button>
        )}
      </div>

      {showForm && (
        <div className="space-y-2 mb-4 p-3 rounded-xl bg-ochre/4 border border-ochre/20">
          <input
            className="input"
            placeholder="Период (например, Осень 2026) — необязательно"
            value={form.periodLabel}
            onChange={(e) => setForm({ ...form, periodLabel: e.target.value })}
          />
          <textarea
            className="input min-h-[70px]"
            placeholder="Основные цели на период"
            value={form.goals}
            onChange={(e) => setForm({ ...form, goals: e.target.value })}
          />
          <textarea
            className="input min-h-[50px]"
            placeholder="На что сделать акцент (навыки, темы) — необязательно"
            value={form.focusAreas}
            onChange={(e) => setForm({ ...form, focusAreas: e.target.value })}
          />
          <textarea
            className="input min-h-[50px]"
            placeholder="Наблюдения о текущем прогрессе — необязательно"
            value={form.notes}
            onChange={(e) => setForm({ ...form, notes: e.target.value })}
          />
          <div className="flex gap-2">
            <button onClick={submit} disabled={saving || !form.goals.trim()} className="btn-primary flex-1 justify-center">
              <Check size={14} /> {saving ? 'Сохранение...' : 'Сохранить'}
            </button>
            <button onClick={() => setShowForm(false)} className="btn-secondary"><X size={14} /></button>
          </div>
        </div>
      )}

      {plans.length === 0 && !showForm ? (
        <p className="text-sm text-muted">План развития пока не составлен</p>
      ) : (
        <div className="space-y-3">
          {plans.map((p, idx) => (
            <div key={p.id} className={`p-3 rounded-xl ${idx === 0 ? 'bg-paper-dark' : 'bg-transparent border border-line'}`}>
              <div className="flex items-center justify-between gap-2 flex-wrap">
                <span className="text-xs font-semibold text-muted uppercase tracking-wide">
                  {idx === 0 ? 'Текущий план' : 'Из истории'} {p.periodLabel && `· ${p.periodLabel}`}
                </span>
                <span className="text-xs text-muted">{format(new Date(p.createdAt), 'd MMM yyyy', { locale: ru })} · {p.author.fullName}</span>
              </div>
              <p className="text-sm text-ink mt-1.5 leading-relaxed">{p.goals}</p>
              {p.focusAreas && <p className="text-xs text-muted mt-1"><b>Акцент:</b> {p.focusAreas}</p>}
              {p.notes && <p className="text-xs text-muted mt-1"><b>Наблюдения:</b> {p.notes}</p>}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

function BackLink() {
  return (
    <Link href="/teacher/groups" className="inline-flex items-center gap-1.5 text-sm text-muted hover:text-ink transition-colors">
      <ArrowLeft size={15} /> К группам
    </Link>
  );
}
