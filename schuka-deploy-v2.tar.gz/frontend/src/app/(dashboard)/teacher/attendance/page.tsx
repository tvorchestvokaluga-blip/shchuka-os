'use client';
// Рабочее место педагога — посещаемость по урокам (с историей).
import { useEffect, useState } from 'react';
import { useSearchParams } from 'next/navigation';
import { Check, Users, Calendar } from 'lucide-react';
import { api } from '@/lib/api';
import type { Group, Lesson, AttendanceRecord } from '@/types';

type AttendanceStatus = 'PRESENT' | 'ABSENT' | 'EXCUSED' | 'MAKEUP';

export default function TeacherAttendance() {
  const searchParams = useSearchParams();
  const initialGroupId = searchParams.get('groupId') ?? '';

  const [groups, setGroups] = useState<Group[]>([]);
  const [groupId, setGroupId] = useState(initialGroupId);
  const [lessons, setLessons] = useState<Lesson[]>([]);
  const [lessonId, setLessonId] = useState('');
  const [attendance, setAttendance] = useState<AttendanceRecord[]>([]);
  const [entries, setEntries] = useState<Record<string, AttendanceStatus>>({});
  const [loading, setLoading] = useState(true);
  const [loadingLesson, setLoadingLesson] = useState(false);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);

  useEffect(() => {
    api.get('/groups').then((r) => {
      const data: Group[] = r.data;
      setGroups(data);
      if (!initialGroupId && data.length > 0) setGroupId(data[0].id);
    }).finally(() => setLoading(false));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    if (!groupId) return;
    api.get(`/groups/${groupId}/lessons`).then((r) => {
      const data: Lesson[] = r.data;
      setLessons(data);
      setLessonId(data.length > 0 ? data[0].id : '');
    });
  }, [groupId]);

  useEffect(() => {
    if (!lessonId) { setAttendance([]); return; }
    setLoadingLesson(true);
    api.get(`/lessons/${lessonId}/attendance`).then((r) => {
      const recs: AttendanceRecord[] = r.data;
      setAttendance(recs);
      const initial: Record<string, AttendanceStatus> = {};
      recs.forEach((a) => { initial[a.enrollment.student.id] = a.status; });
      setEntries(initial);
    }).finally(() => setLoadingLesson(false));
  }, [lessonId]);

  const toggleStatus = (studentId: string) => {
    setEntries((prev) => {
      const current = prev[studentId] ?? 'ABSENT';
      const next: AttendanceStatus = current === 'PRESENT' ? 'ABSENT' : 'PRESENT';
      return { ...prev, [studentId]: next };
    });
  };

  const saveAttendance = async () => {
    if (!lessonId) return;
    setSaving(true);
    try {
      const entriesToSend = attendance.map((a) => ({
        enrollmentId: a.enrollment.student.id,
        status: entries[a.enrollment.student.id] ?? 'ABSENT',
      }));
      await api.post(`/lessons/${lessonId}/attendance`, { entries: entriesToSend });
      setSaved(true);
      setTimeout(() => setSaved(false), 3000);
    } finally {
      setSaving(false);
    }
  };

  if (loading) return <PageSkeleton />;

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-extrabold text-ink tracking-tight">Посещаемость</h1>

      <div className="flex gap-2 overflow-x-auto pb-1">
        {groups.map((g) => (
          <button
            key={g.id}
            onClick={() => setGroupId(g.id)}
            className={`flex-shrink-0 px-4 py-2 rounded-xl text-sm font-semibold border transition-all
              ${groupId === g.id
                ? 'bg-ink text-white border-ink'
                : 'bg-white text-muted border-line hover:border-ink/20 hover:text-ink'
              }`}
          >
            {g.name}
          </button>
        ))}
      </div>

      {lessons.length === 0 ? (
        <div className="card text-center py-14 text-muted">
          <Calendar size={36} className="mx-auto mb-3 opacity-30" />
          <p className="text-sm">Уроков пока нет в этой группе</p>
        </div>
      ) : (
        <>
          <div className="flex gap-2 overflow-x-auto pb-1">
            {lessons.map((l) => (
              <button
                key={l.id}
                onClick={() => { setLessonId(l.id); setSaved(false); }}
                className={`flex-shrink-0 px-3.5 py-1.5 rounded-lg text-xs font-semibold border transition-all
                  ${lessonId === l.id
                    ? 'bg-ochre text-white border-ochre'
                    : 'bg-white text-muted border-line hover:border-ink/20 hover:text-ink'
                  }`}
              >
                {new Date(l.date).toLocaleDateString('ru-RU', { day: 'numeric', month: 'short' })}
                {l.topic ? ` · ${l.topic}` : ''}
              </button>
            ))}
          </div>

          {loadingLesson ? (
            <div className="card h-40 bg-line border-0 animate-pulse" />
          ) : attendance.length === 0 ? (
            <div className="card text-center py-14 text-muted">
              <Users size={36} className="mx-auto mb-3 opacity-30" />
              <p className="text-sm">Список учеников пуст</p>
            </div>
          ) : (
            <div className="card">
              <div className="flex items-center justify-between mb-4">
                <h2 className="font-bold text-ink">Отметки</h2>
                <span className="text-xs text-muted">
                  {Object.values(entries).filter((s) => s === 'PRESENT').length} из {attendance.length}
                </span>
              </div>
              <div className="space-y-2">
                {attendance.map((rec) => {
                  const { student } = rec.enrollment;
                  const status = entries[student.id] ?? 'ABSENT';
                  const isPresent = status === 'PRESENT';
                  return (
                    <div
                      key={rec.id}
                      className={`flex items-center gap-3 p-3 rounded-xl border transition-colors cursor-pointer
                        ${isPresent ? 'bg-sage/8 border-sage/20' : 'bg-white border-line hover:bg-paper-dark'}`}
                      onClick={() => toggleStatus(student.id)}
                    >
                      <div className={`w-7 h-7 rounded-lg border-2 flex items-center justify-center flex-shrink-0
                        ${isPresent ? 'bg-sage border-sage' : 'border-line'}`}
                      >
                        {isPresent && <Check size={14} className="text-white" />}
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-semibold text-ink">
                          {student.firstName} {student.lastName}
                        </p>
                        {rec.subscription && (
                          <p className="text-xs text-muted">
                            Осталось занятий: {rec.subscription.remainingLessons}
                          </p>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
              <button
                onClick={saveAttendance}
                disabled={saving || saved}
                className={`btn-primary w-full justify-center mt-4 ${saved ? 'bg-sage hover:bg-sage' : ''}`}
              >
                {saved ? (<><Check size={15} /> Сохранено</>) : saving ? 'Сохранение...' : 'Сохранить посещаемость'}
              </button>
            </div>
          )}
        </>
      )}
    </div>
  );
}

function PageSkeleton() {
  return (
    <div className="space-y-6 animate-pulse">
      <div className="h-8 w-40 bg-line rounded-xl" />
      <div className="card h-48 bg-line border-0" />
    </div>
  );
}
