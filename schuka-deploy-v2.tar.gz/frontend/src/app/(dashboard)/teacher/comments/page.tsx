'use client';
// Рабочее место педагога — комментарии по ученикам (история + AI-черновик).
import { useEffect, useState } from 'react';
import { useSearchParams } from 'next/navigation';
import { MessageSquare, Sparkles, Send, X } from 'lucide-react';
import { api } from '@/lib/api';
import type { Group, Enrollment, Comment } from '@/types';

export default function TeacherComments() {
  const searchParams = useSearchParams();
  const initialGroupId = searchParams.get('groupId') ?? '';

  const [groups, setGroups] = useState<Group[]>([]);
  const [enrollments, setEnrollments] = useState<Enrollment[]>([]);
  const [groupId, setGroupId] = useState(initialGroupId);
  const [enrollmentId, setEnrollmentId] = useState('');
  const [comments, setComments] = useState<Comment[]>([]);
  const [loading, setLoading] = useState(true);
  const [loadingComments, setLoadingComments] = useState(false);
  const [aiDraft, setAiDraft] = useState('');
  const [aiLoading, setAiLoading] = useState(false);
  const [sending, setSending] = useState(false);

  useEffect(() => {
    Promise.all([
      api.get('/groups').then((r) => {
        const data: Group[] = r.data;
        setGroups(data);
        if (!initialGroupId && data.length > 0) setGroupId(data[0].id);
      }),
      api.get('/enrollments').then((r) => setEnrollments(r.data)),
    ]).finally(() => setLoading(false));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const groupEnrollments = enrollments.filter((e) => e.group.id === groupId);

  useEffect(() => {
    if (groupEnrollments.length > 0 && !groupEnrollments.some((e) => e.id === enrollmentId)) {
      setEnrollmentId(groupEnrollments[0].id);
    }
    if (groupEnrollments.length === 0) setEnrollmentId('');
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [groupId, enrollments]);

  useEffect(() => {
    if (!enrollmentId) { setComments([]); return; }
    setLoadingComments(true);
    setAiDraft('');
    api.get(`/enrollments/${enrollmentId}/comments`)
      .then((r) => setComments(r.data))
      .finally(() => setLoadingComments(false));
  }, [enrollmentId]);

  const generateDraft = async () => {
    if (!enrollmentId) return;
    setAiLoading(true);
    setAiDraft('');
    try {
      const { data } = await api.post('/comments/ai-draft', { enrollmentId });
      setAiDraft(data.draft);
    } finally {
      setAiLoading(false);
    }
  };

  const sendComment = async () => {
    if (!aiDraft || !enrollmentId) return;
    setSending(true);
    try {
      await api.post('/comments', { enrollmentId, text: aiDraft, aiAssisted: true });
      setAiDraft('');
      const { data } = await api.get(`/enrollments/${enrollmentId}/comments`);
      setComments(data);
    } finally {
      setSending(false);
    }
  };

  if (loading) return <PageSkeleton />;

  const activeStudent = groupEnrollments.find((e) => e.id === enrollmentId)?.student;

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-extrabold text-ink tracking-tight">Комментарии</h1>

      <div className="flex gap-2 overflow-x-auto pb-1">
        {groups.map((g) => (
          <button
            key={g.id}
            onClick={() => setGroupId(g.id)}
            className={`flex-shrink-0 px-4 py-2 rounded-xl text-sm font-semibold border transition-all
              ${groupId === g.id
                ? 'bg-ink text-white border-ink'
                : 'bg-white text-muted border-line hover:border-ink/20 hover:text-ink'
              }`}
          >
            {g.name}
          </button>
        ))}
      </div>

      {groupEnrollments.length === 0 ? (
        <div className="card text-center py-14 text-muted">
          <MessageSquare size={36} className="mx-auto mb-3 opacity-30" />
          <p className="text-sm">В этой группе пока нет учеников</p>
        </div>
      ) : (
        <>
          <div className="flex gap-2 overflow-x-auto pb-1">
            {groupEnrollments.map((e) => (
              <button
                key={e.id}
                onClick={() => setEnrollmentId(e.id)}
                className={`flex-shrink-0 flex items-center gap-2 px-3.5 py-1.5 rounded-lg text-xs font-semibold border transition-all
                  ${enrollmentId === e.id
                    ? 'bg-ochre text-white border-ochre'
                    : 'bg-white text-muted border-line hover:border-ink/20 hover:text-ink'
                  }`}
              >
                <span>{e.student.avatarEmoji ?? '🎨'}</span>
                {e.student.firstName} {e.student.lastName}
              </button>
            ))}
          </div>

          <div className="card">
            <div className="flex items-center justify-between mb-4">
              <h2 className="font-bold text-ink">
                История {activeStudent && `· ${activeStudent.firstName}`}
              </h2>
              <button onClick={generateDraft} className="btn-ghost text-xs py-1.5 px-2.5" disabled={aiLoading}>
                <Sparkles size={13} /> AI-черновик
              </button>
            </div>

            {(aiLoading || aiDraft) && (
              <div className="rounded-xl border border-ochre/30 bg-ochre/4 p-3.5 mb-4">
                {aiLoading ? (
                  <div className="h-16 bg-line rounded-lg animate-pulse" />
                ) : (
                  <>
                    <textarea
                      className="input min-h-20 resize-none"
                      value={aiDraft}
                      onChange={(e) => setAiDraft(e.target.value)}
                    />
                    <div className="flex gap-2 mt-3">
                      <button onClick={sendComment} disabled={sending} className="btn-primary flex-1 justify-center">
                        <Send size={14} /> {sending ? 'Отправка...' : 'Отправить родителям'}
                      </button>
                      <button onClick={() => setAiDraft('')} className="btn-secondary">
                        <X size={14} />
                      </button>
                    </div>
                  </>
                )}
              </div>
            )}

            {loadingComments ? (
              <div className="h-24 bg-line rounded-xl animate-pulse" />
            ) : comments.length === 0 ? (
              <p className="text-sm text-muted text-center py-8">Комментариев пока нет</p>
            ) : (
              <div className="space-y-3">
                {comments.map((c) => (
                  <div key={c.id} className="p-3 rounded-xl bg-paper-dark">
                    <div className="flex items-center justify-between mb-1">
                      <p className="text-xs font-semibold text-ink">{c.author.fullName}</p>
                      <p className="text-xs text-muted">
                        {new Date(c.createdAt).toLocaleDateString('ru-RU', { day: 'numeric', month: 'long' })}
                      </p>
                    </div>
                    <p className="text-sm text-ink/80">{c.text}</p>
                    {c.aiAssisted && (
                      <span className="badge badge-neutral mt-2"><Sparkles size={10} /> AI-черновик</span>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>
        </>
      )}
    </div>
  );
}

function PageSkeleton() {
  return (
    <div className="space-y-6 animate-pulse">
      <div className="h-8 w-40 bg-line rounded-xl" />
      <div className="card h-48 bg-line border-0" />
    </div>
  );
}
