'use client';
// Рабочее место педагога — домашние задания по группам.
import { useEffect, useState } from 'react';
import { useSearchParams } from 'next/navigation';
import { ClipboardList, Plus, Trash2, Paperclip } from 'lucide-react';
import { api } from '@/lib/api';
import type { Group, Homework } from '@/types';

export default function TeacherHomework() {
  const params = useSearchParams();
  const [groups, setGroups] = useState<Group[]>([]);
  const [groupId, setGroupId] = useState(params.get('groupId') ?? '');
  const [items, setItems] = useState<Homework[]>([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);

  useEffect(() => {
    api.get('/groups').then((r) => {
      setGroups(r.data);
      if (!groupId && r.data.length > 0) setGroupId(r.data[0].id);
    });
  }, []);

  useEffect(() => {
    if (!groupId) { setLoading(false); return; }
    setLoading(true);
    api.get(`/groups/${groupId}/homework`).then((r) => setItems(r.data)).finally(() => setLoading(false));
  }, [groupId]);

  async function remove(id: string) {
    await api.delete(`/homework/${id}`);
    setItems((cur) => cur.filter((h) => h.id !== id));
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-extrabold text-ink tracking-tight">Домашние задания</h1>
        {groupId && (
          <button className="btn-primary" onClick={() => setShowForm((v) => !v)}>
            <Plus size={16} /> Задать
          </button>
        )}
      </div>

      <div className="flex gap-2 overflow-x-auto pb-1">
        {groups.map((g) => (
          <button
            key={g.id}
            onClick={() => setGroupId(g.id)}
            className={`flex-shrink-0 px-3.5 py-1.5 rounded-lg text-xs font-semibold border transition-all
              ${groupId === g.id
                ? 'bg-ink text-white border-ink'
                : 'bg-white text-muted border-line hover:border-ink/20 hover:text-ink'
              }`}
          >
            {g.name}
          </button>
        ))}
      </div>

      {showForm && groupId && (
        <HomeworkForm
          groupId={groupId}
          onCreated={(hw) => { setItems((cur) => [hw, ...cur]); setShowForm(false); }}
          onCancel={() => setShowForm(false)}
        />
      )}

      {loading ? (
        <div className="card h-32 bg-line border-0 animate-pulse" />
      ) : items.length === 0 ? (
        <div className="card text-center py-14 text-muted">
          <ClipboardList size={36} className="mx-auto mb-3 opacity-30" />
          <p className="text-sm">Заданий для этой группы пока нет</p>
        </div>
      ) : (
        <div className="space-y-4">
          {items.map((hw) => (
            <div key={hw.id} className="card space-y-2">
              <div className="flex items-start justify-between gap-3">
                <h2 className="font-bold text-ink">{hw.title}</h2>
                <button onClick={() => remove(hw.id)} className="btn-ghost text-terra flex-shrink-0 p-1.5">
                  <Trash2 size={15} />
                </button>
              </div>
              <p className="text-sm text-ink/80 whitespace-pre-wrap leading-relaxed">{hw.description}</p>
              <div className="flex items-center gap-3 text-xs text-muted pt-1">
                {hw.dueDate && <span>до {new Date(hw.dueDate).toLocaleDateString('ru-RU')}</span>}
                {hw.attachmentUrl && (
                  <a href={hw.attachmentUrl} target="_blank" rel="noreferrer" className="flex items-center gap-1 text-ochre font-semibold">
                    <Paperclip size={12} /> материалы
                  </a>
                )}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

function HomeworkForm({ groupId, onCreated, onCancel }: {
  groupId: string; onCreated: (hw: Homework) => void; onCancel: () => void;
}) {
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [dueDate, setDueDate] = useState('');
  const [attachmentUrl, setAttachmentUrl] = useState('');
  const [saving, setSaving] = useState(false);

  async function submit() {
    if (!title.trim() || !description.trim()) return;
    setSaving(true);
    try {
      const { data } = await api.post('/homework', {
        groupId, title, description,
        dueDate: dueDate || undefined,
        attachmentUrl: attachmentUrl || undefined,
      });
      onCreated(data);
    } finally {
      setSaving(false);
    }
  }

  return (
    <div className="card space-y-3">
      <input className="input" placeholder="Тема задания" value={title} onChange={(e) => setTitle(e.target.value)} />
      <textarea className="input min-h-[90px]" placeholder="Что нужно сделать"
        value={description} onChange={(e) => setDescription(e.target.value)} />
      <div className="grid grid-cols-2 gap-3">
        <input className="input" type="date" value={dueDate} onChange={(e) => setDueDate(e.target.value)} />
        <input className="input" placeholder="Ссылка на референс (необязательно)"
          value={attachmentUrl} onChange={(e) => setAttachmentUrl(e.target.value)} />
      </div>
      <div className="flex gap-2 justify-end">
        <button className="btn-secondary" onClick={onCancel}>Отмена</button>
        <button className="btn-primary" onClick={submit} disabled={saving}>Сохранить</button>
      </div>
    </div>
  );
}
