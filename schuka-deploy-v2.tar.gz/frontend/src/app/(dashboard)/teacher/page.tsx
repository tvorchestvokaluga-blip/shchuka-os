﻿'use client';
// Рабочее место педагога — главная страница.
// Показывает группы сегодня, позволяет отмечать посещаемость и запускать AI-черновик.
import { useEffect, useState } from 'react';
import { Check, X, Sparkles, Send, Camera, Users } from 'lucide-react';
import { api } from '@/lib/api';
import type { Group, Lesson, AttendanceRecord } from '../../../types';

type AttendanceStatus = 'PRESENT' | 'ABSENT' | 'EXCUSED' | 'MAKEUP';
interface LocalEntry { enrollmentId: string; status: AttendanceStatus }

export default function TeacherHome() {
  const [groups, setGroups] = useState<Group[]>([]);
  const [activeGroup, setActiveGroup] = useState<Group | null>(null);
  const [lesson, setLesson] = useState<Lesson | null>(null);
  const [attendance, setAttendance] = useState<AttendanceRecord[]>([]);
  const [entries, setEntries] = useState<Record<string, AttendanceStatus>>({});
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [aiDraft, setAiDraft] = useState('');
  const [aiLoading, setAiLoading] = useState(false);
  const [selectedEnrollmentId, setSelectedEnrollmentId] = useState('');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api.get('/groups').then((r) => {
      setGroups(r.data);
      if (r.data.length > 0) setActiveGroup(r.data[0]);
    }).finally(() => setLoading(false));
  }, []);

  // загружаем последний урок группы
  useEffect(() => {
    if (!activeGroup) return;
    api.get(`/groups/${activeGroup.id}/lessons`).then((r) => {
      const lessons: Lesson[] = r.data;
      if (lessons.length > 0) {
        const latest = lessons[0];
        setLesson(latest);
        return api.get(`/lessons/${latest.id}/attendance`).then((ar) => {
          const recs: AttendanceRecord[] = ar.data;
          setAttendance(recs);
          const initial: Record<string, AttendanceStatus> = {};
          recs.forEach((a) => { initial[a.enrollment.student.id] = a.status; });
          setEntries(initial);
        });
      }
    });
  }, [activeGroup]);

  const toggleStatus = (enrollmentId: string, studentId: string) => {
    setEntries((prev) => {
      const current = prev[studentId] ?? 'ABSENT';
      const next: AttendanceStatus = current === 'PRESENT' ? 'ABSENT' : 'PRESENT';
      return { ...prev, [studentId]: next };
    });
  };

  const saveAttendance = async () => {
    if (!lesson) return;
    setSaving(true);
    try {
      const entriesToSend = attendance.map((a) => ({
        enrollmentId: a.enrollment.student.id, // используем studentId как ключ
        status: entries[a.enrollment.student.id] ?? 'ABSENT',
      }));
      await api.post(`/lessons/${lesson.id}/attendance`, { entries: entriesToSend });
      setSaved(true);
      setTimeout(() => setSaved(false), 3000);
    } finally {
      setSaving(false);
    }
  };

  const generateDraft = async (enrollmentId: string) => {
    setSelectedEnrollmentId(enrollmentId);
    setAiLoading(true);
    setAiDraft('');
    try {
      const { data } = await api.post('/comments/ai-draft', {
        enrollmentId,
        lessonTopic: lesson?.topic,
        lessonId: lesson?.id,
      });
      setAiDraft(data.draft);
    } finally {
      setAiLoading(false);
    }
  };

  const sendComment = async () => {
    if (!aiDraft || !selectedEnrollmentId) return;
    await api.post('/comments', {
      enrollmentId: selectedEnrollmentId,
      lessonId: lesson?.id,
      text: aiDraft,
      aiAssisted: true,
    });
    setAiDraft('');
    setSelectedEnrollmentId('');
  };

  if (loading) return <div className="animate-pulse space-y-4"><div className="h-48 card bg-line border-0" /></div>;

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-extrabold text-ink tracking-tight">Рабочее место</h1>

      {/* переключатель групп */}
      <div className="flex gap-2 overflow-x-auto pb-1">
        {groups.map((g) => (
          <button
            key={g.id}
            onClick={() => { setActiveGroup(g); setSaved(false); setAiDraft(''); }}
            className={`flex-shrink-0 px-4 py-2 rounded-xl text-sm font-semibold border transition-all
              ${activeGroup?.id === g.id
                ? 'bg-ink text-white border-ink'
                : 'bg-white text-muted border-line hover:border-ink/20 hover:text-ink'
              }`}
          >
            {g.name}
          </button>
        ))}
      </div>

      {activeGroup && (
        <>
          {/* урок */}
          <div className="card">
            <div className="flex items-center justify-between mb-1">
              <h2 className="font-bold text-ink">{activeGroup.name}</h2>
              <span className="badge badge-neutral">
                <Users size={11} />{activeGroup._count?.enrollments ?? 0} детей
              </span>
            </div>
            {lesson ? (
              <p className="text-sm text-muted">
                Последний урок: {lesson.topic ?? 'без темы'} ·{' '}
                {new Date(lesson.date).toLocaleDateString('ru-RU', { day: 'numeric', month: 'long' })}
              </p>
            ) : (
              <p className="text-sm text-muted">Уроков пока нет</p>
            )}
          </div>

          {/* посещаемость */}
          {attendance.length > 0 && (
            <div className="card">
              <div className="flex items-center justify-between mb-4">
                <h2 className="font-bold text-ink">Посещаемость</h2>
                <span className="text-xs text-muted">
                  {Object.values(entries).filter((s) => s === 'PRESENT').length} из {attendance.length}
                </span>
              </div>
              <div className="space-y-2">
                {attendance.map((rec) => {
                  const { student } = rec.enrollment;
                  const status = entries[student.id] ?? 'ABSENT';
                  const isPresent = status === 'PRESENT';
                  return (
                    <div
                      key={rec.id}
                      className={`flex items-center gap-3 p-3 rounded-xl border transition-colors cursor-pointer
                        ${isPresent ? 'bg-sage/8 border-sage/20' : 'bg-white border-line hover:bg-paper-dark'}`}
                      onClick={() => toggleStatus(rec.enrollment.student.id, student.id)}
                    >
                      <div className={`w-7 h-7 rounded-lg border-2 flex items-center justify-center flex-shrink-0
                        ${isPresent ? 'bg-sage border-sage' : 'border-line'}`}
                      >
                        {isPresent && <Check size={14} className="text-white" />}
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-semibold text-ink">
                          {student.firstName} {student.lastName}
                        </p>
                        {rec.subscription && (
                          <p className="text-xs text-muted">
                            Осталось занятий: {rec.subscription.remainingLessons}
                          </p>
                        )}
                      </div>
                      <button
                        onClick={(e) => { e.stopPropagation(); generateDraft(rec.id); }}
                        className="btn-ghost text-xs py-1 px-2"
                        title="AI-комментарий"
                      >
                        <Sparkles size={13} />
                      </button>
                    </div>
                  );
                })}
              </div>

              <div className="flex gap-2 mt-4">
                <button
                  onClick={saveAttendance}
                  disabled={saving || saved}
                  className={`btn-primary flex-1 justify-center ${saved ? 'bg-sage hover:bg-sage' : ''}`}
                >
                  {saved ? (<><Check size={15} /> Сохранено</>) : saving ? 'Сохранение...' : 'Сохранить посещаемость'}
                </button>
              </div>
            </div>
          )}

          {/* AI-черновик */}
          {(aiLoading || aiDraft) && (
            <div className="card border-ochre/30 bg-ochre/4">
              <div className="flex items-center gap-2 mb-3">
                <Sparkles size={16} className="text-ochre" />
                <h2 className="font-bold text-ink">AI-черновик комментария</h2>
              </div>
              {aiLoading ? (
                <div className="h-20 bg-line rounded-xl animate-pulse" />
              ) : (
                <>
                  <textarea
                    className="input min-h-24 resize-none"
                    value={aiDraft}
                    onChange={(e) => setAiDraft(e.target.value)}
                  />
                  <div className="flex gap-2 mt-3">
                    <button onClick={sendComment} className="btn-primary flex-1 justify-center">
                      <Send size={14} /> Отправить родителям
                    </button>
                    <button onClick={() => setAiDraft('')} className="btn-secondary">
                      <X size={14} />
                    </button>
                  </div>
                  <p className="text-xs text-muted mt-2 text-center">
                    AI подготовил черновик — вы проверяете и отправляете
                  </p>
                </>
              )}
            </div>
          )}
        </>
      )}

      {groups.length === 0 && (
        <div className="card text-center py-10 text-muted">
          <Users size={36} className="mx-auto mb-3 opacity-30" />
          <p className="text-sm">Групп не найдено</p>
        </div>
      )}
    </div>
  );
}
