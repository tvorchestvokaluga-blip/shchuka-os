'use client';
// Рабочее место педагога — мои группы.
import { useEffect, useState } from 'react';
import Link from 'next/link';
import { Users, Calendar, MessageSquare, MapPin, LayoutList } from 'lucide-react';
import { api } from '@/lib/api';
import type { Group } from '@/types';

const WEEKDAY_RU: Record<string, string> = {
  MON: 'Пн', TUE: 'Вт', WED: 'Ср', THU: 'Чт', FRI: 'Пт', SAT: 'Сб', SUN: 'Вс',
};

export default function TeacherGroups() {
  const [groups, setGroups] = useState<Group[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api.get('/groups').then((r) => setGroups(r.data)).finally(() => setLoading(false));
  }, []);

  if (loading) return <PageSkeleton />;

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-extrabold text-ink tracking-tight">Мои группы</h1>

      {groups.length === 0 ? (
        <div className="card text-center py-14 text-muted">
          <Users size={36} className="mx-auto mb-3 opacity-30" />
          <p className="text-sm">Групп не найдено</p>
        </div>
      ) : (
        <div className="space-y-4">
          {groups.map((g) => (
            <div key={g.id} className="card space-y-3">
              <div className="flex items-center justify-between">
                <div>
                  <h2 className="font-bold text-ink">{g.name}</h2>
                  <p className="text-xs text-muted">{g.program?.name}</p>
                </div>
                <span className="badge badge-neutral">
                  <Users size={11} />{g._count?.enrollments ?? 0} / {g.maxSize}
                </span>
              </div>

              {(g.scheduleSlots ?? []).length > 0 && (
                <div className="flex flex-wrap gap-2">
                  {g.scheduleSlots.map((s) => (
                    <span key={s.id} className="badge badge-neutral">
                      <Calendar size={11} />
                      {WEEKDAY_RU[s.weekday] ?? s.weekday} {s.startTime}
                      {s.room && (
                        <>
                          <MapPin size={11} className="ml-1" />
                          {s.room}
                        </>
                      )}
                    </span>
                  ))}
                </div>
              )}

              <Link
                href={`/teacher/groups/${g.id}`}
                className="btn-primary w-full justify-center text-xs py-2"
              >
                <LayoutList size={13} /> Роспись, уроки и фото
              </Link>

              <div className="flex gap-2 pt-1">
                <Link
                  href={`/teacher/attendance?groupId=${g.id}`}
                  className="btn-secondary flex-1 justify-center text-xs py-2"
                >
                  Посещаемость
                </Link>
                <Link
                  href={`/teacher/comments?groupId=${g.id}`}
                  className="btn-secondary flex-1 justify-center text-xs py-2"
                >
                  <MessageSquare size={13} /> Комментарии
                </Link>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

function PageSkeleton() {
  return (
    <div className="space-y-6 animate-pulse">
      <div className="h-8 w-40 bg-line rounded-xl" />
      <div className="card h-32 bg-line border-0" />
      <div className="card h-32 bg-line border-0" />
    </div>
  );
}
