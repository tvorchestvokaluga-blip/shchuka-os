﻿// Корень / — редирект по роли пользователя.
'use client';
import { useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { useAuthStore } from '@/lib/auth-store';

export default function Root() {
  const { user } = useAuthStore();
  const router = useRouter();
  useEffect(() => {
    if (!user) router.replace('/login');
    else if (user.role === 'PARENT') router.replace('/parent');
    else if (user.role === 'TEACHER') router.replace('/teacher');
    else router.replace('/admin');
  }, [user, router]);
  return null;
}
