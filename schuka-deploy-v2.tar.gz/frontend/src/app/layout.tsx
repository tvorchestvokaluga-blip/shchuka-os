// app/layout.tsx — корневой layout: провайдеры, шрифты, метаданные.
import type { Metadata } from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: 'Schuka OS',
  description: 'Цифровая экосистема художественной школы «Щука»',
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="ru">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link
          href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap"
          rel="stylesheet"
        />
      </head>
      <body>{children}</body>
    </html>
  );
}
