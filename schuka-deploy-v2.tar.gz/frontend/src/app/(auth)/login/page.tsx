﻿'use client';
// Страница входа — /login. Чистая, без лишних элементов.
// Сигнатура: рыбка-логотип + тёплый фон бумаги.
import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { useAuthStore } from '@/lib/auth-store';

export default function LoginPage() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const { login, isLoading } = useAuthStore();
  const router = useRouter();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    try {
      await login(email, password);
      // редирект по роли
      const user = useAuthStore.getState().user;
      if (user?.role === 'PARENT') router.push('/parent');
      else if (user?.role === 'TEACHER') router.push('/teacher');
      else router.push('/admin');
    } catch {
      setError('Неверный email или пароль');
    }
  };

  return (
    <div className="min-h-screen bg-paper flex items-center justify-center px-4">
      <div className="w-full max-w-sm">
        {/* логотип */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-14 h-14 rounded-2xl bg-ink mb-4 text-2xl">
            🐟
          </div>
          <h1 className="text-2xl font-extrabold text-ink tracking-tight">Schuka OS</h1>
          <p className="text-sm text-muted mt-1">Художественная школа «Щука»</p>
        </div>

        {/* форма */}
        <form onSubmit={handleSubmit} className="card space-y-4">
          <div>
            <label className="block text-sm font-semibold text-ink mb-1.5">Email</label>
            <input
              type="email"
              className="input"
              placeholder="your@email.com"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
              autoComplete="email"
            />
          </div>
          <div>
            <label className="block text-sm font-semibold text-ink mb-1.5">Пароль</label>
            <input
              type="password"
              className="input"
              placeholder="••••••••"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
              autoComplete="current-password"
            />
          </div>

          {error && (
            <div className="rounded-xl bg-terra/8 border border-terra/20 px-3.5 py-2.5 text-sm text-terra font-medium">
              {error}
            </div>
          )}

          <button type="submit" className="btn-primary w-full justify-center py-3" disabled={isLoading}>
            {isLoading ? 'Вход...' : 'Войти'}
          </button>
        </form>

        {/* подсказка для демо */}
        <div className="mt-4 rounded-xl bg-paper-dark border border-line px-4 py-3 text-xs text-muted space-y-1">
          <p className="font-semibold text-ink">Демо-доступы:</p>
          <p>Руководитель: owner@schuka.art</p>
          <p>Педагог: anna@schuka.art</p>
          <p>Родитель: orlova@example.com</p>
          <p className="text-muted/70">Пароль: schuka123</p>
        </div>
      </div>
    </div>
  );
}
