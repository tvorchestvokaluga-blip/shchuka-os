import type { Config } from 'tailwindcss'

const config: Config = {
  content: ['./src/**/*.{ts,tsx}'],
  theme: {
    extend: {
      colors: {
        // Палитра Schuka OS — приведена в соответствие с сайтом школы
        // (тёмно-зелёный графит из логотипа + тёплый кремовый + коралл + жёлтый)
        ink:    { DEFAULT: '#2B382F', light: '#44544A' },
        paper:  { DEFAULT: '#F7F3E7', dark: '#F1EBDA' },
        ochre:  { DEFAULT: '#E8563A', light: '#F17A62', dark: '#C7381E' }, // = коралл сайта (основной акцент)
        sage:   { DEFAULT: '#3C6350', light: '#5C8A73', dark: '#2A4A3A' }, // = зелёный сайта
        terra:  { DEFAULT: '#9B3226', light: '#B8574A', dark: '#7A2419' }, // приглушённый красный для ошибок/опасных действий
        amber:  { DEFAULT: '#D9A800', light: '#F4C531', dark: '#B38A00' }, // = жёлтый сайта, для предупреждений
        muted:  '#718075',
        line:   '#E6DFC9',
      },
      fontFamily: {
        sans: ['Inter', 'system-ui', 'sans-serif'],
        display: ['Unbounded', 'Inter', 'system-ui', 'sans-serif'], // заголовки — как на сайте школы
      },
      borderRadius: {
        '2xl': '1rem',
        '3xl': '1.5rem',
      },
      boxShadow: {
        'card':  '0 1px 3px rgba(43,56,47,0.08), 0 1px 2px rgba(43,56,47,0.05)',
        'card-hover': '0 4px 12px rgba(43,56,47,0.12)',
        'inset-sm': 'inset 0 1px 3px rgba(43,56,47,0.06)',
        'brand': '3px 3px 0 #2B382F',
      },
    },
  },
  plugins: [],
}
export default config
