-- AlterTable
ALTER TABLE "students" ALTER COLUMN "birthDate" DROP NOT NULL;
