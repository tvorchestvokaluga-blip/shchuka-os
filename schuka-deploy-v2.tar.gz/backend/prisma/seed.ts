﻿// @ts-nocheck
// ============================================================================
//  SCHUKA OS — SEED
//  Наполняет свежую базу демонстрационной, но реалистичной структурой школы.
//  Запуск:  npx prisma db seed
//  (требует блока "prisma": { "seed": "ts-node prisma/seed.ts" } в package.json)
//
//  Что создаётся:
//   - школа «Щука»
//   - руководитель (вход), 2 педагога
//   - 3 программы, группы с расписанием
//   - 3 семьи с родителями и детьми
//   - зачисления, абонементы, оплаты
//   - справочники навыков и достижений
//   - примеры уроков, посещаемости, комментариев, фото — чтобы Паспорт был «живым»
//
//  ПАРОЛИ демо-пользователей: "schuka123" (захешированы). Смените после первого входа.
// ============================================================================

import { PrismaClient, UserRole, Weekday, EnrollmentStatus,
  SubscriptionStatus, PaymentStatus, PaymentMethod, AttendanceStatus,
  CommentVisibility } from '@prisma/client';
import * as bcrypt from 'bcrypt';

const prisma = new PrismaClient();

async function main() {
  console.log('🌱 Seeding Schuka OS...');

  // ── чистим (только для dev — порядок обратный связям) ───────────────────
  await prisma.$transaction([
    prisma.notification.deleteMany(),
    prisma.studentAchievement.deleteMany(),
    prisma.achievementType.deleteMany(),
    prisma.studentSkill.deleteMany(),
    prisma.skill.deleteMany(),
    prisma.artwork.deleteMany(),
    prisma.comment.deleteMany(),
    prisma.photo.deleteMany(),
    prisma.attendance.deleteMany(),
    prisma.lesson.deleteMany(),
    prisma.payment.deleteMany(),
    prisma.subscription.deleteMany(),
    prisma.enrollment.deleteMany(),
    prisma.scheduleSlot.deleteMany(),
    prisma.group.deleteMany(),
    prisma.module.deleteMany(),
    prisma.program.deleteMany(),
    prisma.student.deleteMany(),
    prisma.parent.deleteMany(),
    prisma.family.deleteMany(),
    prisma.teacher.deleteMany(),
    prisma.user.deleteMany(),
    prisma.school.deleteMany(),
  ]);

  const pwd = await bcrypt.hash('schuka123', 10);

  // ── Школа ───────────────────────────────────────────────────────────────
  const school = await prisma.school.create({
    data: {
      name: 'Художественная школа «Щука»',
      slug: 'schuka',
      address: 'Калуга, ул. Театральная, 35/8',
      phone: '+7 (900) 000-00-00',
      email: 'hello@schuka.art',
      timezone: 'Europe/Moscow',
    },
  });

  // ── Руководитель ─────────────────────────────────────────────────────────
  const owner = await prisma.user.create({
    data: {
      schoolId: school.id,
      email: 'owner@schuka.art',
      fullName: 'Екатерина (руководитель)',
      role: UserRole.OWNER,
      passwordHash: pwd, isActive: true,
    },
  });

  // ── Педагоги ──────────────────────────────────────────────────────────────
  const teacherData = [
    { email: 'anna@schuka.art', name: 'Анна Сергеевна', bio: 'Живопись, акварель' },
    { email: 'pavel@schuka.art', name: 'Павел Игоревич', bio: 'Скульптура, лепка' },
  ];
  const teachers = [];
  for (const t of teacherData) {
    const u = await prisma.user.create({
      data: { schoolId: school.id, email: t.email, fullName: t.name,
        role: UserRole.TEACHER, passwordHash: pwd, isActive: true },
    });
    const teacher = await prisma.teacher.create({
      data: { schoolId: school.id, userId: u.id, bio: t.bio },
    });
    teachers.push(teacher);
  }

  // ── Программы ──────────────────────────────────────────────────────────────
  const painting = await prisma.program.create({
    data: { schoolId: school.id, name: 'Живопись', ageFrom: 6, ageTo: 12,
      basePrice: 3800, description: 'Акварель, гуашь, работа с цветом' },
  });
  const sculpture = await prisma.program.create({
    data: { schoolId: school.id, name: 'Скульптура', ageFrom: 11, ageTo: 17,
      basePrice: 4200, description: 'Лепка, работа с глиной' },
  });
  const little = await prisma.program.create({
    data: { schoolId: school.id, name: 'Рисование для малышей', ageFrom: 4, ageTo: 5,
      basePrice: 3200, description: 'Первое знакомство с красками' },
  });

  // ── Группы + расписание ────────────────────────────────────────────────────
  const gWatercolor = await prisma.group.create({
    data: { schoolId: school.id, programId: painting.id, teacherId: teachers[0].id,
      name: 'Акварельки', maxSize: 8,
      scheduleSlots: { create: [{ weekday: Weekday.MON, startTime: '16:00', endTime: '17:30', room: 'каб. 2' }] } },
  });
  const gClay = await prisma.group.create({
    data: { schoolId: school.id, programId: sculpture.id, teacherId: teachers[1].id,
      name: 'Глина 11+', maxSize: 8,
      scheduleSlots: { create: [{ weekday: Weekday.WED, startTime: '17:30', endTime: '19:00', room: 'каб. 3' }] } },
  });

  // ── Справочник навыков и достижений ────────────────────────────────────────
  const skillNames = ['Композиция', 'Работа с цветом', 'Перспектива', 'Смешение красок'];
  const skills = [];
  for (const name of skillNames) {
    skills.push(await prisma.skill.create({ data: { schoolId: school.id, name } }));
  }
  const achFirstShow = await prisma.achievementType.create({
    data: { schoolId: school.id, title: 'Первая выставка', iconEmoji: '🏅' } });
  const achYear = await prisma.achievementType.create({
    data: { schoolId: school.id, title: 'Год в школе', iconEmoji: '🌟' } });

  // ── Семьи, родители, дети ───────────────────────────────────────────────────
  async function createFamily(famName: string, parentName: string, parentEmail: string,
      kids: { first: string; last: string; birth: string; emoji: string }[]) {
    const family = await prisma.family.create({ data: { schoolId: school.id, name: famName } });
    const pUser = await prisma.user.create({
      data: { schoolId: school.id, email: parentEmail, fullName: parentName,
        role: UserRole.PARENT, passwordHash: pwd, isActive: true } });
    await prisma.parent.create({ data: { familyId: family.id, userId: pUser.id, isPrimary: true } });
    const students = [];
    for (const k of kids) {
      students.push(await prisma.student.create({
        data: { schoolId: school.id, familyId: family.id, firstName: k.first,
          lastName: k.last, birthDate: new Date(k.birth), avatarEmoji: k.emoji } }));
    }
    return { family, students };
  }

  const orlov = await createFamily('Семья Орловых', 'Ольга Орлова', 'orlova@example.com', [
    { first: 'Маша', last: 'Орлова', birth: '2017-04-12', emoji: '🎨' },
    { first: 'Лев', last: 'Орлов', birth: '2014-09-01', emoji: '🗿' },
  ]);
  const kim = await createFamily('Семья Ким', 'Денис Ким', 'kim@example.com', [
    { first: 'Соня', last: 'Ким', birth: '2017-11-20', emoji: '🌈' },
  ]);

  // ── Зачисления + абонементы + оплаты ────────────────────────────────────────
  async function enroll(studentId: string, programId: string, groupId: string,
      price: number, paid: boolean) {
    const enr = await prisma.enrollment.create({
      data: { schoolId: school.id, studentId, programId, groupId,
        status: EnrollmentStatus.ACTIVE } });
    const sub = await prisma.subscription.create({
      data: { schoolId: school.id, enrollmentId: enr.id, totalLessons: 8,
        remainingLessons: 6, status: SubscriptionStatus.ACTIVE,
        expiryDate: new Date(Date.now() + 60 * 24 * 3600 * 1000) } });
    await prisma.payment.create({
      data: { schoolId: school.id, subscriptionId: sub.id, amount: price,
        status: paid ? PaymentStatus.PAID : PaymentStatus.PENDING,
        method: paid ? PaymentMethod.CARD : undefined,
        paidAt: paid ? new Date() : undefined } });
    return { enr, sub };
  }

  const mashaEnr = await enroll(orlov.students[0].id, painting.id, gWatercolor.id, 3800, true);
  await enroll(orlov.students[1].id, sculpture.id, gClay.id, 4200, true);
  await enroll(kim.students[0].id, painting.id, gWatercolor.id, 3800, false);

  // ── Урок + посещаемость + комментарий + фото для Маши (живой Паспорт) ────────
  const lesson = await prisma.lesson.create({
    data: { schoolId: school.id, groupId: gWatercolor.id, date: new Date(),
      topic: 'Смешение составных цветов' } });

  await prisma.attendance.create({
    data: { lessonId: lesson.id, enrollmentId: mashaEnr.enr.id,
      subscriptionId: mashaEnr.sub.id, status: AttendanceStatus.PRESENT } });

  await prisma.comment.create({
    data: { schoolId: school.id, enrollmentId: mashaEnr.enr.id, lessonId: lesson.id,
      authorId: teachers[0].userId, aiAssisted: true, visibility: CommentVisibility.PARENT,
      text: 'Сегодня Маша впервые смешала составной зелёный сама и закрасила фон ровным слоем — большой шаг в работе с цветом. Дома можно похвалить за терпение!' } });

  await prisma.photo.create({
    data: { schoolId: school.id, studentId: orlov.students[0].id, lessonId: lesson.id,
      url: 'seed/demo-artwork-1.jpg', caption: 'Работа на занятии' } });

  // навыки Маши (для прогресс-баров в Паспорте)
  const levels = [4, 5, 3, 4];
  for (let i = 0; i < skills.length; i++) {
    await prisma.studentSkill.create({
      data: { studentId: orlov.students[0].id, skillId: skills[i].id, level: levels[i] } });
  }
  await prisma.studentAchievement.create({
    data: { studentId: orlov.students[0].id, achievementTypeId: achFirstShow.id } });
  await prisma.studentAchievement.create({
    data: { studentId: orlov.students[0].id, achievementTypeId: achYear.id } });

  console.log('✅ Seed complete.');
  console.log('   Школа:', school.name);
  console.log('   Вход руководителя: owner@schuka.art / schuka123');
  console.log('   Педагог: anna@schuka.art / schuka123');
  console.log('   Родитель: orlova@example.com / schuka123');
}

main()
  .catch((e) => { console.error(e); process.exit(1); })
  .finally(async () => { await prisma.$disconnect(); });
