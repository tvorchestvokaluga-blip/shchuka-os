// AuthService — проверяет логин/пароль и выдаёт JWT.
import { Injectable, UnauthorizedException } from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import * as bcrypt from 'bcrypt';
import { PrismaService } from '../prisma/prisma.service';
import { LoginDto } from './dto/login.dto';

@Injectable()
export class AuthService {
  constructor(
    private prisma: PrismaService,
    private jwt: JwtService,
  ) {}

  /** Проверяет учётные данные и возвращает токен + краткий профиль. */
  async login(dto: LoginDto) {
    // email уникален в пределах школы; для входа находим первого активного с таким email
    const user = await this.prisma.user.findFirst({
      where: { email: dto.email, isActive: true },
    });
    if (!user || !user.passwordHash) {
      throw new UnauthorizedException('Неверный email или пароль');
    }

    const ok = await bcrypt.compare(dto.password, user.passwordHash);
    if (!ok) {
      throw new UnauthorizedException('Неверный email или пароль');
    }

    await this.prisma.user.update({
      where: { id: user.id },
      data: { lastLoginAt: new Date() },
    });

    const token = await this.jwt.signAsync({ sub: user.id });
    return {
      accessToken: token,
      user: {
        id: user.id,
        fullName: user.fullName,
        role: user.role,
        schoolId: user.schoolId,
      },
    };
  }

  /** Привязка личного Telegram-чата пользователя — для отправки отчётов. */
  async setTelegramChatId(userId: string, telegramChatId: string) {
    await this.prisma.user.update({ where: { id: userId }, data: { telegramChatId } });
    return { ok: true };
  }
}
