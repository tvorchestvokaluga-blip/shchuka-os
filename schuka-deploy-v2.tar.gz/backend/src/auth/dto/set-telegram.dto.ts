import { IsString, MinLength } from 'class-validator';

export class SetTelegramChatIdDto {
  @IsString()
  @MinLength(1)
  telegramChatId: string;
}
