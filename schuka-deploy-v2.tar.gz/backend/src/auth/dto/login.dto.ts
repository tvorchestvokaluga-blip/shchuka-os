// Структуры данных запросов авторизации с валидацией.
import { IsEmail, IsString, MinLength } from 'class-validator';

export class LoginDto {
  @IsEmail({}, { message: 'Введите корректный email' })
  email: string;

  @IsString()
  @MinLength(6, { message: 'Пароль не короче 6 символов' })
  password: string;
}
