// AuthController — публичные эндпоинты входа и получения своего профиля.
import { Body, Controller, Get, Post, Patch, HttpCode } from '@nestjs/common';
import { Throttle } from '@nestjs/throttler';
import { AuthService } from './auth.service';
import { LoginDto } from './dto/login.dto';
import { SetTelegramChatIdDto } from './dto/set-telegram.dto';
import { Public } from '../common/decorators/public.decorator';
import { CurrentUser, AuthUser } from '../common/decorators/current-user.decorator';

@Controller('auth')
export class AuthController {
  constructor(private auth: AuthService) {}

  /**
   * POST /auth/login — вход по email и паролю. Открытый эндпоинт.
   * Жёстко ограничен (5 попыток в минуту с одного адреса) — защита от
   * перебора паролей, раз этот эндпоинт доступен из интернета без токена.
   */
  @Public()
  @Throttle({ default: { limit: 5, ttl: 60000 } })
  @Post('login')
  @HttpCode(200)
  login(@Body() dto: LoginDto) {
    return this.auth.login(dto);
  }

  /** GET /auth/me — кто я (по токену). */
  @Get('me')
  me(@CurrentUser() user: AuthUser) {
    return user;
  }

  /** PATCH /auth/me/telegram — привязать личный Telegram-чат для отчётов. */
  @Patch('me/telegram')
  setTelegram(@Body() dto: SetTelegramChatIdDto, @CurrentUser() user: AuthUser) {
    return this.auth.setTelegramChatId(user.userId, dto.telegramChatId);
  }
}
