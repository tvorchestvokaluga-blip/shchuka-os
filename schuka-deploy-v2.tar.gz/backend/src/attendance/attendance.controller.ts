// AttendanceController — /api/lessons/:lessonId/attendance
import { Body, Controller, Get, Param, Post } from '@nestjs/common';
import { UserRole } from '@prisma/client';
import { AttendanceService } from './attendance.service';
import { MarkAttendanceDto } from './dto/attendance.dto';
import { Roles } from '../common/decorators/roles.decorator';
import { CurrentUser, AuthUser } from '../common/decorators/current-user.decorator';

@Controller('lessons/:lessonId/attendance')
export class AttendanceController {
  constructor(private readonly attendance: AttendanceService) {}

  @Get()
  findByLesson(@Param('lessonId') lessonId: string, @CurrentUser() user: AuthUser) {
    return this.attendance.findByLesson(lessonId, user);
  }

  @Post()
  @Roles(UserRole.OWNER, UserRole.ADMIN, UserRole.TEACHER)
  markLesson(
    @Param('lessonId') lessonId: string,
    @Body() dto: MarkAttendanceDto,
    @CurrentUser() user: AuthUser,
  ) {
    return this.attendance.markLesson(lessonId, dto, user);
  }
}
