// AttendanceService — отметка посещаемости и списание занятий с абонемента.
//
// Самое важное: когда педагог отмечает ребёнка как PRESENT или MAKEUP,
// система АТОМАРНО списывает занятие с его активного абонемента.
// Это транзакция — либо оба действия произошли, либо ни одного.
// Нельзя отметить «был» и не списать занятие, и нельзя списать без отметки.
import { Injectable, NotFoundException, BadRequestException } from '@nestjs/common';
import { AttendanceStatus, UserRole } from '@prisma/client';
import { PrismaService } from '../prisma/prisma.service';
import { SubscriptionsService } from '../subscriptions/subscriptions.service';
import { AuthUser } from '../common/decorators/current-user.decorator';
import { MarkAttendanceDto } from './dto/attendance.dto';

@Injectable()
export class AttendanceService {
  constructor(
    private prisma: PrismaService,
    private subscriptions: SubscriptionsService,
  ) {}

  /** Посещаемость конкретного урока — для педагога и руководителя. */
  async findByLesson(lessonId: string, user: AuthUser) {
    const lesson = await this.prisma.lesson.findFirst({
      where: { id: lessonId, schoolId: user.schoolId }, select: { id: true },
    });
    if (!lesson) throw new NotFoundException('Урок не найден');

    return this.prisma.attendance.findMany({
      where: { lessonId },
      include: {
        enrollment: {
          include: { student: { select: { id: true, firstName: true, lastName: true, avatarEmoji: true } } },
        },
        subscription: { select: { remainingLessons: true, totalLessons: true } },
      },
    });
  }

  /**
   * Массовая отметка всего класса за один запрос.
   * PRESENT/MAKEUP → транзакция: attendance + deductLesson.
   * ABSENT/EXCUSED → только attendance, без списания.
   */
  async markLesson(lessonId: string, dto: MarkAttendanceDto, user: AuthUser) {
    const lesson = await this.prisma.lesson.findFirst({
      where: { id: lessonId, schoolId: user.schoolId },
      select: { id: true, groupId: true },
    });
    if (!lesson) throw new NotFoundException('Урок не найден');

    // проверяем, что педагог ведёт эту группу
    if (user.role === UserRole.TEACHER) {
      const teacher = await this.prisma.teacher.findUnique({
        where: { userId: user.userId }, select: { id: true },
      });
      const group = await this.prisma.group.findFirst({
        where: { id: lesson.groupId, teacherId: teacher?.id }, select: { id: true },
      });
      if (!group) throw new NotFoundException('Нет доступа к этому уроку');
    }

    const results = await Promise.all(
      dto.entries.map((entry) => this.markOneStudent(lessonId, entry.enrollmentId, entry.status, user.schoolId)),
    );
    return { marked: results.length, lesson: lessonId };
  }

  /** Отметить одного ребёнка — атомарная операция. */
  private async markOneStudent(
    lessonId: string,
    enrollmentId: string,
    status: AttendanceStatus,
    schoolId: string,
  ) {
    const enrollment = await this.prisma.enrollment.findFirst({
      where: { id: enrollmentId, schoolId }, select: { id: true },
    });
    if (!enrollment) throw new BadRequestException(`Зачисление ${enrollmentId} не найдено`);

    // уже отмечен — обновляем
    const existing = await this.prisma.attendance.findUnique({
      where: { lessonId_enrollmentId: { lessonId, enrollmentId } },
    });

    const shouldDeduct = status === AttendanceStatus.PRESENT || status === AttendanceStatus.MAKEUP;
    const wasDeducted = existing?.subscriptionId != null;

    return this.prisma.$transaction(async (tx) => {
      let subscriptionId: string | null = null;

      // списываем занятие только при первой отметке "был" (или смене с "не был" на "был")
      if (shouldDeduct && !wasDeducted) {
        const updated = await this.subscriptions.deductLesson(enrollmentId, schoolId);
        subscriptionId = updated.id;
      }

      if (existing) {
        return tx.attendance.update({
          where: { lessonId_enrollmentId: { lessonId, enrollmentId } },
          data: { status, subscriptionId: shouldDeduct ? subscriptionId ?? existing.subscriptionId : null },
        });
      }

      return tx.attendance.create({
        data: { lessonId, enrollmentId, status, subscriptionId },
      });
    });
  }
}
