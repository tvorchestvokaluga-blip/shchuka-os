// Данные запросов для посещаемости.
import { IsArray, IsEnum, IsString, ValidateNested } from 'class-validator';
import { Type } from 'class-transformer';
import { AttendanceStatus } from '@prisma/client';

export class AttendanceEntryDto {
  @IsString()
  enrollmentId: string;

  @IsEnum(AttendanceStatus, { message: 'Статус: PRESENT | ABSENT | EXCUSED | MAKEUP' })
  status: AttendanceStatus;
}

/** Массовая отметка всего класса за один запрос. */
export class MarkAttendanceDto {
  @IsArray()
  @ValidateNested({ each: true })
  @Type(() => AttendanceEntryDto)
  entries: AttendanceEntryDto[];
}
