// TelegramService — отправка отчётов руководителю в личный Telegram-чат.
// Токен бота (TELEGRAM_BOT_TOKEN) живёт только в .env на сервере.
// Два пути запуска: вручную (кнопка "Отправить в Telegram") и по расписанию (Cron, каждый понедельник).
import { Injectable, Logger, BadRequestException } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { Cron } from '@nestjs/schedule';
import axios from 'axios';
import { UserRole } from '@prisma/client';
import { PrismaService } from '../prisma/prisma.service';
import { ReportsService } from '../reports/reports.service';
import { AuthUser } from '../common/decorators/current-user.decorator';

@Injectable()
export class TelegramService {
  private readonly logger = new Logger(TelegramService.name);

  constructor(
    private prisma: PrismaService,
    private config: ConfigService,
    private reports: ReportsService,
  ) {}

  /** Отправить сводку + "Требуют внимания" в Telegram-чат текущего пользователя (кнопка в интерфейсе). */
  async sendWeeklyToUser(user: AuthUser) {
    const dbUser = await this.prisma.user.findUnique({ where: { id: user.userId }, select: { telegramChatId: true } });
    if (!dbUser?.telegramChatId) {
      throw new BadRequestException('Сначала привяжите Telegram-чат в настройках отчётов');
    }
    const text = await this.buildWeeklyMessage(user);
    await this.send(dbUser.telegramChatId, text);
    return { ok: true };
  }

  /** По расписанию: каждый понедельник в 8:00 — всем руководителям/администраторам с привязанным чатом. */
  @Cron('0 8 * * 1', { timeZone: 'Europe/Moscow' })
  async sendWeeklyToAllSubscribed() {
    const token = this.config.get<string>('TELEGRAM_BOT_TOKEN');
    if (!token) return; // бот ещё не настроен — тихо выходим, ничего не падает

    const subscribers = await this.prisma.user.findMany({
      where: {
        role: { in: [UserRole.OWNER, UserRole.ADMIN] },
        telegramChatId: { not: null },
        isActive: true,
      },
      select: { id: true, schoolId: true, role: true, telegramChatId: true },
    }).catch(() => []);

    for (const sub of subscribers) {
      if (!sub.telegramChatId) continue;
      try {
        const authUser: AuthUser = { userId: sub.id, schoolId: sub.schoolId, role: sub.role, email: '' };
        const text = await this.buildWeeklyMessage(authUser);
        await this.send(sub.telegramChatId, text);
      } catch (e) {
        this.logger.warn(`Не удалось отправить еженедельный отчёт пользователю ${sub.id}: ${e}`);
      }
    }
  }

  private async buildWeeklyMessage(user: AuthUser): Promise<string> {
    const [summary, alerts] = await Promise.all([
      this.reports.weeklySummary(user),
      this.reports.attentionAlerts(user),
    ]);

    const lines: string[] = [];
    lines.push('🐟 <b>Schuka OS — еженедельная сводка</b>');
    lines.push('');
    lines.push(`Занятий проведено: <b>${summary.lessonsHeld}</b>`);
    lines.push(`Посещаемость: <b>${summary.attendance.rate !== null ? summary.attendance.rate + '%' : '—'}</b>`);
    lines.push(`Новых зачислений: <b>${summary.enrollments.new}</b>`);
    lines.push(`Собрано оплат: <b>${summary.revenue.collected.toLocaleString('ru-RU')} ₽</b>`);
    if (summary.revenue.overdueCount > 0) {
      lines.push(`⚠️ Просрочено: ${summary.revenue.overdueAmount.toLocaleString('ru-RU')} ₽ (${summary.revenue.overdueCount})`);
    }
    if (summary.inventory.lowStockCount > 0) {
      lines.push(`📦 Нужно закупить: ${summary.inventory.lowStockCount} поз.`);
    }
    if (summary.tasks.open > 0) {
      lines.push(`📋 Открытых задач: ${summary.tasks.open}`);
    }
    if (summary.birthdays.length > 0) {
      lines.push(`🎂 Дни рождения: ${summary.birthdays.map((b) => b.name).join(', ')}`);
    }

    if (alerts.length > 0) {
      lines.push('');
      lines.push('<b>Требуют внимания:</b>');
      for (const a of alerts.slice(0, 10)) {
        lines.push(`• ${a.name} (${a.groupName}) — ${a.detail}`);
      }
      if (alerts.length > 10) lines.push(`…и ещё ${alerts.length - 10}`);
    }

    return lines.join('\n');
  }

  private async send(chatId: string, text: string) {
    const token = this.config.get<string>('TELEGRAM_BOT_TOKEN');
    if (!token) {
      throw new BadRequestException('TELEGRAM_BOT_TOKEN не настроен на сервере');
    }
    await axios.post(`https://api.telegram.org/bot${token}/sendMessage`, {
      chat_id: chatId,
      text,
      parse_mode: 'HTML',
    });
  }
}
