// TelegramController — /api/reports/send-telegram (кнопка "Отправить в Telegram" на странице отчётов).
import { Controller, Post } from '@nestjs/common';
import { UserRole } from '@prisma/client';
import { TelegramService } from './telegram.service';
import { Roles } from '../common/decorators/roles.decorator';
import { CurrentUser, AuthUser } from '../common/decorators/current-user.decorator';

@Controller('reports')
@Roles(UserRole.OWNER, UserRole.ADMIN)
export class TelegramController {
  constructor(private readonly telegram: TelegramService) {}

  @Post('send-telegram')
  sendTelegram(@CurrentUser() user: AuthUser) {
    return this.telegram.sendWeeklyToUser(user);
  }
}
