// ProgramsService — каталог направлений обучения школы.
// Программы видят все роли (для записи детей нужно знать каталог),
// но менять может только руководство. Всё ограничено школой пользователя.
import { Injectable, NotFoundException, BadRequestException } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { AuthUser } from '../common/decorators/current-user.decorator';
import { CreateProgramDto, UpdateProgramDto } from './dto/program.dto';

@Injectable()
export class ProgramsService {
  constructor(private prisma: PrismaService) {}

  findAll(user: AuthUser) {
    return this.prisma.program.findMany({
      where: { schoolId: user.schoolId },
      include: { _count: { select: { groups: true, enrollments: true } } },
      orderBy: { name: 'asc' },
    });
  }

  async findOne(id: string, user: AuthUser) {
    const program = await this.prisma.program.findFirst({
      where: { id, schoolId: user.schoolId },
      include: { modules: { orderBy: { orderIndex: 'asc' } }, groups: true },
    });
    if (!program) throw new NotFoundException('Программа не найдена');
    return program;
  }

  create(dto: CreateProgramDto, user: AuthUser) {
    if (dto.ageFrom > dto.ageTo) {
      throw new BadRequestException('Возраст «от» не может быть больше «до»');
    }
    return this.prisma.program.create({
      data: { schoolId: user.schoolId, ...dto },
    });
  }

  async update(id: string, dto: UpdateProgramDto, user: AuthUser) {
    await this.ensureInSchool(id, user.schoolId);
    if (dto.ageFrom != null && dto.ageTo != null && dto.ageFrom > dto.ageTo) {
      throw new BadRequestException('Возраст «от» не может быть больше «до»');
    }
    return this.prisma.program.update({ where: { id }, data: dto });
  }

  private async ensureInSchool(id: string, schoolId: string) {
    const p = await this.prisma.program.findFirst({
      where: { id, schoolId }, select: { id: true },
    });
    if (!p) throw new NotFoundException('Программа не найдена');
  }
}
