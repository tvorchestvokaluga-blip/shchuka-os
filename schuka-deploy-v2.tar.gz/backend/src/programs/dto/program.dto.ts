// Данные запросов для программ обучения, с валидацией.
import { IsBoolean, IsInt, IsNumber, IsOptional, IsString, Min, MinLength } from 'class-validator';

export class CreateProgramDto {
  @IsString()
  @MinLength(2)
  name: string;

  @IsOptional()
  @IsString()
  description?: string;

  @IsInt()
  @Min(0)
  ageFrom: number;

  @IsInt()
  @Min(0)
  ageTo: number;

  @IsNumber()
  @Min(0)
  basePrice: number;
}

export class UpdateProgramDto {
  @IsOptional() @IsString() @MinLength(2) name?: string;
  @IsOptional() @IsString() description?: string;
  @IsOptional() @IsInt() @Min(0) ageFrom?: number;
  @IsOptional() @IsInt() @Min(0) ageTo?: number;
  @IsOptional() @IsNumber() @Min(0) basePrice?: number;
  @IsOptional() @IsBoolean() isActive?: boolean;
}
