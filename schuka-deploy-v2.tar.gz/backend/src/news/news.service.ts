// NewsService — новости школы. Публикует руководитель/администратор,
// видят все родители школы (только опубликованные).
import { Injectable, NotFoundException, ForbiddenException } from '@nestjs/common';
import { UserRole } from '@prisma/client';
import { PrismaService } from '../prisma/prisma.service';
import { AuthUser } from '../common/decorators/current-user.decorator';
import { CreateNewsDto, UpdateNewsDto } from './dto/news.dto';

@Injectable()
export class NewsService {
  constructor(private prisma: PrismaService) {}

  /** Родитель видит только опубликованные новости своей школы. Персонал — все, включая черновики. */
  async findAll(user: AuthUser) {
    const isStaff = user.role !== UserRole.PARENT;
    return this.prisma.newsPost.findMany({
      where: {
        schoolId: user.schoolId,
        ...(isStaff ? {} : { isPublished: true }),
      },
      include: { author: { select: { fullName: true } } },
      orderBy: { publishedAt: 'desc' },
    });
  }

  async create(dto: CreateNewsDto, user: AuthUser) {
    return this.prisma.newsPost.create({
      data: {
        schoolId: user.schoolId,
        authorId: user.userId,
        title: dto.title,
        body: dto.body,
        isPublished: dto.isPublished ?? true,
      },
      include: { author: { select: { fullName: true } } },
    });
  }

  async update(id: string, dto: UpdateNewsDto, user: AuthUser) {
    const post = await this.prisma.newsPost.findFirst({
      where: { id, schoolId: user.schoolId }, select: { id: true },
    });
    if (!post) throw new NotFoundException('Новость не найдена');
    return this.prisma.newsPost.update({ where: { id }, data: dto });
  }

  async remove(id: string, user: AuthUser) {
    const post = await this.prisma.newsPost.findFirst({
      where: { id, schoolId: user.schoolId }, select: { id: true },
    });
    if (!post) throw new NotFoundException('Новость не найдена');
    return this.prisma.newsPost.delete({ where: { id } });
  }
}
