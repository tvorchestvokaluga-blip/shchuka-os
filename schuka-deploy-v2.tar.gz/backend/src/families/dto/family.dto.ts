// Данные запросов для семей, с валидацией.
import { IsOptional, IsString, MinLength } from 'class-validator';

export class CreateFamilyDto {
  @IsString()
  @MinLength(2, { message: 'Название семьи слишком короткое' })
  name: string;

  @IsOptional()
  @IsString()
  note?: string;
}

export class UpdateFamilyDto {
  @IsOptional()
  @IsString()
  @MinLength(2)
  name?: string;

  @IsOptional()
  @IsString()
  note?: string;
}
