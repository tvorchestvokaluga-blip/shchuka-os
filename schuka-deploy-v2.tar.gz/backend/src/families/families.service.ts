// FamiliesService — бизнес-логика семей.
// Ключевая ответственность: каждый запрос ограничен школой пользователя (schoolId),
// а родитель видит только свою семью.
import { Injectable, NotFoundException, ForbiddenException } from '@nestjs/common';
import { UserRole } from '@prisma/client';
import { PrismaService } from '../prisma/prisma.service';
import { AuthUser } from '../common/decorators/current-user.decorator';
import { CreateFamilyDto, UpdateFamilyDto } from './dto/family.dto';

@Injectable()
export class FamiliesService {
  constructor(private prisma: PrismaService) {}

  /** Список семей школы. Родителю отдаём только его семью. */
  async findAll(user: AuthUser) {
    if (user.role === UserRole.PARENT) {
      const parent = await this.prisma.parent.findUnique({
        where: { userId: user.userId },
        include: { family: { include: { students: { where: { deletedAt: null } } } } },
      });
      return parent ? [parent.family] : [];
    }
    return this.prisma.family.findMany({
      where: { schoolId: user.schoolId, deletedAt: null },
      include: {
        students: { where: { deletedAt: null } },
        parents: { include: { user: true } },
      },
      orderBy: { name: 'asc' },
    });
  }

  /** Одна семья. Проверяем и школу, и право родителя видеть именно её. */
  async findOne(id: string, user: AuthUser) {
    const family = await this.prisma.family.findFirst({
      where: { id, schoolId: user.schoolId, deletedAt: null },
      include: {
        students: { where: { deletedAt: null } },
        parents: { include: { user: { select: { id: true, fullName: true, email: true, phone: true } } } },
      },
    });
    if (!family) throw new NotFoundException('Семья не найдена');

    await this.assertParentOwnsFamily(user, id);
    return family;
  }

  /** Создать семью — только сотрудники школы. */
  async create(dto: CreateFamilyDto, user: AuthUser) {
    return this.prisma.family.create({
      data: { schoolId: user.schoolId, name: dto.name, note: dto.note },
    });
  }

  async update(id: string, dto: UpdateFamilyDto, user: AuthUser) {
    await this.ensureInSchool(id, user.schoolId);
    return this.prisma.family.update({ where: { id }, data: dto });
  }

  /** Мягкое удаление — запись остаётся в базе (история, 152-ФЗ). */
  async remove(id: string, user: AuthUser) {
    await this.ensureInSchool(id, user.schoolId);
    return this.prisma.family.update({
      where: { id },
      data: { deletedAt: new Date() },
    });
  }

  // ── вспомогательные проверки ────────────────────────────────────────────
  private async ensureInSchool(familyId: string, schoolId: string) {
    const f = await this.prisma.family.findFirst({
      where: { id: familyId, schoolId, deletedAt: null },
      select: { id: true },
    });
    if (!f) throw new NotFoundException('Семья не найдена');
  }

  /** Если пользователь — родитель, он может работать только со своей семьёй. */
  private async assertParentOwnsFamily(user: AuthUser, familyId: string) {
    if (user.role !== UserRole.PARENT) return;
    const parent = await this.prisma.parent.findUnique({
      where: { userId: user.userId },
      select: { familyId: true },
    });
    if (!parent || parent.familyId !== familyId) {
      throw new ForbiddenException('Нет доступа к этой семье');
    }
  }
}
