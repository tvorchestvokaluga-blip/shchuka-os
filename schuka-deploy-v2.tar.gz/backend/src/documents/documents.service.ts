// DocumentsService — договоры и соглашения семьи. Загружает админ/руководитель,
// видит родитель (только документы своей семьи).
import { Injectable, NotFoundException, ForbiddenException } from '@nestjs/common';
import { UserRole } from '@prisma/client';
import { PrismaService } from '../prisma/prisma.service';
import { AuthUser } from '../common/decorators/current-user.decorator';
import { CreateDocumentDto, UpdateDocumentDto } from './dto/document.dto';

@Injectable()
export class DocumentsService {
  constructor(private prisma: PrismaService) {}

  /** Документы одной семьи. Родитель может смотреть только свою. */
  async findByFamily(familyId: string, user: AuthUser) {
    const family = await this.prisma.family.findFirst({
      where: { id: familyId, schoolId: user.schoolId }, select: { id: true },
    });
    if (!family) throw new NotFoundException('Семья не найдена');

    if (user.role === UserRole.PARENT) {
      await this.assertParentOwnsFamily(familyId, user);
    }

    return this.prisma.document.findMany({
      where: { familyId },
      include: { uploadedBy: { select: { fullName: true } } },
      orderBy: { createdAt: 'desc' },
    });
  }

  /** Лента документов текущего пользователя: родителю — его семья, персоналу — вся школа. */
  async findForUser(user: AuthUser) {
    if (user.role === UserRole.PARENT) {
      const parent = await this.prisma.parent.findUnique({
        where: { userId: user.userId }, select: { familyId: true },
      });
      if (!parent) return [];
      return this.prisma.document.findMany({
        where: { familyId: parent.familyId },
        include: { uploadedBy: { select: { fullName: true } } },
        orderBy: { createdAt: 'desc' },
      });
    }

    return this.prisma.document.findMany({
      where: { schoolId: user.schoolId },
      include: {
        uploadedBy: { select: { fullName: true } },
        family: { select: { id: true, name: true } },
      },
      orderBy: { createdAt: 'desc' },
    });
  }

  async create(dto: CreateDocumentDto, user: AuthUser) {
    const family = await this.prisma.family.findFirst({
      where: { id: dto.familyId, schoolId: user.schoolId }, select: { id: true },
    });
    if (!family) throw new NotFoundException('Семья не найдена');

    return this.prisma.document.create({
      data: {
        schoolId: user.schoolId,
        familyId: dto.familyId,
        type: dto.type,
        title: dto.title,
        url: dto.url,
        uploadedById: user.userId,
      },
      include: { uploadedBy: { select: { fullName: true } } },
    });
  }

  async update(id: string, dto: UpdateDocumentDto, user: AuthUser) {
    const doc = await this.prisma.document.findFirst({
      where: { id, schoolId: user.schoolId }, select: { id: true },
    });
    if (!doc) throw new NotFoundException('Документ не найден');
    return this.prisma.document.update({ where: { id }, data: dto });
  }

  async remove(id: string, user: AuthUser) {
    const doc = await this.prisma.document.findFirst({
      where: { id, schoolId: user.schoolId }, select: { id: true },
    });
    if (!doc) throw new NotFoundException('Документ не найден');
    return this.prisma.document.delete({ where: { id } });
  }

  // ── приватные проверки ───────────────────────────────────────────────────
  private async assertParentOwnsFamily(familyId: string, user: AuthUser) {
    const parent = await this.prisma.parent.findUnique({
      where: { userId: user.userId }, select: { familyId: true },
    });
    if (parent?.familyId !== familyId) {
      throw new ForbiddenException('Нет доступа к документам этой семьи');
    }
  }
}
