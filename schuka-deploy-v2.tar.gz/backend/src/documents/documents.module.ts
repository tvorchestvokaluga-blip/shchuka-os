import { Module } from '@nestjs/common';
import { DocumentsService } from './documents.service';
import { DocumentsController, FamilyDocumentsController } from './documents.controller';

@Module({
  controllers: [DocumentsController, FamilyDocumentsController],
  providers: [DocumentsService],
  exports: [DocumentsService],
})
export class DocumentsModule {}
