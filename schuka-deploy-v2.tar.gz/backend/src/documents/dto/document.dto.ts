// Данные запросов для документов семьи (договоры, соглашения).
import { IsEnum, IsOptional, IsString, MinLength } from 'class-validator';
import { DocumentType } from '@prisma/client';

export class CreateDocumentDto {
  @IsString()
  familyId: string;

  @IsOptional()
  @IsEnum(DocumentType)
  type?: DocumentType;

  @IsString()
  @MinLength(1)
  title: string;

  @IsString()
  @MinLength(1)
  url: string;
}

export class UpdateDocumentDto {
  @IsOptional() @IsEnum(DocumentType) type?: DocumentType;
  @IsOptional() @IsString() @MinLength(1) title?: string;
  @IsOptional() @IsString() @MinLength(1) url?: string;
}
