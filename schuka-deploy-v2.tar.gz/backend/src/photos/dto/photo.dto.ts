// Данные запросов для фотографий.
import { IsArray, IsOptional, IsString } from 'class-validator';

export class CreatePhotoDto {
  @IsString()
  studentId: string;

  @IsOptional()
  @IsString()
  lessonId?: string;

  @IsString()
  url: string; // путь к файлу, полученный от POST /api/photos/upload

  @IsOptional()
  @IsString()
  caption?: string;
}

/** Массовая привязка одного фото к нескольким детям группы. */
export class BulkCreatePhotosDto {
  @IsString()
  lessonId: string;

  @IsArray()
  @IsString({ each: true })
  studentIds: string[]; // всем детям из списка добавится это фото

  @IsString()
  url: string;

  @IsOptional()
  @IsString()
  caption?: string;
}
