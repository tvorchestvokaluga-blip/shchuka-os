import { Module } from '@nestjs/common';
import { PhotosService } from './photos.service';
import { PhotosController, StudentPhotosController, LessonPhotosController } from './photos.controller';
import { CommentsModule } from '../comments/comments.module';

@Module({
  imports: [CommentsModule],
  controllers: [PhotosController, StudentPhotosController, LessonPhotosController],
  providers: [PhotosService],
  exports: [PhotosService],
})
export class PhotosModule {}
