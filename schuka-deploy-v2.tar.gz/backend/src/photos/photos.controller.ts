// PhotosController — /api/students/:studentId/photos, /api/lessons/:lessonId/photos, /api/photos
import {
  BadRequestException,
  Body,
  Controller,
  Delete,
  Get,
  Param,
  Post,
  UploadedFile,
  UseInterceptors,
} from '@nestjs/common';
import { FileInterceptor } from '@nestjs/platform-express';
import { diskStorage } from 'multer';
import { extname, join } from 'path';
import * as fs from 'fs';
import * as crypto from 'crypto';
import { UserRole } from '@prisma/client';
import { PhotosService } from './photos.service';
import { CommentsService } from '../comments/comments.service';
import { CreatePhotoDto, BulkCreatePhotosDto } from './dto/photo.dto';
import { Roles } from '../common/decorators/roles.decorator';
import { CurrentUser, AuthUser } from '../common/decorators/current-user.decorator';

@Controller('students/:studentId/photos')
export class StudentPhotosController {
  constructor(private readonly photos: PhotosService) {}

  @Get()
  findByStudent(@Param('studentId') studentId: string, @CurrentUser() user: AuthUser) {
    return this.photos.findByStudent(studentId, user);
  }
}

@Controller('lessons/:lessonId/photos')
export class LessonPhotosController {
  constructor(
    private readonly photos: PhotosService,
    private readonly comments: CommentsService,
  ) {}

  @Get()
  @Roles(UserRole.OWNER, UserRole.ADMIN, UserRole.TEACHER)
  findByLesson(@Param('lessonId') lessonId: string, @CurrentUser() user: AuthUser) {
    return this.photos.findByLesson(lessonId, user);
  }

  @Post('bulk')
  @Roles(UserRole.OWNER, UserRole.ADMIN, UserRole.TEACHER)
  bulkCreate(@Body() dto: BulkCreatePhotosDto, @CurrentUser() user: AuthUser) {
    return this.photos.bulkCreate(dto, user);
  }

  /**
   * Как /bulk, но для каждого ребёнка ещё сразу создаёт авто-комментарий
   * педагога об этом уроке ("по скрипту") — используется загрузкой фото
   * из раздела «Мои группы». Комментарий и фото сразу видны родителю.
   */
  @Post('bulk-with-comment')
  @Roles(UserRole.OWNER, UserRole.ADMIN, UserRole.TEACHER)
  async bulkCreateWithComment(
    @Param('lessonId') lessonId: string,
    @Body() dto: BulkCreatePhotosDto,
    @CurrentUser() user: AuthUser,
  ) {
    const result = await this.photos.bulkCreate({ ...dto, lessonId }, user);
    const created = await Promise.all(
      dto.studentIds.map((studentId) =>
        this.comments.autoCreateForLessonPhoto({ studentId, lessonId }, user).catch(() => null),
      ),
    );
    return { ...result, commentsCreated: created.filter(Boolean).length };
  }
}

const MAX_PHOTO_SIZE = 15 * 1024 * 1024; // 15 МБ
const ALLOWED_MIME = /^image\/(jpeg|png|webp|gif|heic|heif)$/i;

@Controller('photos')
export class PhotosController {
  constructor(private readonly photos: PhotosService) {}

  /**
   * Загрузка файла фото с занятия.
   * Тестовое (локальное) хранилище — файл сохраняется прямо на диске сервера,
   * в папке uploads/photos/<школа>/, и отдаётся статикой по /uploads/...
   * Когда подключим облако (S3/Я.Облако) — поменяется только это место,
   * остальной код (create/bulkCreate по url) останется как есть.
   */
  @Post('upload')
  @Roles(UserRole.OWNER, UserRole.ADMIN, UserRole.TEACHER)
  @UseInterceptors(
    FileInterceptor('file', {
      storage: diskStorage({
        destination: (req: any, _file, cb) => {
          const schoolId = req.user?.schoolId || 'common';
          const dir = join(__dirname, '..', '..', 'uploads', 'photos', schoolId);
          fs.mkdirSync(dir, { recursive: true });
          cb(null, dir);
        },
        filename: (_req, file, cb) => {
          const ext = (extname(file.originalname) || '.jpg').toLowerCase();
          cb(null, `${crypto.randomUUID()}${ext}`);
        },
      }),
      limits: { fileSize: MAX_PHOTO_SIZE },
      fileFilter: (_req, file, cb) => {
        if (!ALLOWED_MIME.test(file.mimetype)) {
          return cb(new BadRequestException('Можно загружать только изображения (jpg, png, webp, heic)'), false);
        }
        cb(null, true);
      },
    }),
  )
  uploadFile(@UploadedFile() file: any, @CurrentUser() user: AuthUser) {
    if (!file) throw new BadRequestException('Файл не получен');
    return { url: `/uploads/photos/${user.schoolId}/${file.filename}` };
  }

  @Post()
  @Roles(UserRole.OWNER, UserRole.ADMIN, UserRole.TEACHER)
  create(@Body() dto: CreatePhotoDto, @CurrentUser() user: AuthUser) {
    return this.photos.create(dto, user);
  }

  @Delete(':id')
  @Roles(UserRole.OWNER, UserRole.ADMIN)
  remove(@Param('id') id: string, @CurrentUser() user: AuthUser) {
    return this.photos.remove(id, user);
  }
}
