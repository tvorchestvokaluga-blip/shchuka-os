// PhotosService — управление фотографиями с занятий.
//
// Хранение файлов — тестовое (локальное): файлы лежат на диске сервера
// в uploads/photos/<школа>/, сама загрузка обрабатывается в PhotosController
// через multer (POST /api/photos/upload). Здесь — только запись/чтение
// в базе (создание записи о фото после того, как файл уже сохранён).
// Когда подключим облако (S3/Я.Облако) — поменяется только upload-эндпоинт,
// эта логика не тронется.
//
// BulkCreate — специально для Telegram-бота сбора фото и для загрузки фото
// педагогом с урока: один снимок привязывается сразу ко всем выбранным детям группы.
import { Injectable, NotFoundException, ForbiddenException } from '@nestjs/common';
import { UserRole } from '@prisma/client';
import { PrismaService } from '../prisma/prisma.service';
import { AuthUser } from '../common/decorators/current-user.decorator';
import { CreatePhotoDto, BulkCreatePhotosDto } from './dto/photo.dto';
import { join } from 'path';
import * as fs from 'fs';

@Injectable()
export class PhotosService {
  constructor(private prisma: PrismaService) {}

  /** Фотографии ребёнка — для его Паспорта и кабинета родителя. */
  async findByStudent(studentId: string, user: AuthUser) {
    await this.assertCanViewStudent(studentId, user);
    return this.prisma.photo.findMany({
      where: { studentId },
      include: { lesson: { select: { date: true, topic: true } } },
      orderBy: { createdAt: 'desc' },
    });
  }

  /** Фотографии урока — для педагога и руководителя. */
  async findByLesson(lessonId: string, user: AuthUser) {
    const lesson = await this.prisma.lesson.findFirst({
      where: { id: lessonId, schoolId: user.schoolId }, select: { id: true },
    });
    if (!lesson) throw new NotFoundException('Урок не найден');
    return this.prisma.photo.findMany({ where: { lessonId }, orderBy: { createdAt: 'desc' } });
  }

  /** Сохранить одно фото (после загрузки через /api/photos/upload). */
  async create(dto: CreatePhotoDto, user: AuthUser) {
    await this.assertStudentInSchool(dto.studentId, user.schoolId);
    return this.prisma.photo.create({
      data: {
        schoolId: user.schoolId,
        studentId: dto.studentId,
        lessonId: dto.lessonId,
        url: dto.url,
        caption: dto.caption,
      },
    });
  }

  /**
   * Массовая привязка: одно фото → сразу нескольким детям урока.
   * Используется Telegram-ботом и педагогом при загрузке с занятия.
   */
  async bulkCreate(dto: BulkCreatePhotosDto, user: AuthUser) {
    const lesson = await this.prisma.lesson.findFirst({
      where: { id: dto.lessonId, schoolId: user.schoolId }, select: { id: true },
    });
    if (!lesson) throw new NotFoundException('Урок не найден');

    const data = dto.studentIds.map((studentId) => ({
      schoolId: user.schoolId,
      studentId,
      lessonId: dto.lessonId,
      url: dto.url,
      caption: dto.caption,
    }));

    await this.prisma.photo.createMany({ data });
    return { created: data.length };
  }

  async remove(id: string, user: AuthUser) {
    const photo = await this.prisma.photo.findFirst({
      where: { id, schoolId: user.schoolId },
    });
    if (!photo) throw new NotFoundException('Фото не найдено');
    // если это файл из локального хранилища (uploads/...) — удаляем и сам файл с диска
    if (photo.url?.startsWith('/uploads/')) {
      const filePath = join(__dirname, '..', '..', photo.url);
      fs.unlink(filePath, () => {}); // не критично, если файла уже нет
    }
    return this.prisma.photo.delete({ where: { id } });
  }

  // ── приватные проверки ───────────────────────────────────────────────────
  private async assertStudentInSchool(studentId: string, schoolId: string) {
    const s = await this.prisma.student.findFirst({
      where: { id: studentId, schoolId, deletedAt: null }, select: { id: true },
    });
    if (!s) throw new NotFoundException('Ученик не найден');
  }

  private async assertCanViewStudent(studentId: string, user: AuthUser) {
    if (user.role === UserRole.OWNER || user.role === UserRole.ADMIN) return;
    if (user.role === UserRole.PARENT) {
      const parent = await this.prisma.parent.findUnique({
        where: { userId: user.userId }, select: { familyId: true },
      });
      const student = await this.prisma.student.findFirst({
        where: { id: studentId, familyId: parent?.familyId ?? '__none__' }, select: { id: true },
      });
      if (!student) throw new ForbiddenException('Нет доступа к фото этого ребёнка');
    }
  }
}
