// Данные запросов для абонементов, с валидацией.
import { IsDateString, IsInt, IsNumber, IsOptional, IsString, Min } from 'class-validator';

export class CreateSubscriptionDto {
  @IsString()
  enrollmentId: string;

  @IsInt()
  @Min(1)
  totalLessons: number; // сколько занятий покупают

  @IsNumber()
  @Min(0)
  amount: number; // сумма к оплате

  @IsOptional()
  @IsDateString()
  expiryDate?: string; // срок действия абонемента
}
