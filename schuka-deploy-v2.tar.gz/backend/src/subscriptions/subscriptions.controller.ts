// SubscriptionsController — /api/enrollments/:enrollmentId/subscriptions
// Абонементы привязаны к зачислению, поэтому вложенный URL.
import { Body, Controller, Get, Param, Post } from '@nestjs/common';
import { UserRole } from '@prisma/client';
import { SubscriptionsService } from './subscriptions.service';
import { CreateSubscriptionDto } from './dto/subscription.dto';
import { Roles } from '../common/decorators/roles.decorator';
import { CurrentUser, AuthUser } from '../common/decorators/current-user.decorator';

@Controller('enrollments/:enrollmentId/subscriptions')
export class SubscriptionsController {
  constructor(private readonly subscriptions: SubscriptionsService) {}

  @Get()
  findAll(@Param('enrollmentId') enrollmentId: string, @CurrentUser() user: AuthUser) {
    return this.subscriptions.findByEnrollment(enrollmentId, user);
  }

  @Post()
  @Roles(UserRole.OWNER, UserRole.ADMIN)
  create(@Body() dto: CreateSubscriptionDto, @CurrentUser() user: AuthUser) {
    return this.subscriptions.create(dto, user);
  }
}
