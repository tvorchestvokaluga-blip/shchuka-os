// SubscriptionsService — пакеты занятий, привязанные к зачислению.
// Главное: создание абонемента одновременно создаёт запись Payment (ожидает оплаты).
// Это происходит в транзакции — нельзя иметь абонемент без счёта или счёт без абонемента.
import { Injectable, NotFoundException, BadRequestException } from '@nestjs/common';
import { UserRole, SubscriptionStatus } from '@prisma/client';
import { PrismaService } from '../prisma/prisma.service';
import { AuthUser } from '../common/decorators/current-user.decorator';
import { CreateSubscriptionDto } from './dto/subscription.dto';

@Injectable()
export class SubscriptionsService {
  constructor(private prisma: PrismaService) {}

  /** Абонементы видят сотрудники (все по школе) и родитель (только своих детей). */
  async findByEnrollment(enrollmentId: string, user: AuthUser) {
    const enrollment = await this.prisma.enrollment.findFirst({
      where: { id: enrollmentId, schoolId: user.schoolId },
      select: { id: true, student: { select: { family: { select: { id: true } } } } },
    });
    if (!enrollment) throw new NotFoundException('Зачисление не найдено');

    // родитель может смотреть только абонементы своей семьи
    if (user.role === UserRole.PARENT) {
      const parent = await this.prisma.parent.findUnique({
        where: { userId: user.userId }, select: { familyId: true },
      });
      if (enrollment.student.family.id !== parent?.familyId) {
        throw new NotFoundException('Зачисление не найдено');
      }
    }

    return this.prisma.subscription.findMany({
      where: { enrollmentId },
      include: { payment: true },
      orderBy: { createdAt: 'desc' },
    });
  }

  /**
   * Создать абонемент + счёт за него — одна неделимая операция.
   * Транзакция гарантирует, что либо оба объекта создались, либо ни одного.
   */
  async create(dto: CreateSubscriptionDto, user: AuthUser) {
    const enrollment = await this.prisma.enrollment.findFirst({
      where: { id: dto.enrollmentId, schoolId: user.schoolId, status: 'ACTIVE' },
      select: { id: true },
    });
    if (!enrollment) {
      throw new BadRequestException('Зачисление не найдено или неактивно');
    }

    // проверяем, нет ли уже активного абонемента на этом зачислении
    const existing = await this.prisma.subscription.findFirst({
      where: { enrollmentId: dto.enrollmentId, status: SubscriptionStatus.ACTIVE },
      select: { id: true },
    });
    if (existing) {
      throw new BadRequestException('Уже есть активный абонемент на этом зачислении');
    }

    // транзакция: subscription + payment
    return this.prisma.$transaction(async (tx) => {
      const subscription = await tx.subscription.create({
        data: {
          schoolId: user.schoolId,
          enrollmentId: dto.enrollmentId,
          totalLessons: dto.totalLessons,
          remainingLessons: dto.totalLessons,
          status: SubscriptionStatus.ACTIVE,
          expiryDate: dto.expiryDate ? new Date(dto.expiryDate) : undefined,
        },
      });
      const payment = await tx.payment.create({
        data: {
          schoolId: user.schoolId,
          subscriptionId: subscription.id,
          amount: dto.amount,
          status: 'PENDING',
          dueDate: dto.expiryDate ? new Date(dto.expiryDate) : undefined,
        },
      });
      return { subscription, payment };
    });
  }

  /**
   * Метод для AttendanceService: списывает одно занятие с активного абонемента.
   * Возвращает подписку с обновлённым остатком или выбрасывает ошибку.
   */
  async deductLesson(enrollmentId: string, schoolId: string) {
    const sub = await this.prisma.subscription.findFirst({
      where: { enrollmentId, schoolId, status: SubscriptionStatus.ACTIVE },
    });
    if (!sub) throw new BadRequestException('Нет активного абонемента для списания');
    if (sub.remainingLessons <= 0) throw new BadRequestException('Занятия на абонементе закончились');

    const remaining = sub.remainingLessons - 1;
    return this.prisma.subscription.update({
      where: { id: sub.id },
      data: {
        remainingLessons: remaining,
        status: remaining === 0 ? SubscriptionStatus.EXHAUSTED : SubscriptionStatus.ACTIVE,
      },
    });
  }
}
