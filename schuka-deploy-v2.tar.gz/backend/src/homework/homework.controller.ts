// HomeworkController — /api/groups/:groupId/homework  и  /api/homework
import { Body, Controller, Delete, Get, Param, Patch, Post } from '@nestjs/common';
import { UserRole } from '@prisma/client';
import { HomeworkService } from './homework.service';
import { CreateHomeworkDto, UpdateHomeworkDto } from './dto/homework.dto';
import { Roles } from '../common/decorators/roles.decorator';
import { CurrentUser, AuthUser } from '../common/decorators/current-user.decorator';

@Controller('groups/:groupId/homework')
export class GroupHomeworkController {
  constructor(private readonly homework: HomeworkService) {}

  @Get()
  findByGroup(@Param('groupId') groupId: string, @CurrentUser() user: AuthUser) {
    return this.homework.findByGroup(groupId, user);
  }
}

@Controller('homework')
export class HomeworkController {
  constructor(private readonly homework: HomeworkService) {}

  @Get()
  findForCurrentUser(@CurrentUser() user: AuthUser) {
    return this.homework.findForUser(user);
  }

  @Post()
  @Roles(UserRole.OWNER, UserRole.ADMIN, UserRole.TEACHER)
  create(@Body() dto: CreateHomeworkDto, @CurrentUser() user: AuthUser) {
    return this.homework.create(dto, user);
  }

  @Patch(':id')
  @Roles(UserRole.OWNER, UserRole.ADMIN, UserRole.TEACHER)
  update(@Param('id') id: string, @Body() dto: UpdateHomeworkDto, @CurrentUser() user: AuthUser) {
    return this.homework.update(id, dto, user);
  }

  @Delete(':id')
  @Roles(UserRole.OWNER, UserRole.ADMIN, UserRole.TEACHER)
  remove(@Param('id') id: string, @CurrentUser() user: AuthUser) {
    return this.homework.remove(id, user);
  }
}
