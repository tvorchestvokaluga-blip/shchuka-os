import { Module } from '@nestjs/common';
import { HomeworkService } from './homework.service';
import { HomeworkController, GroupHomeworkController } from './homework.controller';

@Module({
  controllers: [HomeworkController, GroupHomeworkController],
  providers: [HomeworkService],
  exports: [HomeworkService],
})
export class HomeworkModule {}
