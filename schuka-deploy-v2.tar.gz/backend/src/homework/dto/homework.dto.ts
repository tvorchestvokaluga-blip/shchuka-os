// Данные запросов для домашних заданий.
import { IsDateString, IsOptional, IsString, MinLength } from 'class-validator';

export class CreateHomeworkDto {
  @IsString()
  groupId: string;

  @IsOptional()
  @IsString()
  lessonId?: string;

  @IsString()
  @MinLength(1)
  title: string;

  @IsString()
  @MinLength(1)
  description: string;

  @IsOptional()
  @IsDateString()
  dueDate?: string;

  @IsOptional()
  @IsString()
  attachmentUrl?: string;
}

export class UpdateHomeworkDto {
  @IsOptional() @IsString() @MinLength(1) title?: string;
  @IsOptional() @IsString() @MinLength(1) description?: string;
  @IsOptional() @IsDateString() dueDate?: string;
  @IsOptional() @IsString() attachmentUrl?: string;
}
