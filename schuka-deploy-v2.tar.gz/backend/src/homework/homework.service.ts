// HomeworkService — домашние задания. Педагог задаёт группе, родитель видит
// задания по группам, в которых учатся его дети.
import { Injectable, NotFoundException, ForbiddenException } from '@nestjs/common';
import { UserRole } from '@prisma/client';
import { PrismaService } from '../prisma/prisma.service';
import { AuthUser } from '../common/decorators/current-user.decorator';
import { CreateHomeworkDto, UpdateHomeworkDto } from './dto/homework.dto';

const INCLUDE = {
  group: { select: { id: true, name: true } },
  lesson: { select: { id: true, date: true, topic: true } },
  author: { select: { fullName: true } },
} as const;

@Injectable()
export class HomeworkService {
  constructor(private prisma: PrismaService) {}

  /** Домашние задания одной группы (для педагога/админа — управление, для родителя — если ребёнок в группе). */
  async findByGroup(groupId: string, user: AuthUser) {
    const group = await this.prisma.group.findFirst({
      where: { id: groupId, schoolId: user.schoolId }, select: { id: true },
    });
    if (!group) throw new NotFoundException('Группа не найдена');

    if (user.role === UserRole.PARENT) {
      await this.assertParentHasChildInGroup(groupId, user);
    }

    return this.prisma.homework.findMany({
      where: { groupId },
      include: INCLUDE,
      orderBy: { createdAt: 'desc' },
    });
  }

  /** Лента домашних заданий текущего пользователя (родитель — по своим детям, педагог — по своим группам). */
  async findForUser(user: AuthUser) {
    if (user.role === UserRole.PARENT) {
      const groupIds = await this.getParentGroupIds(user);
      if (groupIds.length === 0) return [];
      return this.prisma.homework.findMany({
        where: { groupId: { in: groupIds } },
        include: INCLUDE,
        orderBy: { createdAt: 'desc' },
      });
    }

    if (user.role === UserRole.TEACHER) {
      const teacher = await this.prisma.teacher.findUnique({
        where: { userId: user.userId }, select: { id: true },
      });
      return this.prisma.homework.findMany({
        where: { group: { teacherId: teacher?.id ?? '__none__' } },
        include: INCLUDE,
        orderBy: { createdAt: 'desc' },
      });
    }

    // OWNER / ADMIN — вся школа
    return this.prisma.homework.findMany({
      where: { schoolId: user.schoolId },
      include: INCLUDE,
      orderBy: { createdAt: 'desc' },
    });
  }

  async create(dto: CreateHomeworkDto, user: AuthUser) {
    const group = await this.prisma.group.findFirst({
      where: { id: dto.groupId, schoolId: user.schoolId }, select: { id: true, teacherId: true },
    });
    if (!group) throw new NotFoundException('Группа не найдена');

    if (user.role === UserRole.TEACHER) {
      const teacher = await this.prisma.teacher.findUnique({
        where: { userId: user.userId }, select: { id: true },
      });
      if (teacher?.id !== group.teacherId) {
        throw new ForbiddenException('Можно задавать домашние задания только своим группам');
      }
    }

    return this.prisma.homework.create({
      data: {
        schoolId: user.schoolId,
        groupId: dto.groupId,
        lessonId: dto.lessonId,
        authorId: user.userId,
        title: dto.title,
        description: dto.description,
        dueDate: dto.dueDate ? new Date(dto.dueDate) : undefined,
        attachmentUrl: dto.attachmentUrl,
      },
      include: INCLUDE,
    });
  }

  async update(id: string, dto: UpdateHomeworkDto, user: AuthUser) {
    const hw = await this.prisma.homework.findFirst({
      where: { id, schoolId: user.schoolId }, select: { id: true, authorId: true },
    });
    if (!hw) throw new NotFoundException('Домашнее задание не найдено');
    if (hw.authorId !== user.userId && user.role !== UserRole.OWNER && user.role !== UserRole.ADMIN) {
      throw new ForbiddenException('Можно редактировать только свои задания');
    }
    return this.prisma.homework.update({
      where: { id },
      data: { ...dto, dueDate: dto.dueDate ? new Date(dto.dueDate) : undefined },
      include: INCLUDE,
    });
  }

  async remove(id: string, user: AuthUser) {
    const hw = await this.prisma.homework.findFirst({
      where: { id, schoolId: user.schoolId }, select: { id: true, authorId: true },
    });
    if (!hw) throw new NotFoundException('Домашнее задание не найдено');
    if (hw.authorId !== user.userId && user.role !== UserRole.OWNER && user.role !== UserRole.ADMIN) {
      throw new ForbiddenException('Можно удалять только свои задания');
    }
    return this.prisma.homework.delete({ where: { id } });
  }

  // ── приватные проверки ───────────────────────────────────────────────────
  private async getParentGroupIds(user: AuthUser): Promise<string[]> {
    const parent = await this.prisma.parent.findUnique({
      where: { userId: user.userId }, select: { familyId: true },
    });
    if (!parent) return [];
    const enrollments = await this.prisma.enrollment.findMany({
      where: { student: { familyId: parent.familyId }, status: 'ACTIVE' },
      select: { groupId: true },
    });
    return [...new Set(enrollments.map((e) => e.groupId))];
  }

  private async assertParentHasChildInGroup(groupId: string, user: AuthUser) {
    const groupIds = await this.getParentGroupIds(user);
    if (!groupIds.includes(groupId)) {
      throw new ForbiddenException('Нет доступа к домашним заданиям этой группы');
    }
  }
}
