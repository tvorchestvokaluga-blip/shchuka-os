﻿// DTO Р·Р°С‡РёСЃР»РµРЅРёР№, СЃ РІР°Р»РёРґР°С†РёРµР№.
import { IsDateString, IsIn, IsNumber, IsOptional, IsString } from 'class-validator';
import { EnrollmentStatus } from '@prisma/client';

export class CreateEnrollmentDto {
  @IsString()
  studentId: string;

  @IsString()
  programId: string;

  @IsString()
  groupId: string;

  @IsOptional()
  @IsDateString()
  startDate?: string;

  @IsOptional()
  @IsNumber()
  priceFrozen?: number;
}

export class UpdateEnrollmentDto {
  @IsOptional()
  @IsIn(['ACTIVE', 'PAUSED', 'FINISHED', 'CANCELLED'])
  status?: EnrollmentStatus;

  @IsOptional()
  @IsString()
  groupId?: string;

  @IsOptional()
  @IsDateString()
  endDate?: string;

  @IsOptional()
  @IsNumber()
  priceFrozen?: number;
}
