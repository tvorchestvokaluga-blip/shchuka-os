﻿// EnrollmentsService вЂ” Р±РёР·РЅРµСЃ-Р»РѕРіРёРєР° Р·Р°С‡РёСЃР»РµРЅРёР№.
// Р’РёРґРёРјРѕСЃС‚СЊ РїРѕ СЂРѕР»СЏРј Р°РЅР°Р»РѕРіРёС‡РЅР° StudentsService:
//   OWNER/ADMIN вЂ” РІСЃРµ Р·Р°С‡РёСЃР»РµРЅРёСЏ С€РєРѕР»С‹.
//   TEACHER     вЂ” С‚РѕР»СЊРєРѕ Р·Р°С‡РёСЃР»РµРЅРёСЏ РІ РµРіРѕ РіСЂСѓРїРїС‹.
//   PARENT      вЂ” С‚РѕР»СЊРєРѕ Р·Р°С‡РёСЃР»РµРЅРёСЏ РґРµС‚РµР№ РµРіРѕ СЃРµРјСЊРё.
import { Injectable, NotFoundException, BadRequestException } from '@nestjs/common';
import { UserRole, Prisma, EnrollmentStatus } from '@prisma/client';
import { PrismaService } from '../prisma/prisma.service';
import { AuthUser } from '../common/decorators/current-user.decorator';
import { CreateEnrollmentDto, UpdateEnrollmentDto } from './dto/enrollment.dto';

@Injectable()
export class EnrollmentsService {
  constructor(private prisma: PrismaService) {}

  private async visibilityFilter(user: AuthUser): Promise<Prisma.EnrollmentWhereInput> {
    const inSchool: Prisma.EnrollmentWhereInput = { schoolId: user.schoolId };

    if (user.role === UserRole.OWNER || user.role === UserRole.ADMIN) {
      return inSchool;
    }

    if (user.role === UserRole.PARENT) {
      const parent = await this.prisma.parent.findUnique({
        where: { userId: user.userId },
        select: { familyId: true },
      });
      return { ...inSchool, student: { familyId: parent?.familyId ?? '__none__' } };
    }

    if (user.role === UserRole.TEACHER) {
      const teacher = await this.prisma.teacher.findUnique({
        where: { userId: user.userId },
        select: { id: true },
      });
      return { ...inSchool, group: { teacherId: teacher?.id ?? '__none__' } };
    }

    // РїСЂРѕС‡РёРµ СЂРѕР»Рё Р·Р°С‡РёСЃР»РµРЅРёР№ РЅРµ РІРёРґСЏС‚
    return { ...inSchool, id: '__none__' };
  }

  async findAll(user: AuthUser) {
    const where = await this.visibilityFilter(user);
    return this.prisma.enrollment.findMany({
      where,
      include: {
        student: { select: { id: true, firstName: true, lastName: true } },
        program: { select: { id: true, name: true } },
        group: { select: { id: true, name: true } },
      },
      orderBy: { startDate: 'desc' },
    });
  }

  async findOne(id: string, user: AuthUser) {
    const where = await this.visibilityFilter(user);
    const enrollment = await this.prisma.enrollment.findFirst({
      where: { ...where, id },
      include: {
        student: true,
        program: true,
        group: true,
        subscriptions: true,
      },
    });
    if (!enrollment) throw new NotFoundException('Р—Р°С‡РёСЃР»РµРЅРёРµ РЅРµ РЅР°Р№РґРµРЅРѕ');
    return enrollment;
  }

  async create(dto: CreateEnrollmentDto, user: AuthUser) {
    const [student, program, group] = await Promise.all([
      this.prisma.student.findFirst({
        where: { id: dto.studentId, schoolId: user.schoolId, deletedAt: null },
      }),
      this.prisma.program.findFirst({ where: { id: dto.programId, schoolId: user.schoolId } }),
      this.prisma.group.findFirst({ where: { id: dto.groupId, schoolId: user.schoolId } }),
    ]);
    if (!student) throw new BadRequestException('РЈС‡РµРЅРёРє РЅРµ РЅР°Р№РґРµРЅ РІ РІР°С€РµР№ С€РєРѕР»Рµ');
    if (!program) throw new BadRequestException('РџСЂРѕРіСЂР°РјРјР° РЅРµ РЅР°Р№РґРµРЅР° РІ РІР°С€РµР№ С€РєРѕР»Рµ');
    if (!group) throw new BadRequestException('Р“СЂСѓРїРїР° РЅРµ РЅР°Р№РґРµРЅР° РІ РІР°С€РµР№ С€РєРѕР»Рµ');

    return this.prisma.enrollment.create({
      data: {
        schoolId: user.schoolId,
        studentId: dto.studentId,
        programId: dto.programId,
        groupId: dto.groupId,
        startDate: dto.startDate ? new Date(dto.startDate) : undefined,
        priceFrozen: dto.priceFrozen,
      },
    });
  }

  async update(id: string, dto: UpdateEnrollmentDto, user: AuthUser) {
    await this.ensureInSchool(id, user.schoolId);
    const data: Prisma.EnrollmentUpdateInput = { ...dto };
    if (dto.endDate) data.endDate = new Date(dto.endDate);
    return this.prisma.enrollment.update({ where: { id }, data });
  }

  /** РњСЏРіРєР°СЏ РѕС‚РјРµРЅР° вЂ” Р·Р°С‡РёСЃР»РµРЅРёРµ РїРѕРјРµС‡Р°РµС‚СЃСЏ CANCELLED, РёСЃС‚РѕСЂРёСЏ РЅРµ С‚РµСЂСЏРµС‚СЃСЏ. */
  async remove(id: string, user: AuthUser) {
    await this.ensureInSchool(id, user.schoolId);
    return this.prisma.enrollment.update({
      where: { id },
      data: { status: EnrollmentStatus.CANCELLED, endDate: new Date() },
    });
  }

  private async ensureInSchool(id: string, schoolId: string) {
    const e = await this.prisma.enrollment.findFirst({ where: { id, schoolId }, select: { id: true } });
    if (!e) throw new NotFoundException('Р—Р°С‡РёСЃР»РµРЅРёРµ РЅРµ РЅР°Р№РґРµРЅРѕ');
  }
}
