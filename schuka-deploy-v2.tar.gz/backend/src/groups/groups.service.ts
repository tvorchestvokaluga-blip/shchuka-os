// GroupsService — группы, расписание, привязка педагога.
// Бизнес-правила, живущие здесь (а не в интерфейсе):
//   • лимит группы (maxSize, по умолчанию 8) проверяется при зачислении;
//   • педагог и программа должны принадлежать той же школе;
//   • педагог видит только свои группы, родитель — группы своих детей.
import { Injectable, NotFoundException, BadRequestException } from '@nestjs/common';
import { UserRole, Prisma, Weekday } from '@prisma/client';
import { PrismaService } from '../prisma/prisma.service';
import { AuthUser } from '../common/decorators/current-user.decorator';
import { CreateGroupDto, UpdateGroupDto } from './dto/group.dto';

@Injectable()
export class GroupsService {
  constructor(private prisma: PrismaService) {}

  async findAll(user: AuthUser) {
    const where = await this.visibilityFilter(user);
    return this.prisma.group.findMany({
      where,
      include: {
        program: { select: { id: true, name: true } },
        teacher: { include: { user: { select: { fullName: true } } } },
        scheduleSlots: true,
        _count: { select: { enrollments: true } },
      },
      orderBy: { name: 'asc' },
    });
  }

  async findOne(id: string, user: AuthUser) {
    const where = await this.visibilityFilter(user);
    const group = await this.prisma.group.findFirst({
      where: { AND: [{ id }, where] },
      include: {
        program: true,
        teacher: { include: { user: { select: { fullName: true } } } },
        scheduleSlots: true,
        enrollments: {
          where: { status: 'ACTIVE' },
          include: {
            student: {
              select: { id: true, firstName: true, lastName: true, birthDate: true, avatarEmoji: true },
            },
          },
          orderBy: { student: { lastName: 'asc' } },
        },
      },
    });
    if (!group) throw new NotFoundException('Группа не найдена или нет доступа');
    return group;
  }

  /** Создать группу. Программа и педагог проверяются на принадлежность школе. */
  async create(dto: CreateGroupDto, user: AuthUser) {
    await this.assertProgramInSchool(dto.programId, user.schoolId);
    if (dto.teacherId) await this.assertTeacherInSchool(dto.teacherId, user.schoolId);

    return this.prisma.group.create({
      data: {
        schoolId: user.schoolId,
        programId: dto.programId,
        teacherId: dto.teacherId,
        name: dto.name,
        maxSize: dto.maxSize ?? 8,
        scheduleSlots: dto.scheduleSlots
          ? { create: dto.scheduleSlots.map((s) => ({
              weekday: s.weekday as Weekday,
              startTime: s.startTime,
              endTime: s.endTime,
              room: s.room,
            })) }
          : undefined,
      },
      include: { scheduleSlots: true },
    });
  }

  async update(id: string, dto: UpdateGroupDto, user: AuthUser) {
    await this.ensureInSchool(id, user.schoolId);
    if (dto.teacherId) await this.assertTeacherInSchool(dto.teacherId, user.schoolId);
    return this.prisma.group.update({ where: { id }, data: dto });
  }

  /**
   * Проверка возможности добавить ещё одного ребёнка в группу.
   * Вызывается модулем Enrollments перед зачислением — здесь живёт правило лимита.
   */
  async assertHasFreeSeat(groupId: string, schoolId: string) {
    const group = await this.prisma.group.findFirst({
      where: { id: groupId, schoolId },
      select: { maxSize: true, _count: { select: { enrollments: { where: { status: 'ACTIVE' } } } } },
    });
    if (!group) throw new NotFoundException('Группа не найдена');
    if (group._count.enrollments >= group.maxSize) {
      throw new BadRequestException(`В группе нет свободных мест (лимит ${group.maxSize})`);
    }
  }

  // ── видимость и проверки ──────────────────────────────────────────────────
  private async visibilityFilter(user: AuthUser): Promise<Prisma.GroupWhereInput> {
    const inSchool: Prisma.GroupWhereInput = { schoolId: user.schoolId };

    if (user.role === UserRole.TEACHER) {
      const teacher = await this.prisma.teacher.findUnique({
        where: { userId: user.userId }, select: { id: true },
      });
      return { ...inSchool, teacherId: teacher?.id ?? '__none__' };
    }
    if (user.role === UserRole.PARENT) {
      const parent = await this.prisma.parent.findUnique({
        where: { userId: user.userId }, select: { familyId: true },
      });
      return {
        ...inSchool,
        enrollments: { some: { student: { familyId: parent?.familyId ?? '__none__' } } },
      };
    }
    return inSchool; // OWNER/ADMIN — все группы школы
  }

  private async ensureInSchool(id: string, schoolId: string) {
    const g = await this.prisma.group.findFirst({ where: { id, schoolId }, select: { id: true } });
    if (!g) throw new NotFoundException('Группа не найдена');
  }
  private async assertProgramInSchool(programId: string, schoolId: string) {
    const p = await this.prisma.program.findFirst({ where: { id: programId, schoolId }, select: { id: true } });
    if (!p) throw new BadRequestException('Программа не найдена в вашей школе');
  }
  private async assertTeacherInSchool(teacherId: string, schoolId: string) {
    const t = await this.prisma.teacher.findFirst({ where: { id: teacherId, schoolId }, select: { id: true } });
    if (!t) throw new BadRequestException('Педагог не найден в вашей школе');
  }
}
