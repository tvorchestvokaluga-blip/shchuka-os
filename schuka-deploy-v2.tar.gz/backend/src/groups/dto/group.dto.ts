// Данные запросов для групп и слотов расписания, с валидацией.
import {
  IsArray, IsBoolean, IsIn, IsInt, IsOptional, IsString, Matches, Max, Min, MinLength, ValidateNested,
} from 'class-validator';
import { Type } from 'class-transformer';

const WEEKDAYS = ['MON', 'TUE', 'WED', 'THU', 'FRI', 'SAT', 'SUN'];

export class ScheduleSlotDto {
  @IsIn(WEEKDAYS, { message: 'День недели: MON..SUN' })
  weekday: string;

  @Matches(/^([01]\d|2[0-3]):[0-5]\d$/, { message: 'Время в формате ЧЧ:ММ' })
  startTime: string;

  @Matches(/^([01]\d|2[0-3]):[0-5]\d$/, { message: 'Время в формате ЧЧ:ММ' })
  endTime: string;

  @IsOptional()
  @IsString()
  room?: string;
}

export class CreateGroupDto {
  @IsString()
  programId: string;

  @IsOptional()
  @IsString()
  teacherId?: string;

  @IsString()
  @MinLength(1)
  name: string;

  @IsOptional()
  @IsInt()
  @Min(1)
  @Max(20)
  maxSize?: number; // по умолчанию 8 (правило школы)

  @IsOptional()
  @IsArray()
  @ValidateNested({ each: true })
  @Type(() => ScheduleSlotDto)
  scheduleSlots?: ScheduleSlotDto[];
}

export class UpdateGroupDto {
  @IsOptional() @IsString() @MinLength(1) name?: string;
  @IsOptional() @IsString() teacherId?: string;
  @IsOptional() @IsInt() @Min(1) @Max(20) maxSize?: number;
  @IsOptional() @IsBoolean() isActive?: boolean;
}
