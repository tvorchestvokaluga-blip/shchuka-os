// DevelopmentPlansController — /api/students/:studentId/development-plans
import { Body, Controller, Delete, Get, Param, Patch, Post } from '@nestjs/common';
import { DevelopmentPlansService } from './development-plans.service';
import { CreateDevelopmentPlanDto, UpdateDevelopmentPlanDto } from './dto/development-plan.dto';
import { CurrentUser, AuthUser } from '../common/decorators/current-user.decorator';

@Controller('students/:studentId/development-plans')
export class DevelopmentPlansController {
  constructor(private readonly plans: DevelopmentPlansService) {}

  @Get()
  findByStudent(@Param('studentId') studentId: string, @CurrentUser() user: AuthUser) {
    return this.plans.findByStudent(studentId, user);
  }

  @Post()
  create(@Param('studentId') studentId: string, @Body() dto: CreateDevelopmentPlanDto, @CurrentUser() user: AuthUser) {
    return this.plans.create(studentId, dto, user);
  }

  @Patch(':id')
  update(@Param('id') id: string, @Body() dto: UpdateDevelopmentPlanDto, @CurrentUser() user: AuthUser) {
    return this.plans.update(id, dto, user);
  }

  @Delete(':id')
  remove(@Param('id') id: string, @CurrentUser() user: AuthUser) {
    return this.plans.remove(id, user);
  }
}
