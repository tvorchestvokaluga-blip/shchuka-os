// Данные запросов для индивидуальных планов развития ребёнка.
import { IsOptional, IsString, MinLength } from 'class-validator';

export class CreateDevelopmentPlanDto {
  @IsString()
  @MinLength(1)
  goals: string;

  @IsOptional()
  @IsString()
  periodLabel?: string;

  @IsOptional()
  @IsString()
  focusAreas?: string;

  @IsOptional()
  @IsString()
  notes?: string;
}

export class UpdateDevelopmentPlanDto {
  @IsOptional() @IsString() @MinLength(1) goals?: string;
  @IsOptional() @IsString() periodLabel?: string;
  @IsOptional() @IsString() focusAreas?: string;
  @IsOptional() @IsString() notes?: string;
}
