// DevelopmentPlansService — индивидуальный план развития ребёнка.
// Записи копятся со временем (цели меняются от периода к периоду);
// последняя запись — «текущий план», вся история видна тем, у кого есть доступ.
import { Injectable, NotFoundException, ForbiddenException } from '@nestjs/common';
import { UserRole } from '@prisma/client';
import { PrismaService } from '../prisma/prisma.service';
import { AuthUser } from '../common/decorators/current-user.decorator';
import { CreateDevelopmentPlanDto, UpdateDevelopmentPlanDto } from './dto/development-plan.dto';

@Injectable()
export class DevelopmentPlansService {
  constructor(private prisma: PrismaService) {}

  async findByStudent(studentId: string, user: AuthUser) {
    await this.assertCanView(studentId, user);
    return this.prisma.developmentPlan.findMany({
      where: { studentId, schoolId: user.schoolId },
      include: { author: { select: { fullName: true } } },
      orderBy: { createdAt: 'desc' },
    });
  }

  async create(studentId: string, dto: CreateDevelopmentPlanDto, user: AuthUser) {
    await this.assertCanEdit(studentId, user);
    return this.prisma.developmentPlan.create({
      data: {
        schoolId: user.schoolId,
        studentId,
        authorId: user.userId,
        goals: dto.goals,
        periodLabel: dto.periodLabel,
        focusAreas: dto.focusAreas,
        notes: dto.notes,
      },
      include: { author: { select: { fullName: true } } },
    });
  }

  async update(id: string, dto: UpdateDevelopmentPlanDto, user: AuthUser) {
    const plan = await this.prisma.developmentPlan.findFirst({ where: { id, schoolId: user.schoolId } });
    if (!plan) throw new NotFoundException('План не найден');
    await this.assertCanEdit(plan.studentId, user);
    return this.prisma.developmentPlan.update({
      where: { id },
      data: { ...dto },
      include: { author: { select: { fullName: true } } },
    });
  }

  async remove(id: string, user: AuthUser) {
    const plan = await this.prisma.developmentPlan.findFirst({ where: { id, schoolId: user.schoolId } });
    if (!plan) throw new NotFoundException('План не найден');
    await this.assertCanEdit(plan.studentId, user);
    return this.prisma.developmentPlan.delete({ where: { id } });
  }

  // ── доступ на просмотр: родитель — только своему ребёнку; педагог — только ученикам своих групп ──
  private async assertCanView(studentId: string, user: AuthUser) {
    if (user.role === UserRole.OWNER || user.role === UserRole.ADMIN) return;

    if (user.role === UserRole.PARENT) {
      const parent = await this.prisma.parent.findUnique({ where: { userId: user.userId }, select: { familyId: true } });
      const student = await this.prisma.student.findFirst({
        where: { id: studentId, familyId: parent?.familyId ?? '__none__' }, select: { id: true },
      });
      if (!student) throw new ForbiddenException('Нет доступа к плану развития этого ребёнка');
      return;
    }

    if (user.role === UserRole.TEACHER) {
      const teacher = await this.prisma.teacher.findUnique({ where: { userId: user.userId }, select: { id: true } });
      const enrollment = await this.prisma.enrollment.findFirst({
        where: { studentId, group: { teacherId: teacher?.id ?? '__none__' } }, select: { id: true },
      });
      if (!enrollment) throw new ForbiddenException('Нет доступа к плану развития этого ребёнка');
      return;
    }

    throw new ForbiddenException('Нет доступа');
  }

  // ── доступ на запись: родитель никогда не пишет, педагог — только своим ученикам ──
  private async assertCanEdit(studentId: string, user: AuthUser) {
    if (user.role === UserRole.OWNER || user.role === UserRole.ADMIN) return;

    if (user.role === UserRole.TEACHER) {
      const teacher = await this.prisma.teacher.findUnique({ where: { userId: user.userId }, select: { id: true } });
      const enrollment = await this.prisma.enrollment.findFirst({
        where: { studentId, group: { teacherId: teacher?.id ?? '__none__' } }, select: { id: true },
      });
      if (!enrollment) throw new ForbiddenException('Нет доступа к плану развития этого ребёнка');
      return;
    }

    throw new ForbiddenException('Только педагог, руководитель или администратор могут вести план развития');
  }
}
