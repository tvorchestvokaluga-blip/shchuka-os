// Данные запросов для задач руководителя.
import { IsDateString, IsEnum, IsOptional, IsString, MinLength } from 'class-validator';
import { TaskStatus } from '@prisma/client';

export class CreateTaskDto {
  @IsString()
  @MinLength(1)
  title: string;

  @IsOptional()
  @IsString()
  note?: string;

  @IsOptional()
  @IsDateString()
  dueDate?: string;
}

export class UpdateTaskDto {
  @IsOptional() @IsString() @MinLength(1) title?: string;
  @IsOptional() @IsString() note?: string;
  @IsOptional() @IsDateString() dueDate?: string;
  @IsOptional() @IsEnum(TaskStatus, { message: 'Статус: TODO | DONE' }) status?: TaskStatus;
}
