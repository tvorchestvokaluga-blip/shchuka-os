// TasksService — рабочий список дел руководителя/администратора школы.
// Простой личный чек-лист на уровне школы: не привязан к урокам/группам —
// для организационных задач ("оплатить аренду", "заказать краски" и т.п.).
import { Injectable, NotFoundException } from '@nestjs/common';
import { TaskStatus } from '@prisma/client';
import { PrismaService } from '../prisma/prisma.service';
import { AuthUser } from '../common/decorators/current-user.decorator';
import { CreateTaskDto, UpdateTaskDto } from './dto/task.dto';

@Injectable()
export class TasksService {
  constructor(private prisma: PrismaService) {}

  /** Незавершённые задачи — сверху, по сроку; завершённые — снизу, недавние сначала. */
  async findAll(user: AuthUser) {
    const [open, done] = await Promise.all([
      this.prisma.task.findMany({
        where: { schoolId: user.schoolId, status: TaskStatus.TODO },
        orderBy: [{ dueDate: 'asc' }, { createdAt: 'asc' }],
      }),
      this.prisma.task.findMany({
        where: { schoolId: user.schoolId, status: TaskStatus.DONE },
        orderBy: { completedAt: 'desc' },
        take: 30,
      }),
    ]);
    return { open, done };
  }

  async create(dto: CreateTaskDto, user: AuthUser) {
    return this.prisma.task.create({
      data: {
        schoolId: user.schoolId,
        title: dto.title,
        note: dto.note,
        dueDate: dto.dueDate ? new Date(dto.dueDate) : undefined,
        createdById: user.userId,
      },
    });
  }

  async update(id: string, dto: UpdateTaskDto, user: AuthUser) {
    const task = await this.ensureInSchool(id, user.schoolId);
    const data: any = { ...dto };
    if (dto.dueDate) data.dueDate = new Date(dto.dueDate);

    // при переходе в DONE — фиксируем момент; при возврате в TODO — снимаем
    if (dto.status === TaskStatus.DONE && task.status !== TaskStatus.DONE) {
      data.completedAt = new Date();
    } else if (dto.status === TaskStatus.TODO && task.status !== TaskStatus.TODO) {
      data.completedAt = null;
    }

    return this.prisma.task.update({ where: { id }, data });
  }

  async remove(id: string, user: AuthUser) {
    await this.ensureInSchool(id, user.schoolId);
    return this.prisma.task.delete({ where: { id } });
  }

  private async ensureInSchool(id: string, schoolId: string) {
    const t = await this.prisma.task.findFirst({ where: { id, schoolId } });
    if (!t) throw new NotFoundException('Задача не найдена');
    return t;
  }
}
