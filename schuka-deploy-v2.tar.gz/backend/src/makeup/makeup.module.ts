import { Module } from '@nestjs/common';
import { MakeupService } from './makeup.service';
import { MakeupController, MakeupBookingsController } from './makeup.controller';

@Module({
  controllers: [MakeupController, MakeupBookingsController],
  providers: [MakeupService],
  exports: [MakeupService],
})
export class MakeupModule {}
