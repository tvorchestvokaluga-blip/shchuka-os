// Данные запросов для отработок пропущенных занятий.
import { IsDateString, IsInt, IsOptional, IsString, Min } from 'class-validator';

export class CreateMakeupSlotDto {
  @IsDateString()
  date: string;

  @IsOptional()
  @IsInt()
  @Min(1)
  capacity?: number;

  @IsOptional()
  @IsString()
  note?: string;
}

export class BookMakeupDto {
  @IsString()
  studentId: string;
}
