// MakeupController — /api/makeup/*
// Отработки пропущенных занятий: общие слоты на школу, запись по предзаписи.
import { Body, Controller, Delete, Get, Param, Post } from '@nestjs/common';
import { UserRole } from '@prisma/client';
import { MakeupService } from './makeup.service';
import { CreateMakeupSlotDto, BookMakeupDto } from './dto/makeup.dto';
import { Roles } from '../common/decorators/roles.decorator';
import { CurrentUser, AuthUser } from '../common/decorators/current-user.decorator';

@Controller('makeup/slots')
export class MakeupController {
  constructor(private readonly makeup: MakeupService) {}

  @Get()
  findUpcoming(@CurrentUser() user: AuthUser) {
    return this.makeup.findUpcoming(user);
  }

  @Post()
  @Roles(UserRole.OWNER, UserRole.ADMIN)
  create(@Body() dto: CreateMakeupSlotDto, @CurrentUser() user: AuthUser) {
    return this.makeup.createSlot(dto, user);
  }

  @Delete(':id')
  @Roles(UserRole.OWNER, UserRole.ADMIN)
  remove(@Param('id') id: string, @CurrentUser() user: AuthUser) {
    return this.makeup.removeSlot(id, user);
  }

  @Post(':id/book')
  @Roles(UserRole.PARENT)
  book(@Param('id') id: string, @Body() dto: BookMakeupDto, @CurrentUser() user: AuthUser) {
    return this.makeup.book(id, dto, user);
  }
}

@Controller('makeup/bookings')
export class MakeupBookingsController {
  constructor(private readonly makeup: MakeupService) {}

  @Delete(':id')
  remove(@Param('id') id: string, @CurrentUser() user: AuthUser) {
    return this.makeup.cancelBooking(id, user);
  }
}
