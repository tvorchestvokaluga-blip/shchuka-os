// MakeupService — отработки пропущенных занятий.
// Общие слоты на всю школу (по умолчанию 2 раза в месяц, 8 мест), по предзаписи.
// Родитель просто бронирует место — какие темы пропущены, система считает сама
// по посещаемости (Attendance.status = ABSENT), без ручного ввода.
import { Injectable, NotFoundException, ForbiddenException, BadRequestException } from '@nestjs/common';
import { UserRole } from '@prisma/client';
import { PrismaService } from '../prisma/prisma.service';
import { AuthUser } from '../common/decorators/current-user.decorator';
import { CreateMakeupSlotDto, BookMakeupDto } from './dto/makeup.dto';

type MissedTopic = { date: Date; topic: string | null; groupName: string };
type RosterEntry = { bookingId: string; studentId: string; studentName: string; missedTopics: MissedTopic[] };
type SlotRoster = { id: string; date: Date; capacity: number; note: string | null; remaining: number; roster: RosterEntry[] };

@Injectable()
export class MakeupService {
  constructor(private prisma: PrismaService) {}

  /** Список ближайших слотов. Форма ответа зависит от роли. */
  async findUpcoming(user: AuthUser) {
    const slots = await this.prisma.makeupSlot.findMany({
      where: { schoolId: user.schoolId, date: { gte: startOfToday() } },
      orderBy: { date: 'asc' },
      include: {
        bookings: {
          include: {
            student: { select: { id: true, firstName: true, lastName: true, familyId: true } },
          },
        },
      },
    });

    if (user.role === UserRole.PARENT) {
      const parent = await this.prisma.parent.findUnique({
        where: { userId: user.userId }, select: { familyId: true },
      });
      const myFamilyId = parent?.familyId ?? '__none__';
      return slots.map((s) => ({
        id: s.id,
        date: s.date,
        capacity: s.capacity,
        note: s.note,
        remaining: Math.max(s.capacity - s.bookings.length, 0),
        myBookings: s.bookings
          .filter((b) => b.student.familyId === myFamilyId)
          .map((b) => ({ id: b.id, studentId: b.studentId, studentName: `${b.student.firstName} ${b.student.lastName}` })),
      }));
    }

    // OWNER / ADMIN / TEACHER — полный список записавшихся + их пропущенные темы
    const result: SlotRoster[] = [];
    for (const s of slots) {
      const roster: RosterEntry[] = [];
      for (const b of s.bookings) {
        const missedTopics = await this.getMissedTopics(b.studentId, user.schoolId);
        roster.push({
          bookingId: b.id,
          studentId: b.studentId,
          studentName: `${b.student.firstName} ${b.student.lastName}`,
          missedTopics,
        });
      }
      result.push({
        id: s.id,
        date: s.date,
        capacity: s.capacity,
        note: s.note,
        remaining: Math.max(s.capacity - s.bookings.length, 0),
        roster,
      });
    }
    return result;
  }

  /** Темы пропущенных занятий ребёнка (по последним отметкам ABSENT). */
  private async getMissedTopics(studentId: string, schoolId: string) {
    const missed = await this.prisma.attendance.findMany({
      where: {
        status: 'ABSENT',
        enrollment: { studentId, schoolId },
      },
      include: {
        lesson: { select: { date: true, topic: true, group: { select: { name: true } } } },
      },
      orderBy: { lesson: { date: 'desc' } },
      take: 10,
    });
    return missed.map((m) => ({
      date: m.lesson.date,
      topic: m.lesson.topic ?? null,
      groupName: m.lesson.group.name,
    }));
  }

  async createSlot(dto: CreateMakeupSlotDto, user: AuthUser) {
    return this.prisma.makeupSlot.create({
      data: {
        schoolId: user.schoolId,
        date: new Date(dto.date),
        capacity: dto.capacity ?? 8,
        note: dto.note,
      },
    });
  }

  async removeSlot(id: string, user: AuthUser) {
    const slot = await this.prisma.makeupSlot.findFirst({ where: { id, schoolId: user.schoolId } });
    if (!slot) throw new NotFoundException('Слот отработки не найден');
    return this.prisma.makeupSlot.delete({ where: { id } });
  }

  /** Родитель бронирует место для своего ребёнка. */
  async book(slotId: string, dto: BookMakeupDto, user: AuthUser) {
    const slot = await this.prisma.makeupSlot.findFirst({
      where: { id: slotId, schoolId: user.schoolId },
      include: { bookings: true },
    });
    if (!slot) throw new NotFoundException('Слот отработки не найден');

    const parent = await this.prisma.parent.findUnique({
      where: { userId: user.userId }, select: { familyId: true },
    });
    const student = await this.prisma.student.findFirst({
      where: { id: dto.studentId, schoolId: user.schoolId },
      select: { id: true, familyId: true },
    });
    if (!student || student.familyId !== parent?.familyId) {
      throw new ForbiddenException('Можно записывать только своих детей');
    }

    if (slot.bookings.length >= slot.capacity) {
      throw new BadRequestException('Свободных мест на этот слот больше нет');
    }
    if (slot.bookings.some((b) => b.studentId === dto.studentId)) {
      throw new BadRequestException('Этот ребёнок уже записан на данный слот');
    }

    return this.prisma.makeupBooking.create({
      data: { slotId, studentId: dto.studentId },
    });
  }

  /** Отмена записи: родитель — только своего ребёнка, сотрудники — любую. */
  async cancelBooking(bookingId: string, user: AuthUser) {
    const booking = await this.prisma.makeupBooking.findFirst({
      where: { id: bookingId },
      include: { student: true, slot: true },
    });
    if (!booking || booking.slot.schoolId !== user.schoolId) {
      throw new NotFoundException('Запись не найдена');
    }

    if (user.role === UserRole.PARENT) {
      const parent = await this.prisma.parent.findUnique({
        where: { userId: user.userId }, select: { familyId: true },
      });
      if (booking.student.familyId !== parent?.familyId) {
        throw new ForbiddenException('Можно отменять запись только своего ребёнка');
      }
    }

    return this.prisma.makeupBooking.delete({ where: { id: bookingId } });
  }
}

function startOfToday(): Date {
  const d = new Date();
  d.setHours(0, 0, 0, 0);
  return d;
}
