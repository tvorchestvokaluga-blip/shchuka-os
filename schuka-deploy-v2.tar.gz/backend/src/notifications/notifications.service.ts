// NotificationsService — внутрисистемные уведомления (колокольчик в шапке).
// Пока только канал INAPP (без email/Telegram-рассылки) — сообщение появляется
// у пользователя в кабинете. Этот сервис также используют другие модули
// (оплаты, дни рождения), чтобы создавать уведомления по своим событиям.
import { Injectable, NotFoundException } from '@nestjs/common';
import { NotificationChannel, NotificationType, UserRole } from '@prisma/client';
import { PrismaService } from '../prisma/prisma.service';
import { AuthUser } from '../common/decorators/current-user.decorator';

@Injectable()
export class NotificationsService {
  constructor(private prisma: PrismaService) {}

  // schoolId -> дата (yyyy-mm-dd) последней проверки дней рождения.
  // In-memory троттлинг: сервер один процесс на школу, поэтому достаточно.
  private lastBirthdayCheck = new Map<string, string>();

  async findMine(user: AuthUser) {
    await this.checkBirthdaysAndNotify(user.schoolId).catch(() => {});
    return this.prisma.notification.findMany({
      where: { userId: user.userId },
      orderBy: { createdAt: 'desc' },
      take: 50,
    });
  }

  async countUnread(user: AuthUser) {
    return this.prisma.notification.count({ where: { userId: user.userId, isRead: false } });
  }

  async markRead(id: string, user: AuthUser) {
    const n = await this.prisma.notification.findFirst({ where: { id, userId: user.userId } });
    if (!n) throw new NotFoundException('Уведомление не найдено');
    return this.prisma.notification.update({ where: { id }, data: { isRead: true } });
  }

  async markAllRead(user: AuthUser) {
    await this.prisma.notification.updateMany({
      where: { userId: user.userId, isRead: false },
      data: { isRead: true },
    });
    return { ok: true };
  }

  /** Внутренний хелпер для других модулей (оплаты и т.п.) — создать одно уведомление. */
  async create(data: { schoolId: string; userId: string; type: NotificationType; title: string; body?: string }) {
    return this.prisma.notification.create({
      data: { ...data, channel: NotificationChannel.INAPP },
    });
  }

  /**
   * Дни рождения детей: проверяется не чаще раза в день (по факту первого
   * обращения за уведомлениями в этот день). Руководителю/администраторам —
   * напоминание, родителям — готовое поздравление от лица школы.
   */
  private async checkBirthdaysAndNotify(schoolId: string) {
    const todayKey = new Date().toISOString().slice(0, 10);
    if (this.lastBirthdayCheck.get(schoolId) === todayKey) return;
    this.lastBirthdayCheck.set(schoolId, todayKey);

    const today = new Date();
    const month = today.getMonth() + 1;
    const day = today.getDate();

    const students = await this.prisma.student.findMany({
      where: { schoolId, deletedAt: null },
      select: { id: true, firstName: true, lastName: true, birthDate: true, familyId: true },
    });
    const birthdayStudents = students.filter((s) => {
      if (!s.birthDate) return false;
      const bd = new Date(s.birthDate);
      return bd.getMonth() + 1 === month && bd.getDate() === day;
    });
    if (birthdayStudents.length === 0) return;

    const owners = await this.prisma.user.findMany({
      where: { schoolId, role: { in: [UserRole.OWNER, UserRole.ADMIN] }, isActive: true },
      select: { id: true },
    });
    const todayStart = new Date();
    todayStart.setHours(0, 0, 0, 0);

    for (const student of birthdayStudents) {
      const ownerTitle = `🎂 День рождения — ${student.firstName} ${student.lastName}`;

      // защита от дубля, если сервер перезапускался в течение того же дня
      const already = await this.prisma.notification.findFirst({
        where: { schoolId, type: NotificationType.BIRTHDAY, title: ownerTitle, createdAt: { gte: todayStart } },
        select: { id: true },
      });
      if (already) continue;

      for (const owner of owners) {
        await this.create({
          schoolId,
          userId: owner.id,
          type: NotificationType.BIRTHDAY,
          title: ownerTitle,
          body: `Сегодня день рождения у ${student.firstName} ${student.lastName}.`,
        });
      }

      const parents = await this.prisma.parent.findMany({
        where: { familyId: student.familyId },
        select: { userId: true },
      });
      for (const parent of parents) {
        await this.create({
          schoolId,
          userId: parent.userId,
          type: NotificationType.BIRTHDAY,
          title: `🎉 С днём рождения, ${student.firstName}!`,
          body: `Вся команда художественной школы «Щука» поздравляет ${student.firstName} с днём рождения! Желаем вдохновения и ярких работ 🎨`,
        });
      }
    }
  }
}
