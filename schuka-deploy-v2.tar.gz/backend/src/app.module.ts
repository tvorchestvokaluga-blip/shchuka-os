// AppModule — корень приложения. Все модули системы, глобальная защита по токену и ролям.
import { Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { ScheduleModule } from '@nestjs/schedule';
import { ThrottlerModule, ThrottlerGuard } from '@nestjs/throttler';
import { APP_GUARD } from '@nestjs/core';
import { PrismaModule } from './prisma/prisma.module';
import { AuthModule } from './auth/auth.module';
import { UsersModule } from './users/users.module';
import { FamiliesModule } from './families/families.module';
import { StudentsModule } from './students/students.module';
import { ProgramsModule } from './programs/programs.module';
import { GroupsModule } from './groups/groups.module';
import { EnrollmentsModule } from './enrollments/enrollments.module';
import { SubscriptionsModule } from './subscriptions/subscriptions.module';
import { PaymentsModule } from './payments/payments.module';
import { LessonsModule } from './lessons/lessons.module';
import { AttendanceModule } from './attendance/attendance.module';
import { PhotosModule } from './photos/photos.module';
import { CommentsModule } from './comments/comments.module';
import { PassportModule } from './passport/passport.module';
import { NewsModule } from './news/news.module';
import { HomeworkModule } from './homework/homework.module';
import { DocumentsModule } from './documents/documents.module';
import { MakeupModule } from './makeup/makeup.module';
import { NotificationsModule } from './notifications/notifications.module';
import { TasksModule } from './tasks/tasks.module';
import { InventoryModule } from './inventory/inventory.module';
import { ReportsModule } from './reports/reports.module';
import { DevelopmentPlansModule } from './development-plans/development-plans.module';
import { TelegramModule } from './telegram/telegram.module';
import { JwtAuthGuard } from './common/guards/jwt-auth.guard';
import { RolesGuard } from './common/guards/roles.guard';

@Module({
  imports: [
    ConfigModule.forRoot({ isGlobal: true }),
    ScheduleModule.forRoot(),
    // Общий лимит запросов — защита от перебора паролей и случайных перегрузок API.
    // Логин дополнительно ограничен жёстче прямо в auth.controller.ts.
    ThrottlerModule.forRoot([{ name: 'default', ttl: 60000, limit: 300 }]),
    PrismaModule,
    AuthModule,
    UsersModule,
    FamiliesModule,
    StudentsModule,
    ProgramsModule,
    GroupsModule,
    EnrollmentsModule,
    SubscriptionsModule,
    PaymentsModule,
    LessonsModule,
    AttendanceModule,
    PhotosModule,
    CommentsModule,
    PassportModule,
    NewsModule,
    HomeworkModule,
    DocumentsModule,
    MakeupModule,
    NotificationsModule,
    TasksModule,
    InventoryModule,
    ReportsModule,
    DevelopmentPlansModule,
    TelegramModule,
  ],
  providers: [
    { provide: APP_GUARD, useClass: ThrottlerGuard },
    { provide: APP_GUARD, useClass: JwtAuthGuard },
    { provide: APP_GUARD, useClass: RolesGuard },
  ],
})
export class AppModule {}
