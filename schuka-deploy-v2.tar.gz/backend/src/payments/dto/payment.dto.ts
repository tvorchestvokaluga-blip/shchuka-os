// Данные запросов для оплат, с валидацией.
import { IsEnum, IsOptional, IsString } from 'class-validator';
import { PaymentMethod } from '@prisma/client';

export class MarkPaidDto {
  @IsEnum(PaymentMethod, { message: 'Метод: CASH | CARD | TRANSFER | ONLINE' })
  method: PaymentMethod;

  @IsOptional()
  @IsString()
  providerRef?: string; // ссылка на транзакцию у платёжного провайдера
}
