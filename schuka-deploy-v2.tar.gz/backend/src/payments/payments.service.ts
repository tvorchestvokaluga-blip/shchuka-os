// PaymentsService — управление статусами оплат.
// Принципы:
//   • платежи не удаляются никогда (бухгалтерия, 152-ФЗ);
//   • отметить «оплачено» может только сотрудник — вручную или через провайдер;
//   • руководитель видит все оплаты школы, родитель — только свои.
import { Injectable, NotFoundException, BadRequestException } from '@nestjs/common';
import { UserRole, PaymentStatus, NotificationType } from '@prisma/client';
import { PrismaService } from '../prisma/prisma.service';
import { AuthUser } from '../common/decorators/current-user.decorator';
import { MarkPaidDto } from './dto/payment.dto';
import { NotificationsService } from '../notifications/notifications.service';

@Injectable()
export class PaymentsService {
  constructor(
    private prisma: PrismaService,
    private notifications: NotificationsService,
  ) {}

  /** Все оплаты школы (для дашборда руководителя) или только свои (для родителя). */
  async findAll(user: AuthUser) {
    await this.checkOverdueAndNotify(user.schoolId).catch(() => {});

    if (user.role === UserRole.PARENT) {
      const parent = await this.prisma.parent.findUnique({
        where: { userId: user.userId }, select: { familyId: true },
      });
      return this.prisma.payment.findMany({
        where: {
          schoolId: user.schoolId,
          subscription: { enrollment: { student: { familyId: parent?.familyId ?? '__none__' } } },
        },
        include: { subscription: { include: { enrollment: { include: { student: true } } } } },
        orderBy: { createdAt: 'desc' },
      });
    }

    return this.prisma.payment.findMany({
      where: { schoolId: user.schoolId },
      include: {
        subscription: {
          include: {
            enrollment: {
              include: {
                student: { select: { firstName: true, lastName: true } },
                group: { select: { name: true } },
              },
            },
          },
        },
      },
      orderBy: { createdAt: 'desc' },
    });
  }

  /** Просроченные оплаты — для плашки задолженностей у руководителя. */
  findOverdue(user: AuthUser) {
    return this.prisma.payment.findMany({
      where: {
        schoolId: user.schoolId,
        status: { in: [PaymentStatus.PENDING, PaymentStatus.OVERDUE] },
        dueDate: { lt: new Date() },
      },
      include: {
        subscription: {
          include: {
            enrollment: {
              include: {
                student: { select: { firstName: true, lastName: true } },
                group: { select: { name: true } },
              },
            },
          },
        },
      },
      orderBy: { dueDate: 'asc' },
    });
  }

  /** Отметить оплату как оплаченную — вручную (наличные, карта, перевод). */
  async markPaid(id: string, dto: MarkPaidDto, user: AuthUser) {
    const payment = await this.prisma.payment.findFirst({
      where: { id, schoolId: user.schoolId },
      select: { id: true, status: true },
    });
    if (!payment) throw new NotFoundException('Оплата не найдена');
    if (payment.status === PaymentStatus.PAID) {
      throw new BadRequestException('Оплата уже отмечена как оплаченная');
    }

    return this.prisma.payment.update({
      where: { id },
      data: {
        status: PaymentStatus.PAID,
        method: dto.method,
        providerRef: dto.providerRef,
        paidAt: new Date(),
      },
    });
  }

  /** Отметить как просроченную вручную (обычно это делает checkOverdueAndNotify сама). */
  async markOverdue(id: string, user: AuthUser) {
    const payment = await this.prisma.payment.findFirst({
      where: { id, schoolId: user.schoolId, status: PaymentStatus.PENDING },
      select: { id: true },
    });
    if (!payment) throw new NotFoundException('Ожидающая оплата не найдена');
    return this.prisma.payment.update({ where: { id }, data: { status: PaymentStatus.OVERDUE } });
  }

  /**
   * Автопроверка просрочки — запускается при каждом открытии списка оплат
   * (см. findAll). Находит PENDING-оплаты с истёкшим сроком, переводит их
   * в OVERDUE и один раз уведомляет родителя и руководителя/администраторов.
   * Идемпотентна: как только оплата станет OVERDUE, повторный запуск её
   * больше не тронет — двойных уведомлений не будет.
   */
  async checkOverdueAndNotify(schoolId: string) {
    const newlyOverdue = await this.prisma.payment.findMany({
      where: { schoolId, status: PaymentStatus.PENDING, dueDate: { lt: new Date() } },
      include: {
        subscription: {
          include: {
            enrollment: {
              include: {
                student: { select: { firstName: true, lastName: true, familyId: true } },
              },
            },
          },
        },
      },
    });
    if (newlyOverdue.length === 0) return;

    await this.prisma.payment.updateMany({
      where: { id: { in: newlyOverdue.map((p) => p.id) } },
      data: { status: PaymentStatus.OVERDUE },
    });

    const owners = await this.prisma.user.findMany({
      where: { schoolId, role: { in: [UserRole.OWNER, UserRole.ADMIN] }, isActive: true },
      select: { id: true },
    });

    for (const payment of newlyOverdue) {
      const student = payment.subscription.enrollment.student;
      const dueStr = payment.dueDate ? new Date(payment.dueDate).toLocaleDateString('ru-RU') : '';

      const parents = await this.prisma.parent.findMany({
        where: { familyId: student.familyId },
        select: { userId: true },
      });
      for (const parent of parents) {
        await this.notifications.create({
          schoolId,
          userId: parent.userId,
          type: NotificationType.PAYMENT_DUE,
          title: 'Не оплачен абонемент',
          body: `Абонемент ${student.firstName} ${student.lastName} просрочен (срок оплаты — ${dueStr}). Пожалуйста, оплатите, чтобы занятия продолжались без перерыва.`,
        });
      }
      for (const owner of owners) {
        await this.notifications.create({
          schoolId,
          userId: owner.id,
          type: NotificationType.PAYMENT_DUE,
          title: 'Просрочена оплата у семьи',
          body: `${student.firstName} ${student.lastName} — абонемент не оплачен в срок (${dueStr}).`,
        });
      }
    }
  }
}
