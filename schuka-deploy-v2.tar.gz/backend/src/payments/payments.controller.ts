// PaymentsController — /api/payments
import { Body, Controller, Get, Param, Patch } from '@nestjs/common';
import { UserRole } from '@prisma/client';
import { PaymentsService } from './payments.service';
import { MarkPaidDto } from './dto/payment.dto';
import { Roles } from '../common/decorators/roles.decorator';
import { CurrentUser, AuthUser } from '../common/decorators/current-user.decorator';

@Controller('payments')
export class PaymentsController {
  constructor(private readonly payments: PaymentsService) {}

  @Get()
  findAll(@CurrentUser() user: AuthUser) {
    return this.payments.findAll(user);
  }

  @Get('overdue')
  @Roles(UserRole.OWNER, UserRole.ADMIN)
  findOverdue(@CurrentUser() user: AuthUser) {
    return this.payments.findOverdue(user);
  }

  @Patch(':id/mark-paid')
  @Roles(UserRole.OWNER, UserRole.ADMIN)
  markPaid(@Param('id') id: string, @Body() dto: MarkPaidDto, @CurrentUser() user: AuthUser) {
    return this.payments.markPaid(id, dto, user);
  }

  @Patch(':id/mark-overdue')
  @Roles(UserRole.OWNER, UserRole.ADMIN)
  markOverdue(@Param('id') id: string, @CurrentUser() user: AuthUser) {
    return this.payments.markOverdue(id, user);
  }
}
