// PassportService — Паспорт художника. Главная ценность для родителя.
//
// Паспорт — это НЕ отдельная таблица. Это агрегатор: один запрос собирает
// из всех зачислений ребёнка полную картину его развития:
//   • навыки и их прогресс (шкала 1–5);
//   • все работы (artwork) из всех программ;
//   • достижения и бейджи;
//   • хронология комментариев педагогов;
//   • посещаемость по программам;
//   • фотогалерея с занятий.
// Всё это уже есть в базе — Паспорт просто собирает это в структурированный ответ.
import { Injectable, NotFoundException, ForbiddenException } from '@nestjs/common';
import { UserRole } from '@prisma/client';
import { PrismaService } from '../prisma/prisma.service';
import { AuthUser } from '../common/decorators/current-user.decorator';

@Injectable()
export class PassportService {
  constructor(private prisma: PrismaService) {}

  /**
   * Полный Паспорт художника.
   * Один запрос — полная история ребёнка от первого занятия до сегодня.
   */
  async getPassport(studentId: string, user: AuthUser) {
    // проверяем доступ: родитель видит только своего ребёнка
    await this.assertCanView(studentId, user);

    const student = await this.prisma.student.findFirst({
      where: { id: studentId, schoolId: user.schoolId, deletedAt: null },
      select: { id: true, firstName: true, lastName: true, birthDate: true, avatarEmoji: true },
    });
    if (!student) throw new NotFoundException('Ученик не найден');

    // все активные и завершённые зачисления (история обучения)
    const enrollments = await this.prisma.enrollment.findMany({
      where: { studentId, schoolId: user.schoolId },
      include: {
        program: { select: { name: true } },
        group: { select: { name: true } },
        attendances: {
          select: { status: true, lesson: { select: { id: true, date: true, topic: true, materials: true } } },
          orderBy: { lesson: { date: 'desc' } },
        },
        subscriptions: {
          include: { payment: true },
          orderBy: { startDate: 'desc' },
        },
        comments: {
          where: { visibility: 'PARENT' },
          include: { author: { select: { fullName: true } }, lesson: { select: { date: true, topic: true } } },
          orderBy: { createdAt: 'desc' },
          take: 20, // последние 20 комментариев
        },
      },
      orderBy: { startDate: 'asc' },
    });

    // навыки (из StudentSkill — уровень по каждому)
    const skills = await this.prisma.studentSkill.findMany({
      where: { studentId },
      include: { skill: { select: { name: true } } },
      orderBy: { updatedAt: 'desc' },
    });

    // работы (портфолио)
    const artworks = await this.prisma.artwork.findMany({
      where: { studentId },
      orderBy: { createdAt: 'desc' },
    });

    // достижения/бейджи
    const achievements = await this.prisma.studentAchievement.findMany({
      where: { studentId },
      include: { achievement: true },
      orderBy: { awardedAt: 'desc' },
    });

    // фотогалерея (последние 50)
    const photos = await this.prisma.photo.findMany({
      where: { studentId },
      include: { lesson: { select: { date: true, topic: true } } },
      orderBy: { createdAt: 'desc' },
      take: 50,
    });

    // индивидуальный план развития — вся история, последняя запись сверху
    const developmentPlans = await this.prisma.developmentPlan.findMany({
      where: { studentId },
      include: { author: { select: { fullName: true } } },
      orderBy: { createdAt: 'desc' },
    });

    // считаем статистику посещаемости по каждому зачислению
    const enrollmentsWithStats = enrollments.map((e) => {
      const total = e.attendances.length;
      const present = e.attendances.filter((a) =>
        a.status === 'PRESENT' || a.status === 'MAKEUP',
      ).length;
      // полный список уроков по этому зачислению — с темой и отметкой посещения
      const lessons = e.attendances
        .filter((a) => a.lesson)
        .map((a) => ({
          id: a.lesson!.id,
          date: a.lesson!.date,
          topic: a.lesson!.topic,
          materials: a.lesson!.materials,
          status: a.status,
        }));
      // пропущенные темы — чтобы можно было дать ребёнку наверстать
      const missedTopics = lessons.filter((l) => l.status === 'ABSENT' && l.topic);
      return {
        id: e.id,
        program: e.program.name,
        group: e.group.name,
        status: e.status,
        startDate: e.startDate,
        endDate: e.endDate,
        attendanceRate: total > 0 ? Math.round((present / total) * 100) : null,
        totalLessons: total,
        presentCount: present,
        lessons,
        missedTopics,
        recentComments: e.comments,
        // оплаты, привязанные к абонементам этого зачисления
        payments: e.subscriptions
          .filter((s) => s.payment)
          .map((s) => ({
            id: s.payment!.id,
            amount: Number(s.payment!.amount),
            status: s.payment!.status,
            method: s.payment!.method,
            paidAt: s.payment!.paidAt,
            dueDate: s.payment!.dueDate,
            totalLessons: s.totalLessons,
            remainingLessons: s.remainingLessons,
          })),
      };
    });

    // хронология всех комментариев по всем зачислениям
    const allComments = enrollments
      .flatMap((e) => e.comments.map((c) => ({ ...c, programName: e.program.name })))
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime())
      .slice(0, 30);

    // оплаты по всем зачислениям в одном списке (для вкладки «Оплаты»)
    const allPayments = enrollmentsWithStats
      .flatMap((e) => e.payments.map((p) => ({ ...p, program: e.program, group: e.group })))
      .sort((a, b) => {
        const ta = a.paidAt ? new Date(a.paidAt).getTime() : a.dueDate ? new Date(a.dueDate).getTime() : 0;
        const tb = b.paidAt ? new Date(b.paidAt).getTime() : b.dueDate ? new Date(b.dueDate).getTime() : 0;
        return tb - ta;
      });

    return {
      student,
      // прогресс навыков — основа прогресс-баров
      skills: skills.map((s) => ({ name: s.skill.name, level: s.level })),
      // достижения — бейджи
      achievements: achievements.map((a) => ({
        title: a.achievement.title,
        icon: a.achievement.iconEmoji,
        awardedAt: a.awardedAt,
      })),
      // портфолио работ
      artworks,
      // история обучения по программам
      enrollments: enrollmentsWithStats,
      // хронология комментариев педагогов
      timeline: allComments,
      // галерея фото с занятий
      photos,
      // индивидуальный план развития (история; developmentPlans[0] — текущий)
      developmentPlans,
      // все оплаты по ребёнку (по всем зачислениям)
      payments: allPayments,
      // итоговая статистика
      summary: {
        programsCount: new Set(enrollments.map((e) => e.program.name)).size,
        totalLessonsAttended: enrollmentsWithStats.reduce((s, e) => s + e.presentCount, 0),
        totalLessonsMissed: enrollmentsWithStats.reduce(
          (s, e) => s + e.lessons.filter((l) => l.status === 'ABSENT').length, 0,
        ),
        achievementsCount: achievements.length,
        artworksCount: artworks.length,
        photosCount: photos.length,
        overdueAmount: allPayments.filter((p) => p.status === 'OVERDUE').reduce((s, p) => s + p.amount, 0),
        pendingAmount: allPayments.filter((p) => p.status === 'PENDING').reduce((s, p) => s + p.amount, 0),
        // дата первого занятия в школе
        memberSince: enrollments[0]?.startDate ?? null,
      },
    };
  }

  // ── приватная проверка доступа ────────────────────────────────────────────
  private async assertCanView(studentId: string, user: AuthUser) {
    if (user.role === UserRole.OWNER || user.role === UserRole.ADMIN) return;

    if (user.role === UserRole.PARENT) {
      const parent = await this.prisma.parent.findUnique({
        where: { userId: user.userId }, select: { familyId: true },
      });
      const student = await this.prisma.student.findFirst({
        where: { id: studentId, familyId: parent?.familyId ?? '__none__' }, select: { id: true },
      });
      if (!student) throw new ForbiddenException('Нет доступа к Паспорту этого ребёнка');
      return;
    }

    if (user.role === UserRole.TEACHER) {
      const teacher = await this.prisma.teacher.findUnique({
        where: { userId: user.userId }, select: { id: true },
      });
      const enrollment = await this.prisma.enrollment.findFirst({
        where: { studentId, group: { teacherId: teacher?.id ?? '__none__' } }, select: { id: true },
      });
      if (!enrollment) throw new ForbiddenException('Нет доступа к Паспорту этого ребёнка');
    }
  }
}
