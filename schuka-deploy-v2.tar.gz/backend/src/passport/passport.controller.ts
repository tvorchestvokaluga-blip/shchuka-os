// PassportController — /api/students/:studentId/passport
// Один эндпоинт, один GET — и родитель видит всё развитие своего ребёнка.
import { Controller, Get, Param } from '@nestjs/common';
import { PassportService } from './passport.service';
import { CurrentUser, AuthUser } from '../common/decorators/current-user.decorator';

@Controller('students/:studentId/passport')
export class PassportController {
  constructor(private readonly passport: PassportService) {}

  @Get()
  getPassport(@Param('studentId') studentId: string, @CurrentUser() user: AuthUser) {
    return this.passport.getPassport(studentId, user);
  }
}
