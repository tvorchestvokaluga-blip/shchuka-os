// InventoryController — /api/inventory, вкладка «Инвентаризация» у руководителя/администратора.
import { Body, Controller, Delete, Get, Param, Patch, Post } from '@nestjs/common';
import { UserRole } from '@prisma/client';
import { InventoryService } from './inventory.service';
import { CreateInventoryItemDto, UpdateInventoryItemDto } from './dto/inventory.dto';
import { Roles } from '../common/decorators/roles.decorator';
import { CurrentUser, AuthUser } from '../common/decorators/current-user.decorator';

@Controller('inventory')
@Roles(UserRole.OWNER, UserRole.ADMIN)
export class InventoryController {
  constructor(private readonly inventory: InventoryService) {}

  @Get()
  findAll(@CurrentUser() user: AuthUser) {
    return this.inventory.findAll(user);
  }

  @Post()
  create(@Body() dto: CreateInventoryItemDto, @CurrentUser() user: AuthUser) {
    return this.inventory.create(dto, user);
  }

  @Patch(':id')
  update(@Param('id') id: string, @Body() dto: UpdateInventoryItemDto, @CurrentUser() user: AuthUser) {
    return this.inventory.update(id, dto, user);
  }

  @Delete(':id')
  remove(@Param('id') id: string, @CurrentUser() user: AuthUser) {
    return this.inventory.remove(id, user);
  }
}
