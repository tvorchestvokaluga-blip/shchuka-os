// InventoryService — расходники школы (бумага, краски, мыло...) с сигналом о закупке.
// При каждом просмотре списка сама проверяет, что упало ниже порога, и один раз
// (не чаще раза в 3 дня на одну позицию) уведомляет руководителя/администраторов.
import { Injectable, NotFoundException } from '@nestjs/common';
import { NotificationType, UserRole } from '@prisma/client';
import { PrismaService } from '../prisma/prisma.service';
import { AuthUser } from '../common/decorators/current-user.decorator';
import { NotificationsService } from '../notifications/notifications.service';
import { CreateInventoryItemDto, UpdateInventoryItemDto } from './dto/inventory.dto';

const RENOTIFY_AFTER_MS = 3 * 24 * 60 * 60 * 1000; // не чаще раза в 3 дня на одну позицию

@Injectable()
export class InventoryService {
  constructor(
    private prisma: PrismaService,
    private notifications: NotificationsService,
  ) {}

  async findAll(user: AuthUser) {
    const items = await this.prisma.inventoryItem.findMany({
      where: { schoolId: user.schoolId },
      orderBy: { name: 'asc' },
    });

    await this.checkLowStockAndNotify(user.schoolId, items).catch(() => {});

    return items
      .map((i) => ({ ...i, low: Number(i.quantity) <= Number(i.minQuantity) }))
      .sort((a, b) => Number(b.low) - Number(a.low) || a.name.localeCompare(b.name, 'ru'));
  }

  async create(dto: CreateInventoryItemDto, user: AuthUser) {
    return this.prisma.inventoryItem.create({
      data: {
        schoolId: user.schoolId,
        name: dto.name,
        unit: dto.unit ?? 'шт',
        quantity: dto.quantity ?? 0,
        minQuantity: dto.minQuantity ?? 0,
        note: dto.note,
      },
    });
  }

  async update(id: string, dto: UpdateInventoryItemDto, user: AuthUser) {
    await this.ensureInSchool(id, user.schoolId);
    return this.prisma.inventoryItem.update({ where: { id }, data: dto });
  }

  async remove(id: string, user: AuthUser) {
    await this.ensureInSchool(id, user.schoolId);
    return this.prisma.inventoryItem.delete({ where: { id } });
  }

  private async ensureInSchool(id: string, schoolId: string) {
    const i = await this.prisma.inventoryItem.findFirst({ where: { id, schoolId }, select: { id: true } });
    if (!i) throw new NotFoundException('Позиция не найдена');
  }

  private async checkLowStockAndNotify(schoolId: string, items: { id: string; name: string; quantity: any; minQuantity: any; unit: string; lowStockNotifiedAt: Date | null }[]) {
    const now = Date.now();
    const toNotify = items.filter((i) => {
      if (Number(i.quantity) > Number(i.minQuantity)) return false;
      if (!i.lowStockNotifiedAt) return true;
      return now - new Date(i.lowStockNotifiedAt).getTime() > RENOTIFY_AFTER_MS;
    });
    if (toNotify.length === 0) return;

    const owners = await this.prisma.user.findMany({
      where: { schoolId, role: { in: [UserRole.OWNER, UserRole.ADMIN] }, isActive: true },
      select: { id: true },
    });

    for (const item of toNotify) {
      for (const owner of owners) {
        await this.notifications.create({
          schoolId,
          userId: owner.id,
          type: NotificationType.INVENTORY_LOW,
          title: '📦 Заканчивается расходник',
          body: `«${item.name}» — осталось ${Number(item.quantity)} ${item.unit}. Пора закупить.`,
        });
      }
      await this.prisma.inventoryItem.update({
        where: { id: item.id },
        data: { lowStockNotifiedAt: new Date() },
      });
    }
  }
}
