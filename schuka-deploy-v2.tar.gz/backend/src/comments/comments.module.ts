import { Module } from '@nestjs/common';
import { CommentsService } from './comments.service';
import { CommentsController, EnrollmentCommentsController } from './comments.controller';

@Module({
  controllers: [CommentsController, EnrollmentCommentsController],
  providers: [CommentsService],
  exports: [CommentsService],
})
export class CommentsModule {}
