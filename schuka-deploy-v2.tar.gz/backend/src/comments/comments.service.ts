// CommentsService — комментарии педагога о прогрессе ребёнка.
// Главная функция: generateAiDraft — педагог нажимает кнопку и получает
// тёплый черновик за 2–3 секунды. Черновик готовит AI, человек утверждает.
// AI-вызов идёт через серверный слой — ключ Claude API не попадает в браузер.
import { Injectable, NotFoundException, ForbiddenException } from '@nestjs/common';
import { UserRole, CommentVisibility } from '@prisma/client';
import { ConfigService } from '@nestjs/config';
import { PrismaService } from '../prisma/prisma.service';
import { AuthUser } from '../common/decorators/current-user.decorator';
import { CreateCommentDto, UpdateCommentDto, GenerateAiDraftDto } from './dto/comment.dto';

@Injectable()
export class CommentsService {
  constructor(
    private prisma: PrismaService,
    private config: ConfigService,
  ) {}

  /** Комментарии зачисления. Родитель видит только PARENT-видимость. */
  async findByEnrollment(enrollmentId: string, user: AuthUser) {
    const enrollment = await this.prisma.enrollment.findFirst({
      where: { id: enrollmentId, schoolId: user.schoolId }, select: { id: true },
    });
    if (!enrollment) throw new NotFoundException('Зачисление не найдено');

    const visibilityFilter =
      user.role === UserRole.PARENT ? { visibility: CommentVisibility.PARENT } : {};

    return this.prisma.comment.findMany({
      where: { enrollmentId, ...visibilityFilter },
      include: { author: { select: { fullName: true } }, lesson: { select: { date: true, topic: true } } },
      orderBy: { createdAt: 'desc' },
    });
  }

  async create(dto: CreateCommentDto, user: AuthUser) {
    const enrollment = await this.prisma.enrollment.findFirst({
      where: { id: dto.enrollmentId, schoolId: user.schoolId }, select: { id: true },
    });
    if (!enrollment) throw new NotFoundException('Зачисление не найдено');

    return this.prisma.comment.create({
      data: {
        schoolId: user.schoolId,
        enrollmentId: dto.enrollmentId,
        lessonId: dto.lessonId,
        authorId: user.userId,
        text: dto.text,
        visibility: dto.visibility ?? CommentVisibility.PARENT,
        aiAssisted: dto.aiAssisted ?? false,
      },
      include: { author: { select: { fullName: true } } },
    });
  }

  async update(id: string, dto: UpdateCommentDto, user: AuthUser) {
    const comment = await this.prisma.comment.findFirst({
      where: { id, schoolId: user.schoolId }, select: { id: true, authorId: true },
    });
    if (!comment) throw new NotFoundException('Комментарий не найден');
    if (comment.authorId !== user.userId && user.role !== UserRole.OWNER) {
      throw new ForbiddenException('Можно редактировать только свои комментарии');
    }
    return this.prisma.comment.update({ where: { id }, data: dto });
  }

  /**
   * Генерирует AI-черновик комментария через Claude API.
   * Собирает контекст: имя ребёнка, программу, навыки, тему урока —
   * и отправляет в Claude. Педагог получает тёплый текст, редактирует и сохраняет.
   * Ключ ANTHROPIC_API_KEY живёт только в .env на сервере.
   */
  async generateAiDraft(dto: GenerateAiDraftDto, user: AuthUser): Promise<{ draft: string }> {
    const enrollment = await this.prisma.enrollment.findFirst({
      where: { id: dto.enrollmentId, schoolId: user.schoolId },
      include: {
        student: {
          include: {
            skills: { include: { skill: true } },
          },
        },
        program: { select: { name: true } },
      },
    });
    if (!enrollment) throw new NotFoundException('Зачисление не найдено');

    const { student, program } = enrollment;
    const skillsSummary = student.skills.length > 0
      ? student.skills.map((s) => `${s.skill.name}: ${s.level}/5`).join(', ')
      : 'навыки пока не оценены';

    const apiKey = this.config.get<string>('ANTHROPIC_API_KEY');
    if (!apiKey) {
      // заглушка — до подключения AI-ключа
      return {
        draft: `Сегодня ${student.firstName} работал(а) на занятии по программе «${program.name}»` +
               (dto.lessonTopic ? ` (тема: ${dto.lessonTopic})` : '') +
               `. Молодец! [AI-черновик недоступен: добавьте ANTHROPIC_API_KEY в .env]`,
      };
    }

    const prompt = [
      `Ты — помощник педагога художественной школы. Напиши тёплый, краткий (3–5 предложений) комментарий для родителей`,
      `о прогрессе ребёнка на занятии. Комментарий должен быть конкретным, поддерживающим и дать родителю`,
      `понять, что именно происходило на уроке.`,
      ``,
      `Данные:`,
      `- Имя ребёнка: ${student.firstName}`,
      `- Программа: ${program.name}`,
      dto.lessonTopic ? `- Тема урока: ${dto.lessonTopic}` : '',
      `- Текущие навыки: ${skillsSummary}`,
      ``,
      `Напиши только текст комментария, без заголовков и вводных фраз.`,
    ].filter(Boolean).join('\n');

    const response = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': apiKey,
        'anthropic-version': '2023-06-01',
      },
      body: JSON.stringify({
        model: 'claude-sonnet-4-6',
        max_tokens: 300,
        messages: [{ role: 'user', content: prompt }],
      }),
    });

    if (!response.ok) {
      const err = await response.text();
      throw new Error(`Claude API error: ${err}`);
    }

    const data = await response.json();
    const draft = data.content?.[0]?.text ?? '';
    return { draft };
  }

  /**
   * Авто-комментарий "по скрипту" — вызывается при загрузке фото с урока
   * в разделе «Мои группы» педагога. Готовит тёплый текст (AI, либо шаблон,
   * если ключ ещё не подключён) и сразу сохраняет как обычный комментарий —
   * родитель увидит его в личной карточке ребёнка и в паспорте художника,
   * никаких дополнительных действий от педагога не требуется.
   */
  async autoCreateForLessonPhoto(params: { studentId: string; lessonId: string }, user: AuthUser) {
    const lesson = await this.prisma.lesson.findFirst({
      where: { id: params.lessonId, schoolId: user.schoolId },
      select: { id: true, groupId: true, topic: true },
    });
    if (!lesson) return null;

    const enrollment = await this.prisma.enrollment.findFirst({
      where: { studentId: params.studentId, groupId: lesson.groupId, status: 'ACTIVE' },
      select: { id: true },
    });
    if (!enrollment) return null; // ребёнок не числится активным в этой группе — молча пропускаем

    const { draft } = await this.generateAiDraft(
      { enrollmentId: enrollment.id, lessonId: lesson.id, lessonTopic: lesson.topic ?? undefined },
      user,
    );

    return this.create(
      {
        enrollmentId: enrollment.id,
        lessonId: lesson.id,
        text: draft,
        visibility: CommentVisibility.PARENT,
        aiAssisted: true,
      },
      user,
    );
  }
}
