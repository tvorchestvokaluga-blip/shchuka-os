// CommentsController — /api/enrollments/:enrollmentId/comments  и  /api/comments
import { Body, Controller, Get, Param, Patch, Post } from '@nestjs/common';
import { UserRole } from '@prisma/client';
import { CommentsService } from './comments.service';
import { CreateCommentDto, UpdateCommentDto, GenerateAiDraftDto } from './dto/comment.dto';
import { Roles } from '../common/decorators/roles.decorator';
import { CurrentUser, AuthUser } from '../common/decorators/current-user.decorator';

@Controller('enrollments/:enrollmentId/comments')
export class EnrollmentCommentsController {
  constructor(private readonly comments: CommentsService) {}

  @Get()
  findByEnrollment(@Param('enrollmentId') enrollmentId: string, @CurrentUser() user: AuthUser) {
    return this.comments.findByEnrollment(enrollmentId, user);
  }
}

@Controller('comments')
export class CommentsController {
  constructor(private readonly comments: CommentsService) {}

  @Post()
  @Roles(UserRole.OWNER, UserRole.ADMIN, UserRole.TEACHER)
  create(@Body() dto: CreateCommentDto, @CurrentUser() user: AuthUser) {
    return this.comments.create(dto, user);
  }

  @Patch(':id')
  @Roles(UserRole.OWNER, UserRole.ADMIN, UserRole.TEACHER)
  update(@Param('id') id: string, @Body() dto: UpdateCommentDto, @CurrentUser() user: AuthUser) {
    return this.comments.update(id, dto, user);
  }

  /** Педагог нажал «Подготовить черновик» — AI отвечает за 2–3 секунды. */
  @Post('ai-draft')
  @Roles(UserRole.OWNER, UserRole.ADMIN, UserRole.TEACHER)
  generateAiDraft(@Body() dto: GenerateAiDraftDto, @CurrentUser() user: AuthUser) {
    return this.comments.generateAiDraft(dto, user);
  }
}
