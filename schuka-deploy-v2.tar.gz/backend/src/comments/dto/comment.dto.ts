// Данные запросов для комментариев педагога.
import { IsBoolean, IsEnum, IsOptional, IsString, MinLength } from 'class-validator';
import { CommentVisibility } from '@prisma/client';

export class CreateCommentDto {
  @IsString()
  enrollmentId: string;

  @IsOptional()
  @IsString()
  lessonId?: string;

  @IsString()
  @MinLength(1)
  text: string;

  @IsOptional()
  @IsEnum(CommentVisibility)
  visibility?: CommentVisibility; // PARENT (по умолч.) или INTERNAL

  @IsOptional()
  @IsBoolean()
  aiAssisted?: boolean; // true если педагог использовал AI-черновик
}

export class UpdateCommentDto {
  @IsOptional() @IsString() @MinLength(1) text?: string;
  @IsOptional() @IsEnum(CommentVisibility) visibility?: CommentVisibility;
}

export class GenerateAiDraftDto {
  @IsString()
  enrollmentId: string;

  @IsOptional()
  @IsString()
  lessonTopic?: string; // тема урока для контекста

  @IsOptional()
  @IsString()
  lessonId?: string;
}
