// PrismaModule — глобальный модуль, чтобы PrismaService был доступен везде без повторного импорта.
import { Global, Module } from '@nestjs/common';
import { PrismaService } from './prisma.service';

@Global()
@Module({
  providers: [PrismaService],
  exports: [PrismaService],
})
export class PrismaModule {}
