// ============================================================================
//  PrismaService — единая точка доступа к базе данных для всего приложения.
//  Оборачивает PrismaClient в инжектируемый сервис NestJS.
// ============================================================================
import { Injectable, OnModuleInit, INestApplication } from '@nestjs/common';
import { PrismaClient } from '@prisma/client';

@Injectable()
export class PrismaService extends PrismaClient implements OnModuleInit {
  async onModuleInit() {
    await this.$connect();
  }

  /** Аккуратное завершение соединения при остановке приложения. */
  async enableShutdownHooks(app: INestApplication) {
    process.on('beforeExit', async () => {
      await app.close();
    });
  }
}
