// StudentsService — бизнес-логика учеников.
// Самое важное здесь — видимость по ролям:
//   OWNER/ADMIN  — все дети школы
//   TEACHER      — только дети из его групп (через enrollment → group → teacher)
//   PARENT       — только дети его семьи
import { Injectable, NotFoundException, ForbiddenException, BadRequestException } from '@nestjs/common';
import { UserRole, Prisma } from '@prisma/client';
import { PrismaService } from '../prisma/prisma.service';
import { AuthUser } from '../common/decorators/current-user.decorator';
import { CreateStudentDto, UpdateStudentDto } from './dto/student.dto';

@Injectable()
export class StudentsService {
  constructor(private prisma: PrismaService) {}

  /** Список детей, видимых данному пользователю. */
  async findAll(user: AuthUser) {
    const where = await this.visibilityFilter(user);
    return this.prisma.student.findMany({
      where,
      include: {
        family: { select: { id: true, name: true } },
        // активная запись группы/программы — нужна для общего списка и росписи по группам
        enrollments: {
          where: { status: 'ACTIVE' },
          include: { group: { select: { id: true, name: true } }, program: { select: { id: true, name: true } } },
        },
      },
      orderBy: [{ lastName: 'asc' }, { firstName: 'asc' }],
    });
  }

  /** Один ребёнок — с проверкой, что пользователь имеет право его видеть. */
  async findOne(id: string, user: AuthUser) {
    const base = await this.visibilityFilter(user);
    const student = await this.prisma.student.findFirst({
      where: { AND: [{ id }, where(base)] },
      include: {
        family: { select: { id: true, name: true } },
        enrollments: { include: { program: true, group: true } },
      },
    });
    if (!student) throw new NotFoundException('Ученик не найден или нет доступа');
    return student;
  }

  /** Создать ребёнка — только сотрудники, и только в семью своей школы. */
  async create(dto: CreateStudentDto, user: AuthUser) {
    const family = await this.prisma.family.findFirst({
      where: { id: dto.familyId, schoolId: user.schoolId, deletedAt: null },
      select: { id: true },
    });
    if (!family) throw new BadRequestException('Семья не найдена в вашей школе');

    return this.prisma.student.create({
      data: {
        schoolId: user.schoolId,
        familyId: dto.familyId,
        firstName: dto.firstName,
        lastName: dto.lastName,
        birthDate: dto.birthDate ? new Date(dto.birthDate) : null,
        avatarEmoji: dto.avatarEmoji,
        note: dto.note,
      },
    });
  }

  async update(id: string, dto: UpdateStudentDto, user: AuthUser) {
    await this.ensureInSchool(id, user.schoolId);
    const data: Prisma.StudentUpdateInput = { ...dto };
    if (dto.birthDate) data.birthDate = new Date(dto.birthDate);
    return this.prisma.student.update({ where: { id }, data });
  }

  /** Мягкое удаление. */
  async remove(id: string, user: AuthUser) {
    await this.ensureInSchool(id, user.schoolId);
    return this.prisma.student.update({ where: { id }, data: { deletedAt: new Date() } });
  }

  // ── права и фильтры ───────────────────────────────────────────────────────

  /** Возвращает Prisma-фильтр «каких детей этому пользователю видно». */
  private async visibilityFilter(user: AuthUser): Promise<Prisma.StudentWhereInput> {
    const inSchool: Prisma.StudentWhereInput = { schoolId: user.schoolId, deletedAt: null };

    if (user.role === UserRole.OWNER || user.role === UserRole.ADMIN) {
      return inSchool;
    }

    if (user.role === UserRole.PARENT) {
      const parent = await this.prisma.parent.findUnique({
        where: { userId: user.userId },
        select: { familyId: true },
      });
      // если родитель не привязан — не видит никого
      return { ...inSchool, familyId: parent?.familyId ?? '__none__' };
    }

    if (user.role === UserRole.TEACHER) {
      const teacher = await this.prisma.teacher.findUnique({
        where: { userId: user.userId },
        select: { id: true },
      });
      // дети, у которых есть зачисление в группу этого педагога
      return {
        ...inSchool,
        enrollments: { some: { group: { teacherId: teacher?.id ?? '__none__' } } },
      };
    }

    // прочие роли (маркетолог, бухгалтер) в этом модуле детей не видят
    return { ...inSchool, id: '__none__' };
  }

  private async ensureInSchool(studentId: string, schoolId: string) {
    const s = await this.prisma.student.findFirst({
      where: { id: studentId, schoolId, deletedAt: null },
      select: { id: true },
    });
    if (!s) throw new NotFoundException('Ученик не найден');
  }
}

// маленький помощник, чтобы вложить фильтр видимости в AND
function where(filter: Prisma.StudentWhereInput): Prisma.StudentWhereInput {
  return filter;
}
