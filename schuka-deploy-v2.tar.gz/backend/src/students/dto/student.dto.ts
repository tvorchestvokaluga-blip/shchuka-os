// Данные запросов для учеников, с валидацией.
import { IsDateString, IsOptional, IsString, MinLength } from 'class-validator';

export class CreateStudentDto {
  @IsString()
  familyId: string;

  @IsString()
  @MinLength(1)
  firstName: string;

  @IsString()
  @MinLength(1)
  lastName: string;

  @IsOptional()
  @IsDateString({}, { message: 'Дата рождения в формате ГГГГ-ММ-ДД' })
  birthDate?: string;

  @IsOptional()
  @IsString()
  avatarEmoji?: string;

  @IsOptional()
  @IsString()
  note?: string;
}

export class UpdateStudentDto {
  @IsOptional() @IsString() @MinLength(1) firstName?: string;
  @IsOptional() @IsString() @MinLength(1) lastName?: string;
  @IsOptional() @IsDateString() birthDate?: string;
  @IsOptional() @IsString() avatarEmoji?: string;
  @IsOptional() @IsString() note?: string;
}
