// UsersService — управление учётными записями сотрудников (педагогов и администраторов).
// Пароли не хранятся и не шифруются обратимо (только bcrypt-хэш) — при создании
// аккаунта или сбросе пароля временный пароль показывается ОДИН раз, его нужно
// сразу передать сотруднику (скопировать/сфотографировать).
import { Injectable, NotFoundException, BadRequestException } from '@nestjs/common';
import * as crypto from 'crypto';
import * as bcrypt from 'bcrypt';
import { UserRole } from '@prisma/client';
import { PrismaService } from '../prisma/prisma.service';
import { AuthUser } from '../common/decorators/current-user.decorator';
import { CreateTeacherDto } from './dto/user.dto';

function randomPassword(): string {
  // короткий, но случайный пароль — без +/=, чтобы легко было продиктовать/скопировать
  return crypto.randomBytes(6).toString('base64').replace(/[+/=]/g, '').slice(0, 10);
}

@Injectable()
export class UsersService {
  constructor(private prisma: PrismaService) {}

  /** Список сотрудников школы — для экрана «Сотрудники». По умолчанию педагоги + руководство. */
  async findStaff(user: AuthUser, role?: UserRole) {
    return this.prisma.user.findMany({
      where: {
        schoolId: user.schoolId,
        role: role ?? { in: [UserRole.TEACHER, UserRole.ADMIN, UserRole.OWNER] },
      },
      select: {
        id: true,
        fullName: true,
        email: true,
        phone: true,
        role: true,
        isActive: true,
        lastLoginAt: true,
        createdAt: true,
        teacher: { select: { id: true, groups: { select: { id: true, name: true } } } },
      },
      orderBy: [{ role: 'asc' }, { fullName: 'asc' }],
    });
  }

  /** Создать нового педагога — сразу с учётной записью для входа и временным паролем. */
  async createTeacher(dto: CreateTeacherDto, user: AuthUser) {
    const existing = await this.prisma.user.findFirst({
      where: { schoolId: user.schoolId, email: dto.email },
    });
    if (existing) {
      throw new BadRequestException('Пользователь с таким email уже есть в этой школе');
    }

    const tempPassword = randomPassword();
    const passwordHash = await bcrypt.hash(tempPassword, 10);

    const created = await this.prisma.user.create({
      data: {
        schoolId: user.schoolId,
        email: dto.email,
        phone: dto.phone,
        passwordHash,
        fullName: dto.fullName,
        role: UserRole.TEACHER,
        teacher: { create: { schoolId: user.schoolId, bio: dto.bio } },
      },
      select: { id: true, fullName: true, email: true, role: true },
    });

    return { user: created, tempPassword };
  }

  /** Сбросить пароль сотруднику (например, если забыл) — новый показывается один раз. */
  async resetPassword(userId: string, user: AuthUser) {
    const target = await this.prisma.user.findFirst({
      where: { id: userId, schoolId: user.schoolId },
      select: { id: true, fullName: true },
    });
    if (!target) throw new NotFoundException('Пользователь не найден');

    const tempPassword = randomPassword();
    const passwordHash = await bcrypt.hash(tempPassword, 10);
    await this.prisma.user.update({ where: { id: userId }, data: { passwordHash } });

    return { fullName: target.fullName, tempPassword };
  }

  /** Включить/выключить вход сотруднику, не удаляя его данные и историю. */
  async setActive(userId: string, isActive: boolean, user: AuthUser) {
    const target = await this.prisma.user.findFirst({
      where: { id: userId, schoolId: user.schoolId },
      select: { id: true },
    });
    if (!target) throw new NotFoundException('Пользователь не найден');
    return this.prisma.user.update({
      where: { id: userId },
      data: { isActive },
      select: { id: true, isActive: true },
    });
  }
}
