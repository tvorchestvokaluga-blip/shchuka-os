// UsersController — /api/users. Экран «Сотрудники»: список педагогов/админов,
// добавление педагога, сброс пароля, включение/выключение доступа.
// Доступно только руководителю и администратору.
import { Body, Controller, Get, Param, Patch, Post, Query } from '@nestjs/common';
import { UserRole } from '@prisma/client';
import { UsersService } from './users.service';
import { CreateTeacherDto, UpdateUserActiveDto } from './dto/user.dto';
import { Roles } from '../common/decorators/roles.decorator';
import { CurrentUser, AuthUser } from '../common/decorators/current-user.decorator';

@Controller('users')
export class UsersController {
  constructor(private readonly users: UsersService) {}

  @Get()
  @Roles(UserRole.OWNER, UserRole.ADMIN)
  findStaff(@Query('role') role: UserRole | undefined, @CurrentUser() user: AuthUser) {
    return this.users.findStaff(user, role);
  }

  @Post('teachers')
  @Roles(UserRole.OWNER, UserRole.ADMIN)
  createTeacher(@Body() dto: CreateTeacherDto, @CurrentUser() user: AuthUser) {
    return this.users.createTeacher(dto, user);
  }

  @Post(':id/reset-password')
  @Roles(UserRole.OWNER, UserRole.ADMIN)
  resetPassword(@Param('id') id: string, @CurrentUser() user: AuthUser) {
    return this.users.resetPassword(id, user);
  }

  @Patch(':id')
  @Roles(UserRole.OWNER, UserRole.ADMIN)
  setActive(@Param('id') id: string, @Body() dto: UpdateUserActiveDto, @CurrentUser() user: AuthUser) {
    return this.users.setActive(id, dto.isActive, user);
  }
}
