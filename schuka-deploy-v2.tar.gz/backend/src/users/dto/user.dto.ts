// Данные запросов для управления сотрудниками.
import { IsBoolean, IsEmail, IsOptional, IsString, MinLength } from 'class-validator';

export class CreateTeacherDto {
  @IsString()
  @MinLength(2, { message: 'Укажите имя и фамилию' })
  fullName: string;

  @IsEmail({}, { message: 'Введите корректный email — он понадобится педагогу для входа' })
  email: string;

  @IsOptional()
  @IsString()
  phone?: string;

  @IsOptional()
  @IsString()
  bio?: string; // короткая справка о педагоге (необязательно)
}

export class UpdateUserActiveDto {
  @IsBoolean()
  isActive: boolean;
}
