// ReportsService — сводные отчёты для руководителя/администратора школы:
// еженедельная сводка по школе + список детей, требующих внимания (пропуски / нет обратной связи).
// Читает уже существующие данные (уроки, посещаемость, оплаты, инвентарь, задачи) —
// собственной таблицы не заводит, всё считается "на лету" при запросе.
import { Injectable } from '@nestjs/common';
import { AttendanceStatus, EnrollmentStatus, PaymentStatus, TaskStatus } from '@prisma/client';
import { PrismaService } from '../prisma/prisma.service';
import { AuthUser } from '../common/decorators/current-user.decorator';

const DAY_MS = 24 * 60 * 60 * 1000;

@Injectable()
export class ReportsService {
  constructor(private prisma: PrismaService) {}

  /** Сводка по школе за последние 7 дней (или dto.days, если передан). */
  async weeklySummary(user: AuthUser, days = 7) {
    const schoolId = user.schoolId;
    const now = new Date();
    const from = new Date(now.getTime() - days * DAY_MS);

    const [
      lessons,
      newEnrollments,
      paidPayments,
      overduePayments,
      pendingPayments,
      newPhotos,
      newComments,
      newHomework,
      inventoryItems,
      openTasks,
      students,
    ] = await Promise.all([
      this.prisma.lesson.findMany({
        where: { schoolId, date: { gte: from, lte: now } },
        include: { attendances: { select: { status: true } }, group: { select: { name: true } } },
      }),
      this.prisma.enrollment.count({ where: { schoolId, createdAt: { gte: from, lte: now } } }),
      this.prisma.payment.findMany({ where: { schoolId, status: PaymentStatus.PAID, paidAt: { gte: from, lte: now } } }),
      this.prisma.payment.findMany({ where: { schoolId, status: PaymentStatus.OVERDUE } }),
      this.prisma.payment.findMany({ where: { schoolId, status: PaymentStatus.PENDING } }),
      this.prisma.photo.count({ where: { schoolId, createdAt: { gte: from, lte: now } } }),
      this.prisma.comment.count({ where: { schoolId, createdAt: { gte: from, lte: now } } }),
      this.prisma.homework.count({ where: { schoolId, createdAt: { gte: from, lte: now } } }),
      this.prisma.inventoryItem.findMany({ where: { schoolId } }),
      this.prisma.task.count({ where: { schoolId, status: TaskStatus.TODO } }),
      this.prisma.student.findMany({ where: { schoolId, deletedAt: null }, select: { id: true, firstName: true, lastName: true, birthDate: true } }),
    ]);

    let present = 0, absent = 0, excused = 0, makeup = 0;
    for (const l of lessons) {
      for (const a of l.attendances) {
        if (a.status === AttendanceStatus.PRESENT) present++;
        else if (a.status === AttendanceStatus.ABSENT) absent++;
        else if (a.status === AttendanceStatus.EXCUSED) excused++;
        else if (a.status === AttendanceStatus.MAKEUP) makeup++;
      }
    }
    const totalMarks = present + absent + excused + makeup;
    const attendanceRate = totalMarks > 0 ? Math.round((present / totalMarks) * 100) : null;

    const revenueCollected = paidPayments.reduce((s, p) => s + Number(p.amount), 0);
    const overdueAmount = overduePayments.reduce((s, p) => s + Number(p.amount), 0);
    const pendingAmount = pendingPayments.reduce((s, p) => s + Number(p.amount), 0);

    const birthdays = students
      .filter((s) => this.isBirthdayWithinDays(s.birthDate, now, days))
      .map((s) => ({ id: s.id, name: `${s.firstName} ${s.lastName}`, birthDate: s.birthDate }));

    const lowStock = inventoryItems
      .filter((i) => Number(i.quantity) <= Number(i.minQuantity))
      .map((i) => ({ id: i.id, name: i.name, quantity: Number(i.quantity), unit: i.unit }));

    return {
      period: { from, to: now, days },
      lessonsHeld: lessons.length,
      attendance: { present, absent, excused, makeup, rate: attendanceRate },
      enrollments: { new: newEnrollments },
      revenue: {
        collected: revenueCollected,
        pendingAmount,
        pendingCount: pendingPayments.length,
        overdueAmount,
        overdueCount: overduePayments.length,
      },
      activity: { newPhotos, newComments, newHomework },
      inventory: { lowStockCount: lowStock.length, items: lowStock },
      tasks: { open: openTasks },
      birthdays,
    };
  }

  /** Дети, на которых стоит обратить внимание: частые пропуски или давно нет комментария педагога. */
  async attentionAlerts(user: AuthUser) {
    const schoolId = user.schoolId;
    const now = new Date();
    const attendanceWindowStart = new Date(now.getTime() - 30 * DAY_MS);
    const feedbackWindowStart = new Date(now.getTime() - 45 * DAY_MS);

    const enrollments = await this.prisma.enrollment.findMany({
      where: { schoolId, status: EnrollmentStatus.ACTIVE },
      include: {
        student: { select: { id: true, firstName: true, lastName: true } },
        group: { select: { id: true, name: true } },
        attendances: {
          where: { lesson: { date: { gte: attendanceWindowStart, lte: now } } },
          select: { status: true },
        },
        comments: {
          orderBy: { createdAt: 'desc' },
          take: 1,
          select: { createdAt: true },
        },
      },
    });

    const severityOrder: Record<string, number> = { high: 0, medium: 1, low: 2 };
    const alerts: Array<{
      studentId: string; name: string; groupName: string;
      type: 'ATTENDANCE' | 'NO_FEEDBACK'; severity: 'high' | 'medium' | 'low'; detail: string;
    }> = [];

    for (const e of enrollments) {
      const name = `${e.student.firstName} ${e.student.lastName}`;
      const absences = e.attendances.filter((a) => a.status === AttendanceStatus.ABSENT).length;

      if (absences >= 2) {
        alerts.push({
          studentId: e.student.id,
          name,
          groupName: e.group.name,
          type: 'ATTENDANCE',
          severity: absences >= 3 ? 'high' : 'medium',
          detail: `${absences} пропуск(ов) без отработки за последние 30 дней`,
        });
      }

      const lastComment = e.comments[0]?.createdAt;
      if (!lastComment || lastComment < feedbackWindowStart) {
        alerts.push({
          studentId: e.student.id,
          name,
          groupName: e.group.name,
          type: 'NO_FEEDBACK',
          severity: 'low',
          detail: lastComment
            ? `Нет комментария педагога дольше 45 дней (последний — ${lastComment.toLocaleDateString('ru-RU')})`
            : 'Нет ни одного комментария педагога',
        });
      }
    }

    alerts.sort((a, b) => severityOrder[a.severity] - severityOrder[b.severity]);
    return alerts;
  }

  /** День рождения ребёнка попадает в окно [from, from+days] по месяцу/числу, без учёта года. */
  private isBirthdayWithinDays(birthDate: Date | null, from: Date, days: number): boolean {
    if (!birthDate) return false;
    for (let i = 0; i <= days; i++) {
      const d = new Date(from.getTime() + i * DAY_MS);
      if (d.getMonth() === birthDate.getMonth() && d.getDate() === birthDate.getDate()) return true;
    }
    return false;
  }
}
