// ReportsController — /api/reports, сводные отчёты для руководителя/администратора.
import { Controller, Get, Query } from '@nestjs/common';
import { UserRole } from '@prisma/client';
import { ReportsService } from './reports.service';
import { Roles } from '../common/decorators/roles.decorator';
import { CurrentUser, AuthUser } from '../common/decorators/current-user.decorator';

@Controller('reports')
@Roles(UserRole.OWNER, UserRole.ADMIN)
export class ReportsController {
  constructor(private readonly reports: ReportsService) {}

  @Get('weekly-summary')
  weeklySummary(@CurrentUser() user: AuthUser, @Query('days') days?: string) {
    const parsed = days ? parseInt(days, 10) : 7;
    return this.reports.weeklySummary(user, Number.isFinite(parsed) && parsed > 0 ? parsed : 7);
  }

  @Get('attention')
  attentionAlerts(@CurrentUser() user: AuthUser) {
    return this.reports.attentionAlerts(user);
  }
}
