// LessonsService — конкретные занятия группы в конкретный день.
// Педагог создаёт/редактирует уроки своей группы; родитель видит уроки групп своих детей.
import { Injectable, NotFoundException, ForbiddenException, BadRequestException } from '@nestjs/common';
import { UserRole } from '@prisma/client';
import { PrismaService } from '../prisma/prisma.service';
import { AuthUser } from '../common/decorators/current-user.decorator';
import { CreateLessonDto, UpdateLessonDto, GenerateLessonsDto } from './dto/lesson.dto';

const WEEKDAY_INDEX: Record<string, number> = {
  SUN: 0, MON: 1, TUE: 2, WED: 3, THU: 4, FRI: 5, SAT: 6,
};

@Injectable()
export class LessonsService {
  constructor(private prisma: PrismaService) {}

  async findByGroup(groupId: string, user: AuthUser) {
    const group = await this.assertGroupAccess(groupId, user);
    // сортировка "свежее — сверху" — так исторически ждёт экран посещаемости;
    // для учебного плана (по темам на весь год) сортировку по возрастанию
    // делает сам фронтенд, где это нужно.
    return this.prisma.lesson.findMany({
      where: { groupId: group.id },
      include: { _count: { select: { attendances: true, photos: true } } },
      orderBy: { date: 'desc' },
    });
  }

  async findOne(id: string, user: AuthUser) {
    const lesson = await this.prisma.lesson.findFirst({
      where: { id, schoolId: user.schoolId },
      include: {
        group: { select: { id: true, name: true, teacherId: true } },
        attendances: { include: { enrollment: { include: { student: true } } } },
        photos: true,
        comments: { where: { visibility: 'PARENT' }, include: { author: { select: { fullName: true } } } },
      },
    });
    if (!lesson) throw new NotFoundException('Урок не найден');
    if (user.role === UserRole.TEACHER) {
      await this.assertTeacherOwnsGroup(lesson.group.teacherId, user);
    }
    return lesson;
  }

  async create(dto: CreateLessonDto, user: AuthUser) {
    const group = await this.assertGroupAccess(dto.groupId, user, /* requireWrite */ true);

    return this.prisma.lesson.create({
      data: {
        schoolId: user.schoolId,
        groupId: group.id,
        moduleId: dto.moduleId,
        date: new Date(dto.date),
        topic: dto.topic,
        materials: dto.materials,
        note: dto.note,
      },
    });
  }

  async update(id: string, dto: UpdateLessonDto, user: AuthUser) {
    const lesson = await this.prisma.lesson.findFirst({
      where: { id, schoolId: user.schoolId },
      select: { id: true, group: { select: { teacherId: true } } },
    });
    if (!lesson) throw new NotFoundException('Урок не найден');
    if (user.role === UserRole.TEACHER) {
      await this.assertTeacherOwnsGroup(lesson.group.teacherId, user);
    }
    const data: any = { ...dto };
    if (dto.date) data.date = new Date(dto.date);
    return this.prisma.lesson.update({ where: { id }, data });
  }

  /**
   * Удалить урок. Отметки посещаемости по этому уроку удалятся вместе с ним;
   * фото и комментарии, уже привязанные к нему, останутся (просто потеряют
   * ссылку на дату/тему урока) — ничего у родителей не пропадёт.
   */
  async remove(id: string, user: AuthUser) {
    const lesson = await this.prisma.lesson.findFirst({
      where: { id, schoolId: user.schoolId },
      select: { id: true, group: { select: { teacherId: true } } },
    });
    if (!lesson) throw new NotFoundException('Урок не найден');
    if (user.role === UserRole.TEACHER) {
      await this.assertTeacherOwnsGroup(lesson.group.teacherId, user);
    }
    await this.prisma.lesson.delete({ where: { id } });
    return { ok: true };
  }

  /**
   * Автогенерация уроков на будущее по расписанию группы (ScheduleSlot) —
   * чтобы не вписывать вручную занятие за занятием на весь учебный год.
   * Темы/материалы остаются пустыми — их потом заполняют по одному.
   * Уже существующие уроки на эти даты/время не дублируются.
   */
  async generateForYear(groupId: string, dto: GenerateLessonsDto, user: AuthUser) {
    const group = await this.prisma.group.findFirst({
      where: { id: groupId, schoolId: user.schoolId },
      include: { scheduleSlots: true },
    });
    if (!group) throw new NotFoundException('Группа не найдена');
    if (user.role === UserRole.TEACHER) {
      await this.assertTeacherOwnsGroup(group.teacherId, user);
    }
    if (group.scheduleSlots.length === 0) {
      throw new BadRequestException(
        'У группы не задано расписание (день недели и время) — сначала добавьте его в настройках группы',
      );
    }

    const until = new Date(dto.until);
    until.setHours(23, 59, 59, 999);
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    if (until <= today) throw new BadRequestException('Дата окончания должна быть в будущем');
    const maxRangeMs = 400 * 24 * 60 * 60 * 1000; // защита от случайной даты через 10 лет
    if (until.getTime() - today.getTime() > maxRangeMs) {
      throw new BadRequestException('Слишком большой период — выберите дату не дальше чем через год');
    }

    const existing = await this.prisma.lesson.findMany({
      where: { groupId, date: { gte: today, lte: until } },
      select: { date: true },
    });
    const existingKeys = new Set(existing.map((l) => l.date.toISOString()));

    const toCreate: { schoolId: string; groupId: string; date: Date }[] = [];
    const cursor = new Date(today);
    while (cursor <= until) {
      for (const slot of group.scheduleSlots) {
        if (cursor.getDay() === WEEKDAY_INDEX[slot.weekday]) {
          const [h, m] = slot.startTime.split(':').map((n) => parseInt(n, 10) || 0);
          const lessonDate = new Date(cursor);
          lessonDate.setHours(h, m, 0, 0);
          const key = lessonDate.toISOString();
          if (!existingKeys.has(key)) {
            existingKeys.add(key);
            toCreate.push({ schoolId: user.schoolId, groupId, date: lessonDate });
          }
        }
      }
      cursor.setDate(cursor.getDate() + 1);
    }

    if (toCreate.length > 0) {
      await this.prisma.lesson.createMany({ data: toCreate });
    }
    return { created: toCreate.length };
  }

  // ── доступ ──────────────────────────────────────────────────────────────
  private async assertGroupAccess(groupId: string, user: AuthUser, requireWrite = false) {
    const group = await this.prisma.group.findFirst({
      where: { id: groupId, schoolId: user.schoolId },
      select: { id: true, teacherId: true },
    });
    if (!group) throw new NotFoundException('Группа не найдена');
    if (user.role === UserRole.TEACHER) {
      await this.assertTeacherOwnsGroup(group.teacherId, user);
    } else if (requireWrite && user.role === UserRole.PARENT) {
      throw new ForbiddenException('Недостаточно прав');
    }
    return group;
  }

  private async assertTeacherOwnsGroup(teacherId: string | null, user: AuthUser) {
    const teacher = await this.prisma.teacher.findUnique({
      where: { userId: user.userId }, select: { id: true },
    });
    if (!teacherId || teacherId !== teacher?.id) {
      throw new ForbiddenException('Нет доступа к этой группе');
    }
  }
}
