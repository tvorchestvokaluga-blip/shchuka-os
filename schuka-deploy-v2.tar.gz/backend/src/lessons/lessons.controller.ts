// LessonsController — /api/groups/:groupId/lessons и /api/lessons/:id
import { Body, Controller, Delete, Get, Param, Patch, Post } from '@nestjs/common';
import { UserRole } from '@prisma/client';
import { LessonsService } from './lessons.service';
import { CreateLessonDto, UpdateLessonDto, GenerateLessonsDto } from './dto/lesson.dto';
import { Roles } from '../common/decorators/roles.decorator';
import { CurrentUser, AuthUser } from '../common/decorators/current-user.decorator';

@Controller('groups/:groupId/lessons')
export class LessonsGroupController {
  constructor(private readonly lessons: LessonsService) {}

  @Get()
  findByGroup(@Param('groupId') groupId: string, @CurrentUser() user: AuthUser) {
    return this.lessons.findByGroup(groupId, user);
  }

  @Post()
  @Roles(UserRole.OWNER, UserRole.ADMIN, UserRole.TEACHER)
  create(@Body() dto: CreateLessonDto, @Param('groupId') groupId: string, @CurrentUser() user: AuthUser) {
    return this.lessons.create({ ...dto, groupId }, user);
  }

  /** Заполнить расписание группы уроками вперёд (по дням недели из ScheduleSlot) до указанной даты. */
  @Post('generate')
  @Roles(UserRole.OWNER, UserRole.ADMIN, UserRole.TEACHER)
  generate(
    @Param('groupId') groupId: string,
    @Body() dto: GenerateLessonsDto,
    @CurrentUser() user: AuthUser,
  ) {
    return this.lessons.generateForYear(groupId, dto, user);
  }
}

@Controller('lessons')
export class LessonsController {
  constructor(private readonly lessons: LessonsService) {}

  @Get(':id')
  findOne(@Param('id') id: string, @CurrentUser() user: AuthUser) {
    return this.lessons.findOne(id, user);
  }

  @Patch(':id')
  @Roles(UserRole.OWNER, UserRole.ADMIN, UserRole.TEACHER)
  update(@Param('id') id: string, @Body() dto: UpdateLessonDto, @CurrentUser() user: AuthUser) {
    return this.lessons.update(id, dto, user);
  }

  /** Удалить урок — например, добавленный по ошибке или дублирующий. */
  @Delete(':id')
  @Roles(UserRole.OWNER, UserRole.ADMIN, UserRole.TEACHER)
  remove(@Param('id') id: string, @CurrentUser() user: AuthUser) {
    return this.lessons.remove(id, user);
  }
}
