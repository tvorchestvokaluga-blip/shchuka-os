// Данные запросов для уроков, с валидацией.
import { IsDateString, IsOptional, IsString } from 'class-validator';

export class CreateLessonDto {
  @IsString()
  groupId: string;

  @IsOptional()
  @IsString()
  moduleId?: string;

  @IsDateString({}, { message: 'Дата в формате ISO 8601, например 2025-09-01T16:00:00' })
  date: string;

  @IsOptional()
  @IsString()
  topic?: string;

  @IsOptional()
  @IsString()
  materials?: string; // материалы/методичка к уроку — текст или ссылка

  @IsOptional()
  @IsString()
  note?: string;
}

export class UpdateLessonDto {
  @IsOptional() @IsDateString() date?: string;
  @IsOptional() @IsString() topic?: string;
  @IsOptional() @IsString() materials?: string;
  @IsOptional() @IsString() moduleId?: string;
  @IsOptional() @IsString() note?: string;
}

/** Автогенерация уроков на весь год вперёд по расписанию группы (без тем — их потом впишут). */
export class GenerateLessonsDto {
  @IsDateString({}, { message: 'Дата в формате ISO 8601, например 2027-05-31' })
  until: string; // до какой даты включительно генерировать уроки
}
