import { Module } from '@nestjs/common';
import { LessonsService } from './lessons.service';
import { LessonsController, LessonsGroupController } from './lessons.controller';

@Module({
  controllers: [LessonsGroupController, LessonsController],
  providers: [LessonsService],
  exports: [LessonsService],
})
export class LessonsModule {}
