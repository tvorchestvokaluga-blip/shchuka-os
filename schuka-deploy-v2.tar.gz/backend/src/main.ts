// main.ts — запуск HTTP-сервера Schuka OS.
import { NestFactory } from '@nestjs/core';
import { NestExpressApplication } from '@nestjs/platform-express';
import { ValidationPipe, Logger } from '@nestjs/common';
import { join } from 'path';
import * as fs from 'fs';
import helmet from 'helmet';
import { AppModule } from './app.module';

const DEV_JWT_SECRETS = new Set([
  'dev-local-secret-change-me-1234567890',
  'dev-secret-change-me',
]);

async function bootstrap() {
  const isProd = process.env.NODE_ENV === 'production';

  // Защита от случайного запуска «боевого» сервера с тестовым секретом —
  // если это когда-нибудь попадёт на настоящий сервер с JWT_SECRET по
  // умолчанию, токены будет легко подделать. Лучше не запуститься вовсе.
  if (isProd && (!process.env.JWT_SECRET || DEV_JWT_SECRETS.has(process.env.JWT_SECRET))) {
    Logger.error(
      '❌ JWT_SECRET не задан или оставлен тестовым значением. ' +
        'На боевом сервере задайте в .env свой длинный случайный JWT_SECRET и перезапустите.',
    );
    process.exit(1);
  }

  const app = await NestFactory.create<NestExpressApplication>(AppModule);

  // Базовые защитные HTTP-заголовки (запрет встраивания в чужой iframe,
  // отключение угадывания типа содержимого и т.п.)
  app.use(helmet({ crossOriginResourcePolicy: false }));

  // CORS — чтобы фронтенд (Next.js) мог обращаться к API.
  // В проде пускаем только настоящий адрес сайта (FRONTEND_URL, через запятую
  // можно перечислить несколько) — иначе к API сможет обращаться любой чужой сайт.
  const allowedOrigins = (process.env.FRONTEND_URL || '')
    .split(',')
    .map((s) => s.trim())
    .filter(Boolean);
  app.enableCors({
    origin: isProd && allowedOrigins.length > 0 ? allowedOrigins : true,
    credentials: true,
  });

  // Локальное (тестовое) хранилище файлов — фото с занятий и т.п.
  // Лежат на диске сервера в папке uploads/ и отдаются по /uploads/...
  // Когда подключим облако (S3/Я.Облако), это место — единственное, что поменяется.
  const uploadsDir = join(__dirname, '..', 'uploads');
  if (!fs.existsSync(uploadsDir)) fs.mkdirSync(uploadsDir, { recursive: true });
  app.useStaticAssets(uploadsDir, { prefix: '/uploads' });

  // Все ответы и пути под /api
  app.setGlobalPrefix('api');

  // Глобальная валидация входных данных по DTO.
  app.useGlobalPipes(
    new ValidationPipe({
      whitelist: true,           // отбрасывает лишние поля
      forbidNonWhitelisted: true,
      transform: true,           // приводит типы (строки → числа и т.п.)
    }),
  );

  const port = process.env.PORT || 4000;
  await app.listen(port);
  console.log(`🐟 Schuka OS API запущен на http://localhost:${port}/api`);
}
bootstrap();
