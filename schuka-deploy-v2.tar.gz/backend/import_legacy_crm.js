// ============================================================================
//  Импорт данных из старой CRM в Schuka OS
//  Программы -> Педагоги (логины) -> Группы + расписание -> Дети -> Зачисления
//
//  Скрипт идемпотентный: его можно безопасно запустить повторно —
//  существующие записи не дублируются, только добавляется недостающее.
//
//  Запуск:  node import_legacy_crm.js
// ============================================================================

const { PrismaClient } = require('@prisma/client');
const bcrypt = require('bcrypt');
const crypto = require('crypto');

const prisma = new PrismaClient();

const DATA = {
  "programs": [
    {
      "name": "Первые шаги",
      "ageFrom": 4,
      "ageTo": 5,
      "basePrice": 6000
    },
    {
      "name": "Юные художники",
      "ageFrom": 6,
      "ageTo": 7,
      "basePrice": 6400
    },
    {
      "name": "Академический старт",
      "ageFrom": 8,
      "ageTo": 10,
      "basePrice": 6800
    },
    {
      "name": "Предпрофессиональная",
      "ageFrom": 11,
      "ageTo": 16,
      "basePrice": 7150
    }
  ],
  "teachers": [
    {
      "fullName": "Володина Елизавета Сергеевна",
      "email": "volodina.es@schuka-os.local",
      "phone": null
    },
    {
      "fullName": "Горшкова Светлана Евгеньевна",
      "email": "gorshkova.se@schuka-os.local",
      "phone": null
    },
    {
      "fullName": "Омарова Сабина Азадовна",
      "email": "omarova.sa@schuka-os.local",
      "phone": "+7(953)327-49-15"
    },
    {
      "fullName": "Уваров Андрей Владиславович",
      "email": "uvarov.av@schuka-os.local",
      "phone": "+7(920)840-79-64"
    }
  ],
  "groups": [
    {
      "name": "Первые шаги",
      "program": "Первые шаги",
      "teacher": "Горшкова Светлана Евгеньевна",
      "slots": [
        {
          "weekday": "SUN",
          "startTime": "10:00",
          "endTime": "11:30"
        }
      ],
      "startDate": "2026-09-06"
    },
    {
      "name": "Юные художники",
      "program": "Юные художники",
      "teacher": "Горшкова Светлана Евгеньевна",
      "slots": [
        {
          "weekday": "SUN",
          "startTime": "12:00",
          "endTime": "14:00"
        }
      ],
      "startDate": "2026-09-01"
    },
    {
      "name": "1 класс/группа А (АК.СТ)",
      "program": "Академический старт",
      "teacher": "Омарова Сабина Азадовна",
      "slots": [
        {
          "weekday": "MON",
          "startTime": "15:00",
          "endTime": "17:00"
        },
        {
          "weekday": "WED",
          "startTime": "15:00",
          "endTime": "17:00"
        }
      ],
      "startDate": "2026-09-01"
    },
    {
      "name": "1 класс/группа Б (АК.СТ)",
      "program": "Академический старт",
      "teacher": "Горшкова Светлана Евгеньевна",
      "slots": [
        {
          "weekday": "FRI",
          "startTime": "17:30",
          "endTime": "19:30"
        },
        {
          "weekday": "SUN",
          "startTime": "15:00",
          "endTime": "17:00"
        }
      ],
      "startDate": "2026-09-01"
    },
    {
      "name": "2 класс (АК.СТ)",
      "program": "Академический старт",
      "teacher": "Володина Елизавета Сергеевна",
      "slots": [
        {
          "weekday": "FRI",
          "startTime": "17:30",
          "endTime": "19:30"
        },
        {
          "weekday": "SUN",
          "startTime": "10:00",
          "endTime": "12:00"
        }
      ],
      "startDate": "2026-09-01"
    },
    {
      "name": "3 класс (АК.СТ)",
      "program": "Академический старт",
      "teacher": "Омарова Сабина Азадовна",
      "slots": [
        {
          "weekday": "MON",
          "startTime": "17:30",
          "endTime": "19:30"
        },
        {
          "weekday": "WED",
          "startTime": "17:30",
          "endTime": "19:30"
        }
      ],
      "startDate": "2026-09-01"
    },
    {
      "name": "1 класс (ПР.ПР)",
      "program": "Предпрофессиональная",
      "teacher": "Володина Елизавета Сергеевна",
      "slots": [
        {
          "weekday": "MON",
          "startTime": "17:30",
          "endTime": "19:30"
        },
        {
          "weekday": "WED",
          "startTime": "17:30",
          "endTime": "19:30"
        },
        {
          "weekday": "SUN",
          "startTime": "12:00",
          "endTime": "14:00"
        }
      ],
      "startDate": "2026-09-01"
    },
    {
      "name": "2 класс ПР",
      "program": "Предпрофессиональная",
      "teacher": "Володина Елизавета Сергеевна",
      "slots": [
        {
          "weekday": "MON",
          "startTime": "17:30",
          "endTime": "19:30"
        },
        {
          "weekday": "WED",
          "startTime": "17:30",
          "endTime": "19:30"
        },
        {
          "weekday": "SUN",
          "startTime": "12:00",
          "endTime": "14:00"
        }
      ],
      "startDate": "2025-08-12"
    },
    {
      "name": "4 класс ПР",
      "program": "Предпрофессиональная",
      "teacher": "Володина Елизавета Сергеевна",
      "slots": [
        {
          "weekday": "MON",
          "startTime": "17:30",
          "endTime": "19:30"
        },
        {
          "weekday": "WED",
          "startTime": "17:30",
          "endTime": "19:30"
        },
        {
          "weekday": "SUN",
          "startTime": "12:00",
          "endTime": "14:00"
        }
      ],
      "startDate": "2025-08-12"
    }
  ],
  "students": [
    {
      "fullName": "Кылосова Юлия Владимировна",
      "lastName": "Кылосова",
      "firstName": "Юлия",
      "groups": [
        "1 класс (ПР.ПР)"
      ]
    },
    {
      "fullName": "Люкова Валерия Николаевна",
      "lastName": "Люкова",
      "firstName": "Валерия",
      "groups": [
        "1 класс (ПР.ПР)"
      ]
    },
    {
      "fullName": "Пархоменко Анастасия",
      "lastName": "Пархоменко",
      "firstName": "Анастасия",
      "groups": [
        "1 класс (ПР.ПР)"
      ]
    },
    {
      "fullName": "Степина Анфиса",
      "lastName": "Степина",
      "firstName": "Анфиса",
      "groups": [
        "1 класс (ПР.ПР)"
      ]
    },
    {
      "fullName": "Хлопчур Полина Сергеевна",
      "lastName": "Хлопчур",
      "firstName": "Полина",
      "groups": [
        "1 класс (ПР.ПР)"
      ]
    },
    {
      "fullName": "Аннинкова Василиса",
      "lastName": "Аннинкова",
      "firstName": "Василиса",
      "groups": [
        "1 класс/группа А (АК.СТ)"
      ]
    },
    {
      "fullName": "Ермошенко Тихон Андреевич",
      "lastName": "Ермошенко",
      "firstName": "Тихон",
      "groups": [
        "1 класс/группа А (АК.СТ)"
      ]
    },
    {
      "fullName": "Каверзина Есения Антоновна",
      "lastName": "Каверзина",
      "firstName": "Есения",
      "groups": [
        "1 класс/группа А (АК.СТ)"
      ]
    },
    {
      "fullName": "Люкова Ярослава Николаевна",
      "lastName": "Люкова",
      "firstName": "Ярослава",
      "groups": [
        "1 класс/группа А (АК.СТ)"
      ]
    },
    {
      "fullName": "Федорова Радамира",
      "lastName": "Федорова",
      "firstName": "Радамира",
      "groups": [
        "1 класс/группа А (АК.СТ)"
      ]
    },
    {
      "fullName": "Долгер Ульяна Николаевна",
      "lastName": "Долгер",
      "firstName": "Ульяна",
      "groups": [
        "1 класс/группа Б (АК.СТ)",
        "Юные художники"
      ]
    },
    {
      "fullName": "Павлова Анисия",
      "lastName": "Павлова",
      "firstName": "Анисия",
      "groups": [
        "1 класс/группа Б (АК.СТ)"
      ]
    },
    {
      "fullName": "Соломатина Анна Олеговна",
      "lastName": "Соломатина",
      "firstName": "Анна",
      "groups": [
        "1 класс/группа Б (АК.СТ)"
      ]
    },
    {
      "fullName": "Абдулова Елизавета Андреевна",
      "lastName": "Абдулова",
      "firstName": "Елизавета",
      "groups": [
        "2 класс (АК.СТ)"
      ]
    },
    {
      "fullName": "Алексеевский Владимир Михайлович",
      "lastName": "Алексеевский",
      "firstName": "Владимир",
      "groups": [
        "2 класс (АК.СТ)"
      ]
    },
    {
      "fullName": "Арен Валерия Сергеевна",
      "lastName": "Арен",
      "firstName": "Валерия",
      "groups": [
        "2 класс (АК.СТ)"
      ]
    },
    {
      "fullName": "Борискин Дмитрий",
      "lastName": "Борискин",
      "firstName": "Дмитрий",
      "groups": [
        "2 класс (АК.СТ)"
      ]
    },
    {
      "fullName": "Борискин Евгений",
      "lastName": "Борискин",
      "firstName": "Евгений",
      "groups": [
        "2 класс (АК.СТ)"
      ]
    },
    {
      "fullName": "Душкина Елизавета Ильинична",
      "lastName": "Душкина",
      "firstName": "Елизавета",
      "groups": [
        "2 класс (АК.СТ)"
      ]
    },
    {
      "fullName": "Миронов Андрей Сергеевич",
      "lastName": "Миронов",
      "firstName": "Андрей",
      "groups": [
        "2 класс (АК.СТ)"
      ]
    },
    {
      "fullName": "София Блинникова",
      "lastName": "Блинникова",
      "firstName": "София",
      "groups": [
        "2 класс (АК.СТ)"
      ]
    },
    {
      "fullName": "Прусова Варвара Витальевна",
      "lastName": "Прусова",
      "firstName": "Варвара",
      "groups": [
        "2 класс ПР"
      ]
    },
    {
      "fullName": "Рогаткина Виктория Владимировна",
      "lastName": "Рогаткина",
      "firstName": "Виктория",
      "groups": [
        "2 класс ПР"
      ]
    },
    {
      "fullName": "Беккер Николь Андреевна",
      "lastName": "Беккер",
      "firstName": "Николь",
      "groups": [
        "3 класс (АК.СТ)"
      ]
    },
    {
      "fullName": "Винокурова Александра",
      "lastName": "Винокурова",
      "firstName": "Александра",
      "groups": [
        "3 класс (АК.СТ)"
      ]
    },
    {
      "fullName": "Дубийковская Надежда Васильевна",
      "lastName": "Дубийковская",
      "firstName": "Надежда",
      "groups": [
        "3 класс (АК.СТ)"
      ]
    },
    {
      "fullName": "Ковтун Константин",
      "lastName": "Ковтун",
      "firstName": "Константин",
      "groups": [
        "3 класс (АК.СТ)"
      ]
    },
    {
      "fullName": "Марасанова София Дмитриевна",
      "lastName": "Марасанова",
      "firstName": "София",
      "groups": [
        "3 класс (АК.СТ)"
      ]
    },
    {
      "fullName": "Мартынова Таисия Федоровна",
      "lastName": "Мартынова",
      "firstName": "Таисия",
      "groups": [
        "3 класс (АК.СТ)"
      ]
    },
    {
      "fullName": "Бурханова Гузель",
      "lastName": "Бурханова",
      "firstName": "Гузель",
      "groups": [
        "4 класс ПР"
      ]
    },
    {
      "fullName": "Горохова Ксения Денисовна",
      "lastName": "Горохова",
      "firstName": "Ксения",
      "groups": [
        "4 класс ПР"
      ]
    },
    {
      "fullName": "Иванова Валерия Максимовна",
      "lastName": "Иванова",
      "firstName": "Валерия",
      "groups": [
        "4 класс ПР"
      ]
    },
    {
      "fullName": "Сагдеева Алина",
      "lastName": "Сагдеева",
      "firstName": "Алина",
      "groups": [
        "4 класс ПР"
      ]
    },
    {
      "fullName": "Дмитрикова Арина Алексеевна",
      "lastName": "Дмитрикова",
      "firstName": "Арина",
      "groups": [
        "Первые шаги"
      ]
    },
    {
      "fullName": "Жаворонков Роман Александрович",
      "lastName": "Жаворонков",
      "firstName": "Роман",
      "groups": [
        "Первые шаги"
      ]
    },
    {
      "fullName": "Сорокина Елизавета Андреевна",
      "lastName": "Сорокина",
      "firstName": "Елизавета",
      "groups": [
        "Первые шаги"
      ]
    },
    {
      "fullName": "Суворова Ника Алексеевна",
      "lastName": "Суворова",
      "firstName": "Ника",
      "groups": [
        "Первые шаги"
      ]
    },
    {
      "fullName": "Филатова Алана Михайловна",
      "lastName": "Филатова",
      "firstName": "Алана",
      "groups": [
        "Первые шаги"
      ]
    },
    {
      "fullName": "Шадченева Вероника Сергеевна",
      "lastName": "Шадченева",
      "firstName": "Вероника",
      "groups": [
        "Первые шаги"
      ]
    },
    {
      "fullName": "Григорян Диана Меликовна",
      "lastName": "Григорян",
      "firstName": "Диана",
      "groups": [
        "Юные художники"
      ]
    },
    {
      "fullName": "Марасанова Майя Дмитриевна",
      "lastName": "Марасанова",
      "firstName": "Майя",
      "groups": [
        "Юные художники"
      ]
    },
    {
      "fullName": "Небольшина Ева Всеволодовна",
      "lastName": "Небольшина",
      "firstName": "Ева",
      "groups": [
        "Юные художники"
      ]
    },
    {
      "fullName": "Пацакула Королина",
      "lastName": "Пацакула",
      "firstName": "Королина",
      "groups": [
        "Юные художники"
      ]
    },
    {
      "fullName": "Сидорова Даша",
      "lastName": "Сидорова",
      "firstName": "Даша",
      "groups": [
        "Юные художники"
      ]
    }
  ]
};

function randomPassword() {
  return crypto.randomBytes(6).toString('base64').replace(/[+/=]/g, '').slice(0, 10);
}

async function main() {
  const school = await prisma.school.findFirst();
  if (!school) {
    throw new Error('Школа не найдена в базе — сначала должен быть выполнен исходный seed.');
  }
  console.log(`Школа: ${school.name} (${school.id})`);

  // ---- 1. Программы ----
  const programByName = {};
  for (const p of DATA.programs) {
    let program = await prisma.program.findFirst({ where: { schoolId: school.id, name: p.name } });
    if (!program) {
      program = await prisma.program.create({
        data: {
          schoolId: school.id,
          name: p.name,
          ageFrom: p.ageFrom,
          ageTo: p.ageTo,
          basePrice: p.basePrice,
        },
      });
      console.log(`[+] Программа создана: ${p.name} (${p.ageFrom}-${p.ageTo} лет, ${p.basePrice}₽/мес)`);
    } else {
      console.log(`[=] Программа уже есть: ${p.name}`);
    }
    programByName[p.name] = program;
  }

  // ---- 2. Педагоги (User + Teacher) ----
  const teacherByName = {};
  const createdCredentials = [];
  for (const t of DATA.teachers) {
    let user = await prisma.user.findUnique({
      where: { schoolId_email: { schoolId: school.id, email: t.email } },
    });
    if (!user) {
      const tempPassword = randomPassword();
      const passwordHash = await bcrypt.hash(tempPassword, 10);
      user = await prisma.user.create({
        data: {
          schoolId: school.id,
          email: t.email,
          phone: t.phone,
          passwordHash,
          fullName: t.fullName,
          role: 'TEACHER',
        },
      });
      await prisma.teacher.create({ data: { schoolId: school.id, userId: user.id } });
      createdCredentials.push({ fullName: t.fullName, email: t.email, password: tempPassword });
      console.log(`[+] Педагог создан: ${t.fullName} (${t.email})`);
    } else {
      console.log(`[=] Педагог уже есть: ${t.fullName} (${t.email})`);
    }
    const teacher = await prisma.teacher.findUnique({ where: { userId: user.id } });
    teacherByName[t.fullName] = teacher;
  }

  // ---- 3. Группы + расписание ----
  const groupByName = {};
  for (const g of DATA.groups) {
    let group = await prisma.group.findFirst({ where: { schoolId: school.id, name: g.name } });
    const teacher = teacherByName[g.teacher];
    const program = programByName[g.program];
    if (!group) {
      group = await prisma.group.create({
        data: {
          schoolId: school.id,
          programId: program.id,
          teacherId: teacher ? teacher.id : null,
          name: g.name,
        },
      });
      for (const slot of g.slots) {
        await prisma.scheduleSlot.create({
          data: {
            groupId: group.id,
            weekday: slot.weekday,
            startTime: slot.startTime,
            endTime: slot.endTime,
          },
        });
      }
      console.log(`[+] Группа создана: ${g.name} -> ${g.program}, педагог: ${g.teacher}`);
    } else {
      console.log(`[=] Группа уже есть: ${g.name}`);
    }
    groupByName[g.name] = { group, startDate: g.startDate, programId: program.id };
  }

  // ---- 4. Дети + семьи ----
  const familyByLastName = {};
  const studentByFullName = {};
  let createdStudents = 0;
  let createdFamilies = 0;
  for (const s of DATA.students) {
    let existing = await prisma.student.findFirst({
      where: { schoolId: school.id, firstName: s.firstName, lastName: s.lastName, deletedAt: null },
    });
    if (existing) {
      studentByFullName[s.fullName] = existing;
      console.log(`[=] Ребёнок уже есть: ${s.lastName} ${s.firstName}`);
      continue;
    }

    let family = familyByLastName[s.lastName];
    if (!family) {
      family = await prisma.family.findFirst({ where: { schoolId: school.id, name: `Семья ${s.lastName}` } });
      if (!family) {
        family = await prisma.family.create({ data: { schoolId: school.id, name: `Семья ${s.lastName}` } });
        createdFamilies++;
      }
      familyByLastName[s.lastName] = family;
    }

    const student = await prisma.student.create({
      data: {
        schoolId: school.id,
        familyId: family.id,
        firstName: s.firstName,
        lastName: s.lastName,
        birthDate: null, // дата рождения не перенесена — заполнить позже в карточке ребёнка
      },
    });
    studentByFullName[s.fullName] = student;
    createdStudents++;
    console.log(`[+] Ребёнок создан: ${s.lastName} ${s.firstName} (семья: ${family.name})`);
  }

  // ---- 5. Зачисления ----
  let createdEnrollments = 0;
  for (const s of DATA.students) {
    const student = studentByFullName[s.fullName];
    for (const gname of s.groups) {
      const g = groupByName[gname];
      const existingEnrollment = await prisma.enrollment.findFirst({
        where: { studentId: student.id, groupId: g.group.id },
      });
      if (existingEnrollment) continue;
      await prisma.enrollment.create({
        data: {
          schoolId: school.id,
          studentId: student.id,
          programId: g.programId,
          groupId: g.group.id,
          status: 'ACTIVE',
          startDate: new Date(g.startDate),
        },
      });
      createdEnrollments++;
    }
  }

  console.log('\n========================================');
  console.log('ИТОГО:');
  console.log(`  Новых семей:       ${createdFamilies}`);
  console.log(`  Новых детей:       ${createdStudents}`);
  console.log(`  Новых зачислений:  ${createdEnrollments}`);
  if (createdCredentials.length) {
    console.log('\nНовые логины педагогов (временный пароль — попросите сменить при первом входе):');
    for (const c of createdCredentials) {
      console.log(`  ${c.fullName}\n    email: ${c.email}\n    пароль: ${c.password}`);
    }
  }
  console.log('========================================\n');
}

main()
  .catch((e) => {
    console.error('ОШИБКА ИМПОРТА:', e);
    process.exitCode = 1;
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
