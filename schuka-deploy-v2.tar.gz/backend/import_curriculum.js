// ============================================================================
//  Импорт программ занятий (методичек) в Schuka OS
//  Читает lesson_records.json (должен лежать рядом с этим файлом) и создаёт
//  записи Lesson для каждой группы — дата вычислена по фактическому
//  расписанию группы, тема и методичка — из присланного документа.
//
//  Идемпотентный: повторный запуск не создаст дублей (проверка по
//  группе + дате + теме).
//
//  Запуск:  node import_curriculum.js
// ============================================================================

const { PrismaClient } = require('@prisma/client');
const fs = require('fs');
const path = require('path');

const prisma = new PrismaClient();

async function main() {
  const dataPath = path.join(__dirname, 'lesson_records.json');
  const records = JSON.parse(fs.readFileSync(dataPath, 'utf-8'));
  console.log(`Загружено записей о занятиях: ${records.length}`);

  const school = await prisma.school.findFirst();
  if (!school) throw new Error('Школа не найдена в базе.');

  const groupCache = {};
  let created = 0;
  let skipped = 0;
  let missingGroups = new Set();

  for (const r of records) {
    let group = groupCache[r.group];
    if (group === undefined) {
      group = await prisma.group.findFirst({ where: { schoolId: school.id, name: r.group } });
      groupCache[r.group] = group || null;
    }
    if (!group) {
      missingGroups.add(r.group);
      continue;
    }

    const date = new Date(r.date + 'T00:00:00');
    const existing = await prisma.lesson.findFirst({
      where: { groupId: group.id, date, topic: r.topic },
    });
    if (existing) {
      skipped++;
      continue;
    }

    await prisma.lesson.create({
      data: {
        schoolId: school.id,
        groupId: group.id,
        date,
        topic: r.topic,
        materials: r.materials,
      },
    });
    created++;
  }

  console.log('\n========================================');
  console.log(`Создано занятий:   ${created}`);
  console.log(`Уже было (пропущено): ${skipped}`);
  if (missingGroups.size) {
    console.log('Группы не найдены в базе (сначала запустите import_legacy_crm.js):');
    for (const g of missingGroups) console.log('  -', g);
  }
  console.log('========================================\n');
}

main()
  .catch((e) => {
    console.error('ОШИБКА ИМПОРТА ПРОГРАММ:', e);
    process.exitCode = 1;
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
